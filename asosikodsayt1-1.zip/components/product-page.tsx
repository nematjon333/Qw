"use client"

import { useState } from "react"
import { ShoppingCart, Truck, ArrowLeft } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { ProductCard } from "@/components/product-card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useCart } from "@/context/cart-context"
import { toast } from "@/components/ui/use-toast"
import { QuantitySelector } from "@/components/quantity-selector"

// Sample related products data
const relatedProductsData = [
  {
    id: "1",
    name: "Яблоки Голден",
    price: 159,
    image: "/placeholder.svg?height=400&width=400",
    unit: "кг",
    discount: 15,
  },
  {
    id: "2",
    name: "Бананы",
    price: 129,
    image: "/placeholder.svg?height=400&width=400",
    unit: "кг",
  },
  {
    id: "3",
    name: "Апельсины",
    price: 189,
    image: "/placeholder.svg?height=400&width=400",
    unit: "кг",
    discount: 10,
  },
  {
    id: "9",
    name: "Груши",
    price: 229,
    image: "/placeholder.svg?height=400&width=400",
    unit: "кг",
  },
]

// This is a mock function to get related products
function getRelatedProducts(ids: string[]) {
  return relatedProductsData.filter((product) => ids?.includes(product.id))
}

export function ProductPage({ product }) {
  const [quantity, setQuantity] = useState(1)
  const { addItem } = useCart()
  const relatedProducts = product.related ? getRelatedProducts(product.related) : []

  const discountedPrice = product.discount ? product.price - (product.price * product.discount) / 100 : null

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images?.[0] || "/placeholder.svg?height=400&width=400",
      unit: product.unit,
      discount: product.discount,
      quantity: quantity,
    })

    toast({
      title: "Товар добавлен в корзину",
      description: `${product.name} (${quantity} ${product.unit})`,
      variant: "success",
      duration: 3000,
    })
  }

  const handleQuantityChange = (newQuantity: number) => {
    setQuantity(newQuantity)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-8">
          <div className="mb-4 flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link href="/catalog">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад в каталог
              </Link>
            </Button>
            <div className="text-sm text-gray-500">
              <Link href="/" className="hover:text-green-600">
                Главная
              </Link>
              {" > "}
              <Link href="/catalog" className="hover:text-green-600">
                Каталог
              </Link>
              {" > "}
              <span>{product.name}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className="rounded-lg overflow-hidden">
              <img
                src={product.images?.[0] || "/placeholder.svg?height=400&width=400"}
                alt={product.name}
                className="w-full h-auto object-cover"
                onError={(e) => {
                  e.currentTarget.src = "/placeholder.svg?height=400&width=400"
                }}
              />
            </div>
            <div>
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>

              <div className="flex items-baseline gap-2 mb-4">
                {discountedPrice ? (
                  <>
                    <span className="text-2xl font-bold">
                      {discountedPrice.toFixed(0)} ₽/{product.unit}
                    </span>
                    <span className="text-lg text-gray-500 line-through">{product.price.toFixed(0)} ₽</span>
                    <span className="ml-2 rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-600">
                      -{product.discount}%
                    </span>
                  </>
                ) : (
                  <span className="text-2xl font-bold">
                    {product.price.toFixed(0)} ₽/{product.unit}
                  </span>
                )}
              </div>

              <p className="text-gray-600 mb-6">{product.description}</p>

              <div className="mb-6 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Происхождение:</span>
                  <span>{product.origin}</span>
                </div>
                {product.weight && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Вес:</span>
                    <span>
                      {product.weight} {product.unit}
                    </span>
                  </div>
                )}
                {product.volume && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Объем:</span>
                    <span>
                      {product.volume} {product.unit}
                    </span>
                  </div>
                )}
              </div>

              <Separator className="my-6" />

              <div className="flex items-center gap-4 mb-6">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Количество:</label>
                  <QuantitySelector
                    initialValue={quantity}
                    min={product.min_quantity || 0.1}
                    max={product.max_quantity || 10}
                    step={product.step || 0.1}
                    unit={product.unit}
                    onChange={handleQuantityChange}
                  />
                </div>
                <Button className="flex-1 gap-2 bg-green-600 hover:bg-green-700" onClick={handleAddToCart}>
                  <ShoppingCart className="h-5 w-5" />В корзину
                </Button>
              </div>

              <div className="rounded-lg bg-green-50 p-4 flex items-center gap-3">
                <Truck className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">Доставка в течение 60 минут</p>
                  <p className="text-sm text-gray-600">По всему Челябинску</p>
                </div>
              </div>
            </div>
          </div>

          {relatedProducts.length > 0 && (
            <section className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Похожие товары</h2>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                {relatedProducts.map((product) => (
                  <ProductCard key={product.id} {...product} />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
