"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { YandexMap } from "@/components/yandex-map"

export function CitySelector() {
  const [open, setOpen] = useState(false)
  const [showMap, setShowMap] = useState(false)
  const [cityConfirmed, setCityConfirmed] = useState(false)
  const [address, setAddress] = useState("")

  useEffect(() => {
    // Проверяем, был ли уже выбран город
    const confirmed = localStorage.getItem("city_confirmed")
    if (!confirmed) {
      // Если город еще не выбран, показываем диалог
      setTimeout(() => setOpen(true), 1000)
    } else {
      setCityConfirmed(true)
      setAddress(localStorage.getItem("delivery_address") || "")
    }
  }, [])

  const handleConfirmCity = () => {
    localStorage.setItem("city_confirmed", "true")
    setCityConfirmed(true)
    setOpen(false)
  }

  const handleChangeCity = () => {
    setShowMap(true)
  }

  const handleAddressSelect = (selectedAddress: string) => {
    setAddress(selectedAddress)
    localStorage.setItem("delivery_address", selectedAddress)
    setShowMap(false)
    setOpen(false)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          {!showMap ? (
            <>
              <DialogHeader>
                <DialogTitle>Подтвердите ваш город</DialogTitle>
                <DialogDescription>Ваш город - Челябинск?</DialogDescription>
              </DialogHeader>
              <DialogFooter className="flex flex-col sm:flex-row sm:justify-between">
                <Button onClick={handleConfirmCity} className="bg-green-600 hover:bg-green-700">
                  Да, всё верно
                </Button>
                <Button onClick={handleChangeCity} variant="outline" className="mt-2 sm:mt-0">
                  Нет, указать другой
                </Button>
              </DialogFooter>
            </>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle>Укажите ваш адрес</DialogTitle>
                <DialogDescription>Выберите адрес на карте или введите его вручную</DialogDescription>
              </DialogHeader>
              <YandexMap onAddressSelect={handleAddressSelect} />
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
