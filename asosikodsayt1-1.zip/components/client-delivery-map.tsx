"use client"
import dynamic from "next/dynamic"

// Динамически импортируем компонент карты, чтобы он загружался только на клиенте
const DeliveryMap = dynamic(() => import("@/components/delivery-map").then((mod) => mod.DeliveryMap), {
  ssr: false,
  loading: () => (
    <div className="aspect-video w-full rounded-lg border flex items-center justify-center bg-gray-100 dark:bg-gray-800 dark:border-gray-700">
      <div className="text-center">
        <p className="text-gray-500 dark:text-gray-400">Загрузка карты...</p>
      </div>
    </div>
  ),
})

export function ClientDeliveryMap() {
  return <DeliveryMap />
}
