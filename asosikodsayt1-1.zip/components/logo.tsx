"use client"

import Link from "next/link"
import Image from "next/image"

interface LogoProps {
  className?: string
}

export function Logo({ className = "" }: LogoProps) {
  return (
    <Link href="/" className={`flex items-center ${className}`}>
      <div className="relative h-10 w-10 overflow-hidden rounded-full mr-2">
        <Image
          src="/images/olucha-logo-new.png"
          alt="OLUCHA"
          width={40}
          height={40}
          className="object-cover transition-transform duration-300 hover:scale-110"
          style={{
            filter: "drop-shadow(0 0 5px rgba(255, 0, 0, 0.7))",
          }}
        />
        <div
          className="absolute inset-0 rounded-full"
          style={{
            boxShadow: "0 0 15px 3px rgba(255, 0, 0, 0.5)",
            animation: "pulse 2s infinite",
          }}
        ></div>
      </div>
      <div className="flex flex-col">
        <span className="text-xl font-bold tracking-tight">OLUCHA</span>
        <span className="text-xs text-gray-500 dark:text-gray-400">Natural & Fresh</span>
      </div>
      <style jsx>{`
        @keyframes pulse {
          0% {
            box-shadow: 0 0 15px 3px rgba(255, 0, 0, 0.5);
          }
          50% {
            box-shadow: 0 0 20px 6px rgba(255, 0, 0, 0.7);
          }
          100% {
            box-shadow: 0 0 15px 3px rgba(255, 0, 0, 0.5);
          }
        }
      `}</style>
    </Link>
  )
}
