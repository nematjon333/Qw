"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

interface PromoCodeInputProps {
  subtotal: number
  onApply: (discount: number, code: string) => void
}

export function PromoCodeInput({ subtotal, onApply }: PromoCodeInputProps) {
  const [promoCode, setPromoCode] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleApplyPromoCode = async () => {
    if (!promoCode.trim()) {
      setError("Введите промокод")
      return
    }

    setError("")
    setIsLoading(true)

    try {
      const response = await fetch("/api/promo-codes/apply", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          code: promoCode,
          subtotal,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Ошибка при применении промокода")
      }

      if (data.success) {
        toast({
          title: "Промокод применен",
          description: `Скидка: ${data.discount.toFixed(0)} ₽ (${data.discountPercent}%)`,
          variant: "success",
        })
        onApply(data.discount, data.promoCode)
      } else {
        throw new Error(data.message || "Ошибка при применении промокода")
      }
    } catch (error) {
      console.error("Ошибка при применении промокода:", error)
      setError(error.message || "Не удалось применить промокод")
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось применить промокод",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-2">
      <Label htmlFor="promoCode">Промокод</Label>
      <div className="flex gap-2">
        <Input
          id="promoCode"
          placeholder="Введите промокод"
          value={promoCode}
          onChange={(e) => setPromoCode(e.target.value)}
          className={error ? "border-red-500" : ""}
        />
        <Button
          type="button"
          variant="outline"
          className="border-green-600 text-green-600 hover:bg-green-50 dark:text-green-400 dark:border-green-700 dark:hover:bg-green-900/20"
          onClick={handleApplyPromoCode}
          disabled={isLoading}
        >
          {isLoading ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Применение...
            </span>
          ) : (
            "Применить"
          )}
        </Button>
      </div>
      {error && <p className="text-xs text-red-500">{error}</p>}
    </div>
  )
}
