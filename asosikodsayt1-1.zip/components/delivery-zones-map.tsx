"use client"

import { useEffect, useRef, useState } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import "leaflet-draw/dist/leaflet.draw.css"
import type { DeliveryZone } from "@/types/delivery"
import { CustomMapAttribution } from "@/components/custom-map-attribution"

// Используем CDN для иконок Leaflet

// Исправляем проблему с иконками в Leaflet
const fixLeafletIcon = () => {
  // @ts-ignore
  delete L.Icon.Default.prototype._getIconUrl
  L.Icon.Default.mergeOptions({
    iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
    iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
    shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  })
}

// Цвета для зон доставки
const zoneColors = {
  green: { fill: "#22c55e33", stroke: "#16a34a" },
  yellow: { fill: "#eab30833", stroke: "#ca8a04" },
  orange: { fill: "#f9730033", stroke: "#ea580c" },
  red: { fill: "#ef444433", stroke: "#dc2626" },
  purple: { fill: "#a855f733", stroke: "#9333ea" },
  blue: { fill: "#3b82f633", stroke: "#2563eb" },
  gray: { fill: "#6b728033", stroke: "#4b5563" },
}

interface DeliveryZonesMapProps {
  zones: DeliveryZone[]
  editable?: boolean
  onPolygonChange?: (polygon: [number, number][]) => void
  onCenterChange?: (lat: number, lng: number) => void
  onRadiusChange?: (radius: number) => void
  editingZoneId?: number
  height?: string | number
  storeCoordinates?: [number, number]
}

function DeliveryZonesMap({
  zones,
  editable = false,
  onPolygonChange,
  onCenterChange,
  onRadiusChange,
  editingZoneId,
  height = "500px",
  storeCoordinates,
}: DeliveryZonesMapProps) {
  const mapRef = useRef<L.Map | null>(null)
  const drawControlRef = useRef<L.Control.Draw | null>(null)
  const editLayerRef = useRef<L.FeatureGroup | null>(null)
  const zonesLayerRef = useRef<L.FeatureGroup | null>(null)
  const [mapInitialized, setMapInitialized] = useState(false)

  // Инициализация карты
  useEffect(() => {
    if (typeof window !== "undefined") {
      // Динамический импорт Leaflet Draw
      import("leaflet-draw").then(() => {
        if (!mapRef.current) {
          fixLeafletIcon()

          // Создаем карту
          const map = L.map("delivery-zones-map", {
            center: storeCoordinates || [55.7558, 37.6173], // Москва по умолчанию
            zoom: 10,
          })

          // Добавляем тайлы OpenStreetMap
          L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 19,
          }).addTo(map)

          // Создаем слои для зон и редактирования
          const zonesLayer = L.featureGroup().addTo(map)
          const editLayer = L.featureGroup().addTo(map)

          zonesLayerRef.current = zonesLayer
          editLayerRef.current = editLayer
          mapRef.current = map

          // Если карта редактируемая, добавляем контрол для рисования
          if (editable) {
            const drawControl = new L.Control.Draw({
              draw: {
                polyline: false,
                rectangle: false,
                circle: true,
                circlemarker: false,
                marker: false,
                polygon: {
                  allowIntersection: false,
                  showArea: true,
                },
              },
              edit: {
                featureGroup: editLayer,
                remove: true,
              },
            })

            map.addControl(drawControl)
            drawControlRef.current = drawControl

            // Обработчики событий для рисования и редактирования
            map.on(L.Draw.Event.CREATED, (event: any) => {
              const layer = event.layer
              editLayer.clearLayers()
              editLayer.addLayer(layer)

              if (event.layerType === "polygon") {
                const latLngs = layer.getLatLngs()[0]
                const coordinates = latLngs.map((latLng: L.LatLng) => [latLng.lng, latLng.lat] as [number, number])
                onPolygonChange?.(coordinates)
              } else if (event.layerType === "circle") {
                const center = layer.getLatLng()
                const radius = layer.getRadius() / 1000 // Конвертируем в километры
                onCenterChange?.(center.lat, center.lng)
                onRadiusChange?.(radius)
              }
            })

            map.on(L.Draw.Event.EDITED, (event: any) => {
              const layers = event.layers
              layers.eachLayer((layer: any) => {
                if (layer instanceof L.Polygon) {
                  const latLngs = layer.getLatLngs()[0]
                  const coordinates = latLngs.map((latLng: L.LatLng) => [latLng.lng, latLng.lat] as [number, number])
                  onPolygonChange?.(coordinates)
                } else if (layer instanceof L.Circle) {
                  const center = layer.getLatLng()
                  const radius = layer.getRadius() / 1000 // Конвертируем в километры
                  onCenterChange?.(center.lat, center.lng)
                  onRadiusChange?.(radius)
                }
              })
            })

            map.on(L.Draw.Event.DELETED, () => {
              if (editingZoneId) {
                // Если удаляем полигон, очищаем данные
                onPolygonChange?.([])
                // Если удаляем круг, очищаем данные о центре и радиусе
                onCenterChange?.(0, 0)
                onRadiusChange?.(0)
              }
            })
          }

          setMapInitialized(true)
        }
      })
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove()
        mapRef.current = null
      }
    }
  }, [editable, onPolygonChange, onCenterChange, onRadiusChange, editingZoneId, storeCoordinates])

  // Отображение зон доставки на карте
  useEffect(() => {
    if (mapInitialized && mapRef.current && zonesLayerRef.current) {
      const map = mapRef.current
      const zonesLayer = zonesLayerRef.current
      const editLayer = editLayerRef.current

      // Очищаем слои
      zonesLayer.clearLayers()
      if (editLayer) {
        editLayer.clearLayers()
      }

      // Границы для автоматического масштабирования карты
      const bounds = L.latLngBounds([])
      let hasVisibleZones = false

      // Добавляем зоны на карту
      zones.forEach((zone) => {
        // Если зона имеет полигон
        if (zone.polygon && zone.polygon.length > 0) {
          const latLngs = (zone.polygon as [number, number][]).map((coord) => L.latLng(coord[1], coord[0]))

          // Расширяем границы
          latLngs.forEach((latLng) => bounds.extend(latLng))
          hasVisibleZones = true

          // Создаем полигон
          const polygon = L.polygon(latLngs, {
            color: zone.id === editingZoneId ? "#ff3333" : "#3388ff",
            weight: 2,
            opacity: 0.7,
            fillOpacity: 0.2,
          })

          // Добавляем всплывающую подсказку
          polygon.bindTooltip(zone.name)

          // Добавляем полигон на соответствующий слой
          if (zone.id === editingZoneId && editLayer) {
            editLayer.addLayer(polygon)
          } else {
            zonesLayer.addLayer(polygon)
          }
        }

        // Если зона имеет центр и радиус
        if (zone.center_lat && zone.center_lng && zone.radius) {
          const center = L.latLng(zone.center_lat, zone.center_lng)
          bounds.extend(center)
          hasVisibleZones = true

          // Создаем круг (радиус в метрах)
          const circle = L.circle(center, {
            radius: zone.radius * 1000, // Конвертируем километры в метры
            color: zone.id === editingZoneId ? "#ff3333" : "#3388ff",
            weight: 2,
            opacity: 0.7,
            fillOpacity: 0.2,
          })

          // Добавляем всплывающую подсказку
          circle.bindTooltip(zone.name)

          // Добавляем круг на соответствующий слой
          if (zone.id === editingZoneId && editLayer) {
            editLayer.addLayer(circle)
          } else {
            zonesLayer.addLayer(circle)
          }
        }
      })

      // Устанавливаем границы карты, если есть видимые зоны
      if (hasVisibleZones && !bounds.isEmpty()) {
        map.fitBounds(bounds, { padding: [50, 50] })
      }
    }
  }, [zones, mapInitialized, editingZoneId])

  return (
    <div className="relative w-full" style={{ height }}>
      <div id="delivery-zones-map" className="w-full h-full rounded-md overflow-hidden"></div>
      <CustomMapAttribution />
    </div>
  )
}

// Экспортируем компонент как дефолтный экспорт
export default DeliveryZonesMap
