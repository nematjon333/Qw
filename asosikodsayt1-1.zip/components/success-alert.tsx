import { CheckCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface SuccessAlertProps {
  title?: string
  message: string
}

export function SuccessAlert({ title = "Успешно", message }: SuccessAlertProps) {
  return (
    <Alert variant="success" className="bg-green-50 border-green-600 text-green-800">
      <CheckCircle className="h-4 w-4" />
      <AlertTitle>{title}</AlertTitle>
      <AlertDescription>{message}</AlertDescription>
    </Alert>
  )
}
