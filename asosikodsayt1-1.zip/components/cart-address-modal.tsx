"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { MapPin, Loader2 } from "lucide-react"
import DeliveryMap from "@/components/delivery-map/delivery-map"
import { DeliveryInfoCard } from "@/components/delivery-info-card"

interface CartAddressModalProps {
  onAddressSelect: (address: string, coordinates: [number, number]) => void
  initialAddress?: string
  initialCoordinates?: [number, number]
}

export function CartAddressModal({ onAddressSelect, initialAddress, initialCoordinates }: CartAddressModalProps) {
  const [open, setOpen] = useState(false)
  const [selectedAddress, setSelectedAddress] = useState<any>(null)
  const [selectedCoordinates, setSelectedCoordinates] = useState<[number, number] | null>(initialCoordinates || null)
  const [deliveryInfo, setDeliveryInfo] = useState<any>(null)
  const [isLoadingDeliveryInfo, setIsLoadingDeliveryInfo] = useState(false)
  const [deliveryError, setDeliveryError] = useState<string | null>(null)

  // Функция для расчета стоимости доставки
  const fetchDeliveryInfo = async (coordinates: [number, number], distance: number) => {
    try {
      setIsLoadingDeliveryInfo(true)
      setDeliveryError(null)

      const response = await fetch("/api/delivery-zones/calculate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          latitude: coordinates[0],
          longitude: coordinates[1],
          distance: distance,
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      const data = await response.json()
      setDeliveryInfo(data)
      return data
    } catch (error) {
      console.error("Error fetching delivery info:", error)
      setDeliveryError("Не удалось рассчитать стоимость доставки")
      return null
    } finally {
      setIsLoadingDeliveryInfo(false)
    }
  }

  // Обработчик выбора адреса
  const handleAddressSelect = async (address: any, coordinates: [number, number], distance: number) => {
    setSelectedAddress(address)
    setSelectedCoordinates(coordinates)
    await fetchDeliveryInfo(coordinates, distance)
  }

  // Обработчик сохранения адреса
  const handleSaveAddress = () => {
    if (selectedAddress && selectedCoordinates) {
      const addressValue = typeof selectedAddress === "string" ? selectedAddress : selectedAddress.value || ""
      onAddressSelect(addressValue, selectedCoordinates)
      setOpen(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full justify-start">
          <MapPin className="mr-2 h-4 w-4" />
          {initialAddress || "Выбрать адрес доставки"}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Выберите адрес доставки</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <DeliveryMap
            onAddressSelect={handleAddressSelect}
            initialAddress={initialAddress}
            initialCoordinates={initialCoordinates}
          />

          {(selectedAddress || isLoadingDeliveryInfo || deliveryError) && (
            <DeliveryInfoCard deliveryInfo={deliveryInfo} isLoading={isLoadingDeliveryInfo} error={deliveryError} />
          )}

          <div className="flex justify-end">
            <Button
              onClick={handleSaveAddress}
              disabled={!selectedAddress || !selectedCoordinates || isLoadingDeliveryInfo}
              className="bg-green-600 hover:bg-green-700"
            >
              {isLoadingDeliveryInfo ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Загрузка...
                </>
              ) : (
                "Сохранить адрес"
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
