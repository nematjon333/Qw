"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ImageSliderProps {
  images: string[]
  interval?: number
  autoPlay?: boolean
}

export function ImageSlider({ images, interval = 3000, autoPlay = true }: ImageSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isHovering, setIsHovering] = useState(false)
  const [isTouching, setIsTouching] = useState(false)
  const [touchStart, setTouchStart] = useState(0)
  const [imagesLoaded, setImagesLoaded] = useState<boolean[]>([])
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  // Инициализация состояния загрузки изображений
  useEffect(() => {
    setImagesLoaded(new Array(images.length).fill(false))
  }, [images.length])

  const goToNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex === images.length - 1 ? 0 : prevIndex + 1))
  }

  const goToPrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? images.length - 1 : prevIndex - 1))
  }

  const goToSlide = (index: number) => {
    setCurrentIndex(index)
  }

  const handleImageLoad = (index: number) => {
    setImagesLoaded((prev) => {
      const newState = [...prev]
      newState[index] = true
      return newState
    })
  }

  // Handle touch events for mobile swipe
  const handleTouchStart = (event: React.TouchEvent) => {
    if (event.touches && event.touches.length > 0) {
      setIsTouching(true)
      setTouchStart(event.touches[0].clientX)
    }
  }

  const handleTouchMove = (event: React.TouchEvent) => {
    if (!isTouching || !event.touches || event.touches.length === 0) return

    const touchEnd = event.touches[0].clientX
    const diff = touchStart - touchEnd

    // Swipe threshold
    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        // Swipe left, go next
        goToNext()
      } else {
        // Swipe right, go previous
        goToPrevious()
      }
      setIsTouching(false)
    }
  }

  const handleTouchEnd = () => {
    setIsTouching(false)
  }

  useEffect(() => {
    if (autoPlay && !isHovering && !isTouching) {
      timerRef.current = setInterval(goToNext, interval)
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [autoPlay, interval, isHovering, isTouching, images.length])

  if (!images || images.length === 0) {
    return null
  }

  return (
    <div
      className="relative overflow-hidden rounded-xl"
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div
        className="flex transition-transform duration-500 ease-out h-[300px] sm:h-[400px] md:h-[500px]"
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
      >
        {images.map((image, index) => (
          <div key={index} className="min-w-full h-full relative">
            {!imagesLoaded[index] && <div className="absolute inset-0 bg-gray-200 dark:bg-gray-800 animate-pulse" />}
            <Image
              src={image || "/placeholder.svg?height=500&width=800"}
              alt={`Slide ${index + 1}`}
              fill
              sizes="(max-width: 640px) 100vw, (max-width: 768px) 80vw, 70vw"
              className={cn(
                "object-cover transition-opacity duration-300",
                imagesLoaded[index] ? "opacity-100" : "opacity-0",
              )}
              onLoad={() => handleImageLoad(index)}
              onError={() => handleImageLoad(index)}
              priority={index === 0 || index === currentIndex}
              loading={index === 0 || index === currentIndex ? "eager" : "lazy"}
            />
            <div className="absolute inset-0 bg-black bg-opacity-20"></div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows - Hidden on small screens, visible on hover for larger screens */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-2 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/80 hover:bg-white text-gray-700 shadow-md z-10 hidden sm:flex items-center justify-center"
        onClick={() => goToPrevious()}
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/80 hover:bg-white text-gray-700 shadow-md z-10 hidden sm:flex items-center justify-center"
        onClick={() => goToNext()}
        aria-label="Next slide"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      {/* Dots Indicator */}
      <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
        {images.map((_, index) => (
          <button
            key={index}
            className={cn(
              "h-2 rounded-full transition-all",
              index === currentIndex ? "w-6 bg-white" : "w-2 bg-white/60",
            )}
            onClick={() => goToSlide(index)}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
