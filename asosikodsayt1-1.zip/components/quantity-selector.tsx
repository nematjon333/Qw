"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Minus, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface QuantitySelectorProps {
  initialValue?: number
  min?: number
  max?: number
  step?: number
  unit?: string
  onChange: (value: number) => void
  disabled?: boolean
}

export function QuantitySelector({
  initialValue = 1,
  min = 1,
  max = 10,
  step = 1,
  unit = "кг",
  onChange,
  disabled = false,
}: QuantitySelectorProps) {
  const [value, setValue] = useState<number>(initialValue)
  const [inputValue, setInputValue] = useState<string>(initialValue.toString())

  useEffect(() => {
    // Обновляем значение при изменении initialValue
    setValue(initialValue)
    setInputValue(formatValue(initialValue))
  }, [initialValue])

  const formatValue = (val: number): string => {
    // Форматируем число в зависимости от шага
    if (step >= 1) {
      return val.toFixed(0)
    } else if (step >= 0.1) {
      return val.toFixed(1)
    } else {
      return val.toFixed(2)
    }
  }

  const increment = () => {
    if (disabled) return

    const newValue = Math.min(max, value + step)
    setValue(newValue)
    setInputValue(formatValue(newValue))
    onChange(newValue)
  }

  const decrement = () => {
    if (disabled) return

    const newValue = Math.max(min, value - step)
    setValue(newValue)
    setInputValue(formatValue(newValue))
    onChange(newValue)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (disabled) return

    const inputVal = e.target.value
    setInputValue(inputVal)

    // Проверяем, является ли введенное значение числом
    const numValue = Number.parseFloat(inputVal.replace(",", "."))
    if (!isNaN(numValue)) {
      // Ограничиваем значение в пределах min и max
      const constrainedValue = Math.max(min, Math.min(max, numValue))
      setValue(constrainedValue)
      onChange(constrainedValue)
    }
  }

  const handleBlur = () => {
    if (disabled) return

    // При потере фокуса проверяем валидность значения
    const numValue = Number.parseFloat(inputValue.replace(",", "."))
    if (isNaN(numValue)) {
      // Если введено не число, возвращаем предыдущее значение
      setInputValue(formatValue(value))
    } else {
      // Ограничиваем значение в пределах min и max
      const constrainedValue = Math.max(min, Math.min(max, numValue))
      setValue(constrainedValue)
      setInputValue(formatValue(constrainedValue))
      onChange(constrainedValue)
    }
  }

  return (
    <div className="flex items-center">
      <div className="flex items-center rounded-md border">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 rounded-r-none"
          onClick={decrement}
          disabled={disabled || value <= min}
        >
          <Minus className="h-4 w-4" />
        </Button>
        <div className="relative w-16">
          <Input
            type="text"
            value={inputValue}
            onChange={handleInputChange}
            onBlur={handleBlur}
            className="h-9 border-0 text-center"
            aria-label="Количество"
            disabled={disabled}
          />
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9 rounded-l-none"
          onClick={increment}
          disabled={disabled || value >= max}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <span className="ml-2 text-sm text-gray-500">{unit}</span>
    </div>
  )
}
