"use client"

import { useState, useEffect } from "react"
import { Download, ArrowDown, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface PWAHeroBannerProps {
  className?: string
}

export function PWAHeroBanner({ className }: PWAHeroBannerProps) {
  const [showBanner, setShowBanner] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [isIOS, setIsIOS] = useState(false)

  useEffect(() => {
    // Проверяем, был ли баннер уже закрыт или установлен
    const bannerClosed = localStorage.getItem("pwa_hero_closed")
    const bannerInstalled = localStorage.getItem("pwa_installed")

    if (bannerClosed || bannerInstalled) {
      return
    }

    // Определяем iOS устройства
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream
    setIsIOS(isIOSDevice)

    // Для не-iOS устройств используем стандартный механизм PWA
    if (!isIOSDevice) {
      const handleBeforeInstallPrompt = (e: Event) => {
        // Предотвращаем показ стандартного баннера браузера
        e.preventDefault()
        // Сохраняем событие, чтобы использовать его позже
        setDeferredPrompt(e)
        // Показываем наш баннер
        setShowBanner(true)
      }

      window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

      return () => {
        window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
      }
    } else {
      // Для iOS просто показываем баннер с инструкциями
      // Проверяем, запущено ли приложение в режиме standalone (уже установлено)
      const isStandalone = "standalone" in window.navigator && (window.navigator as any).standalone === true
      if (!isStandalone) {
        setShowBanner(true)
      }
    }
  }, [])

  const handleAddToHomeScreen = async () => {
    if (isIOS) {
      // Для iOS просто показываем инструкции
      return
    }

    if (!deferredPrompt) return

    // Показываем диалог установки
    deferredPrompt.prompt()

    // Ждем ответа пользователя
    const { outcome } = await deferredPrompt.userChoice
    console.log(`User response: ${outcome}`)

    if (outcome === "accepted") {
      localStorage.setItem("pwa_installed", "true")
    }

    // Очищаем сохраненное событие
    setDeferredPrompt(null)
    // Скрываем баннер
    setShowBanner(false)
  }

  const handleClose = () => {
    setShowBanner(false)
    // Запоминаем, что пользователь закрыл баннер
    localStorage.setItem("pwa_hero_closed", "true")
  }

  if (!showBanner) return null

  return (
    <div
      className={cn(
        "w-full rounded-lg overflow-hidden mb-6 bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900/50 dark:to-green-800/50 border border-green-100 dark:border-green-800",
        className,
      )}
    >
      <div className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="flex-shrink-0 bg-green-100 dark:bg-green-800 rounded-full p-3">
            <Download className="h-8 w-8 text-green-600 dark:text-green-400" />
          </div>

          <div className="flex-1 text-center sm:text-left">
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Установите наше приложение</h3>

            {isIOS ? (
              <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                Нажмите <ArrowDown className="inline h-3 w-3 mx-1" /> и выберите{" "}
                <Plus className="inline h-3 w-3 mx-1" /> "На экран «‎Домой»"
              </p>
            ) : (
              <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                Быстрый доступ к свежим продуктам прямо с вашего домашнего экрана
              </p>
            )}
          </div>

          <div className="flex gap-2">
            {!isIOS && (
              <Button className="bg-green-600 hover:bg-green-700 text-white" onClick={handleAddToHomeScreen}>
                Установить
              </Button>
            )}
            <Button variant="outline" onClick={handleClose}>
              {isIOS ? "Понятно" : "Не сейчас"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
