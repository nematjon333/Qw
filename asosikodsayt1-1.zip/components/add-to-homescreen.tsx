"use client"

import { PWABanner } from "@/components/pwa-banner"

export function AddToHomescreen() {
  return <PWABanner />
}
