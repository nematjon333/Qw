"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, ShoppingBag, Home, Package, Truck, Info, Phone, Search, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useCart } from "@/context/cart-context"
import { useFavorites } from "@/context/favorites-context"

export function MobileMenu() {
  const [open, setOpen] = useState(false)
  const { itemCount } = useCart()
  const { itemCount: favoritesCount } = useFavorites()

  const closeMenu = () => setOpen(false)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Открыть меню</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[400px]">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between py-4">
            <span className="text-lg font-bold">Меню</span>
            <Button variant="ghost" size="icon" onClick={closeMenu}>
              <X className="h-5 w-5" />
              <span className="sr-only">Закрыть меню</span>
            </Button>
          </div>
          <nav className="flex-1">
            <ul className="space-y-2">
              <li>
                <Link
                  href="/"
                  className="flex items-center gap-3 rounded-md px-3 py-2 hover:bg-gray-100"
                  onClick={closeMenu}
                >
                  <Home className="h-5 w-5 text-green-600" />
                  <span>Главная</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/catalog"
                  className="flex items-center gap-3 rounded-md px-3 py-2 hover:bg-gray-100"
                  onClick={closeMenu}
                >
                  <Package className="h-5 w-5 text-green-600" />
                  <span>Каталог</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/favorites"
                  className="flex items-center gap-3 rounded-md px-3 py-2 hover:bg-gray-100"
                  onClick={closeMenu}
                >
                  <Heart className="h-5 w-5 text-green-600" />
                  <span>Избранное</span>
                  {favoritesCount > 0 && (
                    <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full bg-green-100 text-xs font-medium text-green-600">
                      {favoritesCount}
                    </span>
                  )}
                </Link>
              </li>
              <li>
                <Link
                  href="/delivery"
                  className="flex items-center gap-3 rounded-md px-3 py-2 hover:bg-gray-100"
                  onClick={closeMenu}
                >
                  <Truck className="h-5 w-5 text-green-600" />
                  <span>Доставка</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/track"
                  className="flex items-center gap-3 rounded-md px-3 py-2 hover:bg-gray-100"
                  onClick={closeMenu}
                >
                  <Search className="h-5 w-5 text-green-600" />
                  <span>Отследить заказ</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/about"
                  className="flex items-center gap-3 rounded-md px-3 py-2 hover:bg-gray-100"
                  onClick={closeMenu}
                >
                  <Info className="h-5 w-5 text-green-600" />
                  <span>О нас</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/contacts"
                  className="flex items-center gap-3 rounded-md px-3 py-2 hover:bg-gray-100"
                  onClick={closeMenu}
                >
                  <Phone className="h-5 w-5 text-green-600" />
                  <span>Контакты</span>
                </Link>
              </li>
            </ul>
          </nav>
          <div className="border-t py-4">
            <Link
              href="/cart"
              className="flex items-center justify-between rounded-md bg-green-600 px-4 py-2 text-white"
              onClick={closeMenu}
            >
              <span className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5" />
                Корзина
              </span>
              {itemCount > 0 ? (
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white text-sm font-medium text-green-600">
                  {itemCount > 99 ? "99+" : itemCount}
                </span>
              ) : (
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white text-sm font-medium text-green-600">
                  0
                </span>
              )}
            </Link>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
