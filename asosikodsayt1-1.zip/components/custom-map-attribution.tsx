import { AttributionControl } from "react-leaflet"

interface CustomMapAttributionProps {
  position?: "topleft" | "topright" | "bottomleft" | "bottomright"
}

export function CustomMapAttribution({ position = "bottomright" }: CustomMapAttributionProps) {
  return <AttributionControl position={position} prefix="&copy; <a href='https://olucha-fresh.ru'>OLUCHA Fresh</a>" />
}

// Экспорт по умолчанию для обратной совместимости
export default CustomMapAttribution
