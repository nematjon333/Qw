"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight, Maximize } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ProductFullscreenView } from "@/components/product-fullscreen-view"

interface ProductImageGalleryProps {
  images: string[]
  alt: string
  videos?: string[]
  productName?: string
}

export function ProductImageGallery({ images, alt, videos = [], productName }: ProductImageGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [fullscreenOpen, setFullscreenOpen] = useState(false)
  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)

  // Make sure we have at least one image
  const safeImages = images && images.length > 0 ? images : ["/placeholder.svg?height=600&width=600"]

  // All media combined (images and videos)
  const allMedia = [...safeImages, ...(videos || [])]

  // Determine if current media is a video
  const isVideo = (index: number) => index >= safeImages.length && index < allMedia.length

  // Get current media URL
  const currentMedia = allMedia[currentIndex] || safeImages[0] || "/placeholder.svg?height=600&width=600"

  // Generate SEO-friendly alt text
  const generateAltText = (index: number) => {
    const name = productName || alt
    if (isVideo(index)) {
      return `Видео ${name} - купить в Челябинске с доставкой`
    }
    return `${name} - купить в Челябинске с доставкой${index > 0 ? ` (изображение ${index + 1})` : ""}`
  }

  // Handle next/previous navigation
  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? allMedia.length - 1 : prev - 1))
  }

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === allMedia.length - 1 ? 0 : prev + 1))
  }

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") {
        handlePrevious()
      } else if (e.key === "ArrowRight") {
        handleNext()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  // Handle touch events for swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe) {
      handleNext()
    } else if (isRightSwipe) {
      handlePrevious()
    }

    setTouchStart(null)
    setTouchEnd(null)
  }

  return (
    <div className="product-gallery space-y-4">
      <div
        className="main-image-container relative rounded-lg overflow-hidden bg-gray-100 dark:bg-gray-800"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Main image or video */}
        <div className="aspect-square relative">
          {isVideo(currentIndex) ? (
            <video
              src={currentMedia}
              className="h-full w-full object-cover"
              controls
              autoPlay={false}
              loop
              muted
              aria-label={generateAltText(currentIndex)}
            />
          ) : (
            <img
              src={currentMedia || "/placeholder.svg"}
              alt={generateAltText(currentIndex)}
              className="h-full w-full object-cover"
              loading="eager"
              fetchPriority="high"
            />
          )}

          {/* Navigation arrows - always show them even with single image for better UX */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-2 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/80 text-gray-800 hover:bg-white dark:bg-gray-800/80 dark:text-gray-200 dark:hover:bg-gray-800"
            onClick={handlePrevious}
            aria-label="Предыдущее изображение"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/80 text-gray-800 hover:bg-white dark:bg-gray-800/80 dark:text-gray-200 dark:hover:bg-gray-800"
            onClick={handleNext}
            aria-label="Следующее изображение"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>

          {/* Fullscreen button */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 h-8 w-8 rounded-full bg-white/80 text-gray-800 hover:bg-white dark:bg-gray-800/80 dark:text-gray-200 dark:hover:bg-gray-800"
            onClick={() => setFullscreenOpen(true)}
            aria-label="Открыть на весь экран"
          >
            <Maximize className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Thumbnails */}
      {allMedia.length > 1 && (
        <div className="thumbnails-container flex space-x-2 overflow-x-auto pb-2">
          {allMedia.map((media, index) => (
            <button
              key={index}
              className={`thumbnail-item flex-shrink-0 rounded-md overflow-hidden border-2 transition-all ${
                index === currentIndex ? "border-green-500 dark:border-green-400" : "border-transparent"
              }`}
              onClick={() => setCurrentIndex(index)}
              aria-label={`Изображение ${index + 1}`}
            >
              {isVideo(index) ? (
                <div className="relative h-16 w-16">
                  <video src={media} className="h-full w-full object-cover" muted />
                  <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
                    <div className="h-6 w-6 rounded-full bg-white flex items-center justify-center">
                      <div className="h-0 w-0 border-t-4 border-b-4 border-l-8 border-transparent border-l-gray-800 ml-0.5"></div>
                    </div>
                  </div>
                </div>
              ) : (
                <img
                  src={media || "/placeholder.svg"}
                  alt={`${alt} - миниатюра ${index + 1}`}
                  className="h-16 w-16 object-cover"
                  loading="lazy"
                />
              )}
            </button>
          ))}
        </div>
      )}

      {/* Fullscreen view */}
      <ProductFullscreenView
        isOpen={fullscreenOpen}
        onClose={() => setFullscreenOpen(false)}
        images={safeImages}
        videos={videos}
        initialIndex={currentIndex}
        alt={alt}
        productName={productName}
      />
    </div>
  )
}
