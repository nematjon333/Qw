"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface CategoryCardProps {
  id: string
  name: string
  slug: string
  image: string
  count?: number
  className?: string
}

export function CategoryCard({ id, name, slug, image, count, className }: CategoryCardProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [isHovered, setIsHovered] = useState(false)

  return (
    <Link
      href={`/catalog?category=${slug}`}
      className={cn(
        "group relative block overflow-hidden rounded-lg transition-all duration-300",
        isHovered ? "shadow-lg scale-[1.02]" : "shadow",
        className,
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="aspect-square w-full overflow-hidden">
        {/* Показываем скелетон пока изображение загружается */}
        {isLoading && <div className="absolute inset-0 bg-gray-200 dark:bg-gray-700 animate-pulse" />}

        <Image
          src={image || "/placeholder.svg"}
          alt={name}
          width={300}
          height={300}
          className={cn(
            "h-full w-full object-cover transition-all duration-500",
            isLoading ? "opacity-0" : "opacity-100",
            isHovered ? "scale-110" : "scale-100",
          )}
          onLoad={() => setIsLoading(false)}
          priority
        />
      </div>

      {/* Градиентная подложка для текста */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent opacity-80" />

      <div className="absolute bottom-0 left-0 right-0 p-4">
        <h3 className="text-lg font-semibold text-white">{name}</h3>
        {count !== undefined && <p className="mt-1 text-sm text-white/90">{count} товаров</p>}
      </div>
    </Link>
  )
}
