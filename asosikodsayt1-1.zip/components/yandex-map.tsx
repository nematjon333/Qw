"use client"

import { useEffect, useRef, useState } from "react"
import Script from "next/script"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Loader2 } from "lucide-react"

interface YandexMapProps {
  onAddressSelect?: (address: string, coordinates: [number, number]) => void
  initialAddress?: string
}

export function YandexMap({ onAddressSelect, initialAddress }: YandexMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const [scriptLoaded, setScriptLoaded] = useState(false)
  const [searchQuery, setSearchQuery] = useState(initialAddress || "")
  const [isWithinDeliveryZone, setIsWithinDeliveryZone] = useState(true)
  const [mapInstance, setMapInstance] = useState<any>(null)
  const [searchControl, setSearchControl] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [locationError, setLocationError] = useState<string | null>(null)
  const [apiKey, setApiKey] = useState<string>("")

  const storeCoordinates: [number, number] = [55.17227, 61.431893] // Координаты магазина

  // Fetch API key from server
  useEffect(() => {
    const fetchApiKey = async () => {
      try {
        const response = await fetch("/api/maps/api-key")
        const data = await response.json()
        setApiKey(data.apiKey || "")
      } catch (error) {
        console.error("Error fetching API key:", error)
        setLocationError("Не удалось загрузить ключ API карт")
      }
    }

    fetchApiKey()
  }, [])

  const initMap = () => {
    if (!mapRef.current || !window.ymaps) return

    window.ymaps.ready(() => {
      try {
        // Создаем карту
        const map = new window.ymaps.Map(mapRef.current, {
          center: storeCoordinates,
          zoom: 12,
          controls: ["zoomControl"],
        })

        // Добавляем метку магазина
        const storePoint = new window.ymaps.Placemark(
          storeCoordinates,
          {
            hintContent: "Olucha-fresh",
            balloonContent: "г. Челябинск, ул. Артиллерийская 116/1",
          },
          {
            preset: "islands#greenShoppingIcon",
          },
        )
        map.geoObjects.add(storePoint)

        // Добавляем круг радиуса доставки (10 км)
        const deliveryZone = new window.ymaps.Circle(
          [storeCoordinates, 10000],
          {
            hintContent: "Зона доставки (10 км)",
          },
          {
            fillColor: "#22c55e33",
            strokeColor: "#16a34a",
            strokeWidth: 2,
          },
        )
        map.geoObjects.add(deliveryZone)

        // Добавляем поисковую строку
        const searchControl = new window.ymaps.control.SearchControl({
          options: {
            provider: "yandex#search",
            boundedBy: [
              [55.07227, 61.331893],
              [55.27227, 61.531893],
            ], // Ограничиваем поиск окрестностями Челябинска
            strictBounds: false,
          },
        })
        map.controls.add(searchControl)
        setSearchControl(searchControl)

        // Добавляем маркер для выбранного адреса
        let placemark = null

        // Обработчик клика по карте
        map.events.add("click", (e) => {
          const coords = e.get("coords")

          // Проверяем, находится ли точка в зоне доставки
          const isInZone = deliveryZone.geometry.contains(coords)
          setIsWithinDeliveryZone(isInZone)

          // Удаляем предыдущий маркер, если он есть
          if (placemark) {
            map.geoObjects.remove(placemark)
          }

          // Создаем новый маркер
          placemark = new window.ymaps.Placemark(
            coords,
            {},
            {
              preset: isInZone ? "islands#greenDotIcon" : "islands#redDotIcon",
            },
          )
          map.geoObjects.add(placemark)

          // Получаем адрес по координатам
          window.ymaps.geocode(coords).then((res) => {
            const firstGeoObject = res.geoObjects.get(0)
            const address = firstGeoObject.getAddressLine()
            setSearchQuery(address)

            if (onAddressSelect) {
              onAddressSelect(address, coords)
            }
          })
        })

        setMapInstance(map)
        setMapLoaded(true)
      } catch (error) {
        console.error("Ошибка при инициализации карты:", error)
      }
    })
  }

  const handleSearch = () => {
    if (!searchControl || !mapInstance) return

    setIsLoading(true)
    setLocationError(null)

    searchControl
      .search(searchQuery)
      .then((res: any) => {
        if (res.geoObjects.getLength() > 0) {
          const firstResult = res.geoObjects.get(0)
          const coords = firstResult.geometry.getCoordinates()

          // Проверяем, находится ли точка в зоне доставки
          const deliveryZone = mapInstance.geoObjects.get(1) // Второй объект - это круг зоны доставки
          const isInZone = deliveryZone.geometry.contains(coords)
          setIsWithinDeliveryZone(isInZone)

          // Удаляем предыдущий маркер, если он есть
          const existingPlacemark = mapInstance.geoObjects.get(2)
          if (existingPlacemark && existingPlacemark !== mapInstance.geoObjects.get(0)) {
            mapInstance.geoObjects.remove(existingPlacemark)
          }

          // Создаем новый маркер
          const placemark = new window.ymaps.Placemark(
            coords,
            {},
            {
              preset: isInZone ? "islands#greenDotIcon" : "islands#redDotIcon",
            },
          )
          mapInstance.geoObjects.add(placemark)

          if (isInZone && onAddressSelect) {
            onAddressSelect(firstResult.getAddressLine(), coords)
          }

          mapInstance.setCenter(coords, 15)
        } else {
          setLocationError("Адрес не найден. Пожалуйста, уточните запрос.")
        }
        setIsLoading(false)
      })
      .catch((error) => {
        console.error("Ошибка при поиске:", error)
        setLocationError("Произошла ошибка при поиске адреса")
        setIsLoading(false)
      })
  }

  const handleUseMyLocation = () => {
    if (!navigator.geolocation || !mapInstance) {
      setLocationError("Геолокация не поддерживается вашим браузером")
      return
    }

    setIsLoading(true)
    setLocationError(null)

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coords: [number, number] = [position.coords.latitude, position.coords.longitude]

        // Проверяем, находится ли точка в зоне доставки
        const deliveryZone = mapInstance.geoObjects.get(1) // Второй объект - это круг зоны доставки
        const isInZone = deliveryZone.geometry.contains(coords)
        setIsWithinDeliveryZone(isInZone)

        // Удаляем предыдущий маркер, если он есть
        const existingPlacemark = mapInstance.geoObjects.get(2)
        if (existingPlacemark && existingPlacemark !== mapInstance.geoObjects.get(0)) {
          mapInstance.geoObjects.remove(existingPlacemark)
        }

        // Создаем новый маркер
        const placemark = new window.ymaps.Placemark(
          coords,
          {},
          {
            preset: isInZone ? "islands#greenDotIcon" : "islands#redDotIcon",
          },
        )
        mapInstance.geoObjects.add(placemark)

        // Получаем адрес по координатам
        window.ymaps
          .geocode(coords)
          .then((res) => {
            const firstGeoObject = res.geoObjects.get(0)
            const address = firstGeoObject.getAddressLine()
            setSearchQuery(address)

            if (isInZone && onAddressSelect) {
              onAddressSelect(address, coords)
            }

            mapInstance.setCenter(coords, 15)
            setIsLoading(false)
          })
          .catch((error) => {
            console.error("Ошибка при получении адреса:", error)
            setLocationError("Не удалось определить адрес")
            setIsLoading(false)
          })
      },
      (error) => {
        console.error("Ошибка получения геолокации:", error)
        let errorMessage = "Не удалось определить ваше местоположение"

        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Доступ к геолокации запрещен. Пожалуйста, разрешите доступ к вашему местоположению."
            break
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Информация о вашем местоположении недоступна."
            break
          case error.TIMEOUT:
            errorMessage = "Истекло время ожидания при определении местоположения."
            break
        }

        setLocationError(errorMessage)
        setIsLoading(false)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    )
  }

  useEffect(() => {
    if (scriptLoaded && mapRef.current) {
      initMap()
    }
  }, [scriptLoaded])

  useEffect(() => {
    if (mapLoaded && initialAddress && searchControl) {
      searchControl.search(initialAddress)
    }
  }, [mapLoaded, initialAddress, searchControl])

  return (
    <div className="space-y-4">
      {apiKey && (
        <Script
          src={`https://api-maps.yandex.ru/2.1/?apikey=${apiKey}&lang=ru_RU`}
          onLoad={() => setScriptLoaded(true)}
          onError={() => setLocationError("Не удалось загрузить карту")}
        />
      )}

      <div className="flex flex-col gap-2 sm:flex-row">
        <Input
          placeholder="Введите адрес доставки"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
          disabled={isLoading}
        />
        <Button onClick={handleSearch} className="bg-green-600 hover:bg-green-700" disabled={isLoading}>
          {isLoading ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Поиск...
            </span>
          ) : (
            "Найти"
          )}
        </Button>
        <Button
          onClick={handleUseMyLocation}
          variant="outline"
          className="border-green-600 text-green-600 hover:bg-green-50"
          disabled={isLoading}
        >
          {isLoading ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Определение...
            </span>
          ) : (
            "Моё местоположение"
          )}
        </Button>
      </div>

      {locationError && <div className="rounded-lg bg-red-50 p-3 text-red-600 text-sm">{locationError}</div>}

      <div ref={mapRef} className="h-[300px] w-full rounded-lg border"></div>

      {!isWithinDeliveryZone && (
        <div className="rounded-lg bg-red-50 p-4 text-red-600">
          <p className="font-medium">Доставка по указанному адресу недоступна</p>
          <p className="text-sm">К сожалению, ваш адрес находится за пределами зоны доставки (10 км от магазина).</p>
          <p className="text-sm">
            Вы можете связаться с нами по телефону:{" "}
            <a href="tel:+79048179762" className="font-medium">
              +7 (904) 817-97-62
            </a>
          </p>
        </div>
      )}
    </div>
  )
}
