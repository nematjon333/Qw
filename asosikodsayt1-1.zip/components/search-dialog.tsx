"use client"

import { useState } from "react"
import { Search, X, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { useCart } from "@/context/cart-context"
import { toast } from "@/components/ui/use-toast"

// Демо-товары для поиска
const demoProducts = [
  {
    id: "1",
    name: "Яблоки Голден",
    price: 159,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    discount: 15,
    category: "fruits",
  },
  {
    id: "2",
    name: "Бананы",
    price: 129,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    category: "fruits",
  },
  {
    id: "3",
    name: "Апельсины",
    price: 189,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    discount: 10,
    category: "fruits",
  },
  {
    id: "4",
    name: "Огурцы",
    price: 199,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    category: "vegetables",
  },
  {
    id: "5",
    name: "Помидоры",
    price: 249,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    discount: 20,
    category: "vegetables",
  },
  {
    id: "6",
    name: "Курага",
    price: 399,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    category: "dried-fruits",
  },
  {
    id: "7",
    name: "Сок апельсиновый",
    price: 159,
    image: "/placeholder.svg?height=200&width=200",
    unit: "л",
    category: "beverages",
  },
  {
    id: "8",
    name: "Чернослив",
    price: 459,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    discount: 5,
    category: "dried-fruits",
  },
]

export function SearchDialog() {
  const [open, setOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState([])
  const [isSearching, setIsSearching] = useState(false)
  const { addItem } = useCart()

  // Функция поиска товаров
  const searchProducts = async (query) => {
    setIsSearching(true)

    try {
      // В реальном приложении здесь был бы запрос к API
      // Имитируем задержку запроса
      await new Promise((resolve) => setTimeout(resolve, 300))

      // Фильтруем товары по запросу
      const results = demoProducts.filter(
        (product) =>
          product.name.toLowerCase().includes(query.toLowerCase()) ||
          product.category.toLowerCase().includes(query.toLowerCase()),
      )

      setSearchResults(results)
    } catch (error) {
      console.error("Ошибка при поиске товаров:", error)
      setSearchResults([])
    } finally {
      setIsSearching(false)
    }
  }

  // Обработчик изменения поискового запроса
  const handleSearchChange = (e) => {
    const query = e.target.value
    setSearchQuery(query)

    if (query.length >= 2) {
      searchProducts(query)
    } else {
      setSearchResults([])
    }
  }

  // Обработчик добавления товара в корзину
  const handleAddToCart = (product, e) => {
    e.preventDefault()
    e.stopPropagation()

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      unit: product.unit,
      discount: product.discount,
      quantity: 1,
    })

    toast({
      title: "Товар добавлен в корзину",
      description: `${product.name} (1 ${product.unit})`,
      duration: 3000,
      variant: "success",
    })

    setOpen(false)
  }

  // Обработчик закрытия диалога
  const handleClose = () => {
    setOpen(false)
    setSearchQuery("")
    setSearchResults([])
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Search className="h-4 w-4" />
          <span className="hidden sm:inline">Поиск</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <div className="flex items-center gap-2">
          <Search className="h-5 w-5 text-gray-500" />
          <Input
            placeholder="Поиск товаров..."
            className="flex-1"
            value={searchQuery}
            onChange={handleSearchChange}
            autoFocus
          />
          <Button variant="ghost" size="icon" onClick={handleClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="mt-4 max-h-[400px] overflow-y-auto">
          {isSearching ? (
            <div className="flex justify-center py-8">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-current border-t-transparent text-green-600" />
            </div>
          ) : searchResults.length > 0 ? (
            <div className="space-y-2">
              {searchResults.map((product) => {
                const discountedPrice = product.discount
                  ? product.price - (product.price * product.discount) / 100
                  : null

                return (
                  <Link
                    key={product.id}
                    href={`/product/${product.id}`}
                    className="flex items-center gap-4 rounded-lg border p-3 hover:bg-gray-50 transition-colors"
                    onClick={handleClose}
                  >
                    <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-md">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{product.name}</h3>
                      <div className="flex items-baseline gap-2">
                        {discountedPrice ? (
                          <>
                            <span className="font-medium">{discountedPrice.toFixed(0)} ₽</span>
                            <span className="text-sm text-gray-500 line-through">{product.price.toFixed(0)} ₽</span>
                          </>
                        ) : (
                          <span className="font-medium">{product.price.toFixed(0)} ₽</span>
                        )}
                        <span className="text-sm text-gray-500">за {product.unit}</span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      className="bg-green-600 hover:bg-green-700"
                      onClick={(e) => handleAddToCart(product, e)}
                    >
                      <ShoppingCart className="h-4 w-4" />
                    </Button>
                  </Link>
                )
              })}
            </div>
          ) : searchQuery.length >= 2 ? (
            <div className="py-8 text-center text-gray-500">
              <p>По запросу "{searchQuery}" ничего не найдено</p>
              <p className="mt-2 text-sm">Попробуйте изменить запрос или перейти в каталог</p>
              <Button asChild className="mt-4 bg-green-600 hover:bg-green-700">
                <Link href="/catalog" onClick={handleClose}>
                  Перейти в каталог
                </Link>
              </Button>
            </div>
          ) : searchQuery.length > 0 ? (
            <div className="py-8 text-center text-gray-500">
              <p>Введите не менее 2 символов для поиска</p>
            </div>
          ) : (
            <div className="py-8 text-center text-gray-500">
              <p>Введите название товара для поиска</p>
              <p className="mt-2 text-sm">Например: яблоки, бананы, сок</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
