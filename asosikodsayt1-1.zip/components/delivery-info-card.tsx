import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { AlertCircle, MapPin, Zap, Info } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface DeliveryInfoCardProps {
  deliveryInfo: any
  isLoading?: boolean
  error?: string | null
  className?: string
}

export function DeliveryInfoCard({ deliveryInfo, isLoading, error, className = "" }: DeliveryInfoCardProps) {
  if (isLoading) {
    return (
      <Card className={`w-full ${className}`}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center">
            <Skeleton className="h-5 w-5 mr-2 rounded-full" />
            <Skeleton className="h-6 w-40" />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive" className={`w-full ${className}`}>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (!deliveryInfo || !deliveryInfo.isDeliveryAvailable) {
    return (
      <Card className={`w-full ${className}`}>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center text-amber-600 dark:text-amber-400">
            <AlertCircle className="h-5 w-5 mr-2" />
            Информация о доставке
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 dark:text-gray-400">
            {deliveryInfo?.message || "Доставка по этому адресу недоступна"}
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={`w-full ${className}`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center text-green-600 dark:text-green-400">
          <MapPin className="h-5 w-5 mr-2" />
          Информация о доставке
          {deliveryInfo.zoneName && (
            <Badge variant="outline" className="ml-2 font-normal">
              {deliveryInfo.zoneName}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-gray-600 dark:text-gray-400 mr-2">Стоимость доставки:</span>
            {deliveryInfo.isSurgeActive && <Zap className="h-4 w-4 text-amber-500 mr-1" />}
          </div>
          <span className="font-medium">
            {deliveryInfo.fee === 0 ? (
              <span className="text-green-600 dark:text-green-400">Бесплатно</span>
            ) : (
              `${deliveryInfo.fee} ₽`
            )}
          </span>
        </div>

        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-gray-600 dark:text-gray-400 mr-2">Время доставки:</span>
          </div>
          <span className="font-medium flex items-center">
            ~{deliveryInfo.estimatedTime}
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-4 w-4 ml-1 text-gray-400 cursor-help" />
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs text-xs">
                    Это примерное время доставки. Фактическое время может увеличиться в зависимости от погодных условий,
                    загруженности дорог и других факторов.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </span>
        </div>

        {deliveryInfo.minOrderAmount > 0 && (
          <div className="flex justify-between items-center">
            <span className="text-gray-600 dark:text-gray-400">Минимальная сумма заказа:</span>
            <span className="font-medium">{deliveryInfo.minOrderAmount} ₽</span>
          </div>
        )}

        {deliveryInfo.freeDeliveryThreshold && (
          <div className="flex justify-between items-center">
            <span className="text-gray-600 dark:text-gray-400">Бесплатная доставка от:</span>
            <span className="font-medium">{deliveryInfo.freeDeliveryThreshold} ₽</span>
          </div>
        )}

        {deliveryInfo.isSurgeActive && deliveryInfo.surgeReason && (
          <div className="mt-2 p-2 bg-amber-100 rounded-md dark:bg-amber-900/30">
            <p className="text-sm text-amber-800 dark:text-amber-300 flex items-center">
              <Zap className="h-4 w-4 mr-1 text-amber-500" />
              {deliveryInfo.surgeReason}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
