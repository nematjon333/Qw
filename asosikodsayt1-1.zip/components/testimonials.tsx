import { Star } from "lucide-react"

const testimonials = [
  {
    id: 1,
    name: "Анна К.",
    avatar: "/placeholder.svg?height=80&width=80",
    rating: 5,
    text: "Очень довольна качеством продуктов. Фрукты всегда свежие, сочные и вкусные. Доставка быстрая, курьеры вежливые. Буду заказывать еще!",
    date: "15 апреля 2025",
  },
  {
    id: 2,
    name: "Дмитрий П.",
    avatar: "/placeholder.svg?height=80&width=80",
    rating: 5,
    text: "Уже несколько месяцев заказываю здесь продукты. Качество всегда на высоте, цены адекватные. Особенно нравится, что доставляют в удобное для меня время.",
    date: "2 апреля 2025",
  },
  {
    id: 3,
    name: "Екатерина В.",
    avatar: "/placeholder.svg?height=80&width=80",
    rating: 4,
    text: "Хороший ассортимент свежих овощей и фруктов. Приятно, что есть раздел с экзотическими фруктами. Иногда балую себя и семью чем-то необычным.",
    date: "28 марта 2025",
  },
]

export function Testimonials() {
  return (
    <section className="reviews-section">
      <div className="container">
        <h2 className="text-3xl font-bold text-center mb-2">Отзывы наших клиентов</h2>
        <p className="text-center text-gray-600 mb-10">Что говорят о нас наши постоянные покупатели</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="review-card hover-effect">
              <div className="review-header">
                <img src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} className="review-avatar" />
                <div>
                  <h3 className="review-author">{testimonial.name}</h3>
                  <p className="review-date">{testimonial.date}</p>
                </div>
              </div>

              <div className="review-rating">
                {Array.from({ length: 5 }).map((_, index) => (
                  <Star key={index} className={`h-4 w-4 ${index < testimonial.rating ? "fill-current" : ""}`} />
                ))}
              </div>

              <p className="review-content mt-3">{testimonial.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
