"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, ShoppingBag, Grid2x2, User } from "lucide-react"
import { useCart } from "@/context/cart-context"
import { useEffect } from "react"

export function MobileBottomMenu() {
  const pathname = usePathname()
  const { itemCount } = useCart()

  // Скролл в начало страницы при переходе
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  // Ensure the menu is visible by adding padding to the main content
  useEffect(() => {
    const addPadding = () => {
      document.body.style.paddingBottom = "70px" // Adjust this value as needed
    }

    addPadding()
    window.addEventListener("resize", addPadding)

    return () => {
      window.removeEventListener("resize", addPadding)
      document.body.style.paddingBottom = ""
    }
  }, [])

  const isActive = (path: string) => {
    return pathname === path
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 md:hidden dark:bg-gray-900 dark:border-gray-800">
      <div className="flex items-center justify-around h-16">
        <Link
          href="/"
          className={`flex flex-col items-center justify-center w-full h-full ${
            isActive("/") ? "text-green-600 dark:text-green-400" : "text-gray-600 dark:text-gray-400"
          }`}
          onClick={() => window.scrollTo(0, 0)}
        >
          <Home className="h-5 w-5" />
          <span className="text-xs mt-1">Главная</span>
        </Link>
        <Link
          href="/catalog"
          className={`flex flex-col items-center justify-center w-full h-full ${
            isActive("/catalog") ? "text-green-600 dark:text-green-400" : "text-gray-600 dark:text-gray-400"
          }`}
          onClick={() => window.scrollTo(0, 0)}
        >
          <Grid2x2 className="h-5 w-5" />
          <span className="text-xs mt-1">Каталог</span>
        </Link>
        <Link
          href="/cart"
          className={`flex flex-col items-center justify-center w-full h-full relative ${
            isActive("/cart") ? "text-green-600 dark:text-green-400" : "text-gray-600 dark:text-gray-400"
          }`}
          onClick={() => window.scrollTo(0, 0)}
        >
          <ShoppingBag className="h-5 w-5" />
          {itemCount > 0 && (
            <span className="absolute top-1 right-[calc(50%-12px)] flex h-4 w-4 items-center justify-center rounded-full bg-green-600 text-[10px] font-medium text-white">
              {itemCount > 99 ? "99+" : itemCount}
            </span>
          )}
          <span className="text-xs mt-1">Корзина</span>
        </Link>
        <Link
          href="/profile"
          className={`flex flex-col items-center justify-center w-full h-full ${
            isActive("/profile") ? "text-green-600 dark:text-green-400" : "text-gray-600 dark:text-gray-400"
          }`}
          onClick={() => window.scrollTo(0, 0)}
        >
          <User className="h-5 w-5" />
          <span className="text-xs mt-1">Профиль</span>
        </Link>
      </div>
    </div>
  )
}
