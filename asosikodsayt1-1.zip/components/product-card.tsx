"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { Heart, Plus, Minus, Check } from "lucide-react"
import { useCart } from "@/context/cart-context"
import { useFavorites } from "@/context/favorites-context"
import { toast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"

// Safe import for analytics
import { ecommerceEvents } from "@/lib/analytics"

interface ProductCardProps {
  id: string
  name: string
  price: number
  image: string
  unit?: string
  discount?: number
  step?: number
  minQuantity?: number
  maxQuantity?: number
  description?: string
  origin?: string
  stockQuantity?: number
}

export function ProductCard({
  id,
  name,
  price,
  image,
  unit = "кг",
  discount,
  step = 1,
  minQuantity = 1,
  maxQuantity = 10,
  description,
  origin,
  stockQuantity = 0,
}: ProductCardProps) {
  const [isAdded, setIsAdded] = useState(false)
  const { addItem, items, updateQuantity, removeItem } = useCart()
  const { addItem: addToFavorites, removeItem: removeFromFavorites, isInFavorites } = useFavorites()
  const discountedPrice = discount ? price - (price * discount) / 100 : null

  // Check if the product is already in the cart
  const cartItem = items.find((item) => item.id === id)
  const isInCart = Boolean(cartItem)

  // Check if the product is in favorites
  const isFavorite = isInFavorites(id)

  // Check if the product is in stock
  const isInStock = stockQuantity > 0

  // Use placeholder for image
  const imageSrc = image || "/placeholder.svg?height=200&width=200"

  // Use ID for product URL
  const productUrl = `/product/${id}`

  const handleAddToCart = (e: React.MouseEvent) => {
    if (e) {
      e.preventDefault()
      e.stopPropagation()
    }

    if (!isInStock) {
      toast({
        title: "Товар недоступен",
        description: "К сожалению, данный товар отсутствует в наличии",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    // Add product to cart with quantity 1 kg
    addItem({
      id,
      name,
      price,
      image,
      unit,
      discount,
      quantity: minQuantity, // Always add minimum quantity
      stockQuantity,
    })

    // Track add to cart event
    try {
      ecommerceEvents.addToCart({
        id,
        name,
        price,
        quantity: minQuantity,
        category: "",
      })
    } catch (error) {
      console.error("Error tracking add to cart event:", error)
    }

    // Show add animation
    setIsAdded(true)
    setTimeout(() => setIsAdded(false), 2000)

    // Show notification
    toast({
      title: "Товар добавлен в корзину",
      description: `${name} (${minQuantity} ${unit})`,
      duration: 3000,
    })
  }

  const handleIncreaseQuantity = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (!isInStock) {
      toast({
        title: "Товар недоступен",
        description: "К сожалению, данный товар отсутствует в наличии",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    if (!cartItem) {
      // If product is not in cart, add it
      addItem({
        id,
        name,
        price,
        image,
        unit,
        discount,
        quantity: minQuantity,
        stockQuantity,
      })
    } else {
      // If product is already in cart, increase quantity
      const newQuantity = Math.min(cartItem.quantity + (step || 1), maxQuantity)
      updateQuantity(id, newQuantity)
    }
  }

  const handleDecreaseQuantity = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (cartItem) {
      if (cartItem.quantity <= minQuantity) {
        // If quantity is minimum or less, remove product from cart
        removeItem(id)
      } else {
        // Otherwise decrease quantity
        updateQuantity(id, cartItem.quantity - (step || 1))
      }
    }
  }

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (isFavorite) {
      removeFromFavorites(id)
      toast({
        title: "Удалено из избранного",
        description: `${name} удален из избранного`,
        duration: 3000,
      })
    } else {
      addToFavorites({
        id,
        name,
        price,
        image,
        unit,
        discount,
      })
      toast({
        title: "Добавлено в избранное",
        description: `${name} добавлен в избранное`,
        duration: 3000,
      })
    }
  }

  return (
    <div className="product-card group relative overflow-hidden rounded-xl bg-white shadow-md transition-all hover:shadow-lg dark:bg-gray-800">
      <Link href={productUrl} className="block">
        <div className="product-image-container relative overflow-hidden pt-[100%]">
          <img
            src={imageSrc || "/placeholder.svg"}
            alt={name}
            className="product-image absolute inset-0 h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
        </div>

        {/* Favorite button */}
        <div className="absolute top-2 right-2">
          <button
            onClick={handleToggleFavorite}
            className={`h-8 w-8 rounded-full flex items-center justify-center transition-colors ${
              isFavorite
                ? "bg-red-100 text-red-500 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400"
                : "bg-white text-gray-500 hover:text-red-500 hover:bg-red-50 dark:bg-gray-700 dark:text-gray-300"
            }`}
            aria-label={isFavorite ? "Удалить из избранного" : "Добавить в избранное"}
          >
            <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
          </button>
        </div>

        {/* Discount badge */}
        {discount && (
          <div className="absolute top-2 left-2">
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-md">-{discount}%</span>
          </div>
        )}

        {/* Out of stock badge */}
        {!isInStock && (
          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
            <span className="bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-md">Нет в наличии</span>
          </div>
        )}

        <div className="product-content p-4">
          <h3 className="product-title text-sm font-medium line-clamp-2 min-h-[2.5rem] dark:text-white">{name}</h3>

          <div className="product-price mt-2 flex items-baseline gap-2">
            {discountedPrice ? (
              <>
                <span className="current-price text-lg font-bold text-green-600 dark:text-green-400">
                  {discountedPrice.toFixed(0)} ₽
                </span>
                <span className="old-price text-sm text-gray-400 line-through">{price.toFixed(0)} ₽</span>
              </>
            ) : (
              <span className="current-price text-lg font-bold text-green-600 dark:text-green-400">
                {price.toFixed(0)} ₽
              </span>
            )}
            <span className="text-xs text-gray-500 dark:text-gray-400">/{unit}</span>
          </div>

          <div className="product-actions mt-3">
            {!isInStock ? (
              <Button
                className="w-full h-10 rounded-full bg-gray-300 hover:bg-gray-400 cursor-not-allowed dark:bg-gray-700 dark:hover:bg-gray-600"
                disabled
              >
                Нет в наличии
              </Button>
            ) : !isInCart ? (
              <Button
                className={`w-full h-10 rounded-full ${isAdded ? "bg-green-700" : "bg-green-600 hover:bg-green-700"}`}
                onClick={handleAddToCart}
              >
                {isAdded ? <Check className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
              </Button>
            ) : (
              <div className="flex items-center justify-between rounded-full overflow-hidden border border-gray-200 dark:border-gray-700">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-l-full"
                  onClick={handleDecreaseQuantity}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="flex-1 text-center font-medium dark:text-white">
                  {cartItem?.quantity.toFixed(step && step < 1 ? 1 : 0)} {unit}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-r-full"
                  onClick={handleIncreaseQuantity}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </Link>
    </div>
  )
}
