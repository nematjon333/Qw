"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CartAddressModal } from "@/components/cart-address-modal"
import { DeliveryInfoCard } from "@/components/delivery-info-card"
import { calculateDistance, STORE_LATITUDE, STORE_LONGITUDE } from "@/lib/dadata-service"

interface DeliveryOptionsProps {
  onDeliveryChange: (type: string, fee: number) => void
  onAddressSelect: (address: string, coordinates: [number, number]) => void
  initialAddress?: string
  initialCoordinates?: [number, number]
}

export function DeliveryOptions({
  onDeliveryChange,
  onAddressSelect,
  initialAddress,
  initialCoordinates,
}: DeliveryOptionsProps) {
  const [deliveryType, setDeliveryType] = useState("delivery")
  const [address, setAddress] = useState(initialAddress || "")
  const [coordinates, setCoordinates] = useState<[number, number] | null>(initialCoordinates || null)
  const [deliveryInfo, setDeliveryInfo] = useState<any>(null)
  const [isLoadingDeliveryInfo, setIsLoadingDeliveryInfo] = useState(false)
  const [deliveryError, setDeliveryError] = useState<string | null>(null)

  // Загрузка сохраненного адреса при монтировании
  useEffect(() => {
    const savedAddress = localStorage.getItem("deliveryAddress")
    if (savedAddress) {
      try {
        const addressData = JSON.parse(savedAddress)
        setAddress(addressData.address || "")
        setCoordinates(addressData.coordinates || null)

        // Если есть координаты, рассчитываем стоимость доставки
        if (addressData.coordinates && addressData.coordinates.length === 2) {
          fetchDeliveryInfo(addressData.coordinates, addressData.distance)
        }
      } catch (error) {
        console.error("Error loading saved address:", error)
      }
    }
  }, [])

  // Функция для расчета стоимости доставки
  const fetchDeliveryInfo = async (coords: [number, number], distance?: number) => {
    try {
      setIsLoadingDeliveryInfo(true)
      setDeliveryError(null)

      // Если расстояние не предоставлено, рассчитываем его
      const calculatedDistance = distance || calculateDistance(STORE_LATITUDE, STORE_LONGITUDE, coords[0], coords[1])

      const response = await fetch("/api/delivery-zones/calculate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          latitude: coords[0],
          longitude: coords[1],
          distance: calculatedDistance,
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      const data = await response.json()
      setDeliveryInfo(data)

      // Обновляем стоимость доставки в родительском компоненте
      if (deliveryType === "delivery") {
        onDeliveryChange("delivery", data.fee || 0)
      }

      return data
    } catch (error) {
      console.error("Error fetching delivery info:", error)
      setDeliveryError("Не удалось рассчитать стоимость доставки")
      return null
    } finally {
      setIsLoadingDeliveryInfo(false)
    }
  }

  // Обработчик изменения типа доставки
  const handleDeliveryTypeChange = (value: string) => {
    setDeliveryType(value)

    // Если выбран самовывоз, устанавливаем стоимость доставки в 0
    if (value === "pickup") {
      onDeliveryChange("pickup", 0)
    } else if (value === "delivery" && deliveryInfo) {
      // Если выбрана доставка и есть информация о доставке, устанавливаем соответствующую стоимость
      onDeliveryChange("delivery", deliveryInfo.fee || 0)
    }
  }

  // Обработчик выбора адреса
  const handleAddressSelect = (selectedAddress: string, selectedCoordinates: [number, number]) => {
    setAddress(selectedAddress)
    setCoordinates(selectedCoordinates)

    // Рассчитываем расстояние
    const distance = calculateDistance(STORE_LATITUDE, STORE_LONGITUDE, selectedCoordinates[0], selectedCoordinates[1])

    // Сохраняем адрес в localStorage
    localStorage.setItem(
      "deliveryAddress",
      JSON.stringify({
        address: selectedAddress,
        coordinates: selectedCoordinates,
        distance,
      }),
    )

    // Рассчитываем стоимость доставки
    fetchDeliveryInfo(selectedCoordinates, distance)

    // Передаем адрес в родительский компонент
    onAddressSelect(selectedAddress, selectedCoordinates)
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Способ получения</CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup value={deliveryType} onValueChange={handleDeliveryTypeChange} className="space-y-4">
          <div className="flex items-start space-x-2">
            <RadioGroupItem value="delivery" id="delivery" className="mt-1" />
            <div className="grid gap-1.5 w-full">
              <Label htmlFor="delivery" className="font-medium">
                Доставка
              </Label>
              {deliveryType === "delivery" && (
                <div className="mt-2 space-y-3">
                  <CartAddressModal
                    onAddressSelect={handleAddressSelect}
                    initialAddress={address}
                    initialCoordinates={coordinates}
                  />

                  {address && coordinates && (
                    <DeliveryInfoCard
                      deliveryInfo={deliveryInfo}
                      isLoading={isLoadingDeliveryInfo}
                      error={deliveryError}
                    />
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-start space-x-2">
            <RadioGroupItem value="pickup" id="pickup" className="mt-1" />
            <div className="grid gap-1.5">
              <Label htmlFor="pickup" className="font-medium">
                Самовывоз
              </Label>
              {deliveryType === "pickup" && (
                <div className="mt-2">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Вы можете забрать заказ по адресу: г. Челябинск, Артиллерийская 116/1
                  </p>
                </div>
              )}
            </div>
          </div>
        </RadioGroup>
      </CardContent>
    </Card>
  )
}
