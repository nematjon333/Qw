"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, ShoppingCart, User, Search, ChevronDown, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useCart } from "@/context/cart-context"
import { MobileMenu } from "@/components/mobile-menu"
import { SearchDialog } from "@/components/search-dialog"
import { ThemeToggle } from "@/components/theme-toggle"
import { Logo } from "@/components/logo"

export function Header() {
  const pathname = usePathname()
  const { items } = useCart()
  const [isScrolled, setIsScrolled] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const cartItemsCount = items.reduce((total, item) => total + item.quantity, 0)

  // Отслеживаем скролл страницы
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Закрываем мобильное меню при изменении пути
  useEffect(() => {
    setIsMobileMenuOpen(false)
  }, [pathname])

  // Проверяем, является ли текущий путь админским
  const isAdminPath = pathname?.startsWith("/admin")

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-200 ${
        isScrolled ? "bg-white/80 backdrop-blur-md shadow-sm dark:bg-gray-950/80" : "bg-white dark:bg-gray-950"
      }`}
    >
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        {/* Мобильное меню */}
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon" aria-label="Меню">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[300px] sm:w-[400px] p-0">
            <MobileMenu onClose={() => setIsMobileMenuOpen(false)} />
          </SheetContent>
        </Sheet>

        {/* Логотип - центрирован на мобильных устройствах */}
        <div className="flex-1 flex justify-start md:justify-start">
          <div className="md:hidden absolute left-1/2 transform -translate-x-1/2">
            <Logo />
          </div>
          <div className="hidden md:block">
            <Logo />
          </div>
        </div>

        {/* Навигация - скрыта на мобильных устройствах */}
        <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
          <Link
            href="/"
            className={`transition-colors hover:text-green-600 dark:hover:text-green-400 ${
              pathname === "/" ? "text-green-600 dark:text-green-400" : "text-gray-600 dark:text-gray-300"
            }`}
          >
            Главная
          </Link>
          <Link
            href="/catalog"
            className={`transition-colors hover:text-green-600 dark:hover:text-green-400 ${
              pathname === "/catalog" ? "text-green-600 dark:text-green-400" : "text-gray-600 dark:text-gray-300"
            }`}
          >
            Каталог
          </Link>
          <Link
            href="/delivery"
            className={`transition-colors hover:text-green-600 dark:hover:text-green-400 ${
              pathname === "/delivery" ? "text-green-600 dark:text-green-400" : "text-gray-600 dark:text-gray-300"
            }`}
          >
            Доставка
          </Link>
          <Link
            href="/contacts"
            className={`transition-colors hover:text-green-600 dark:hover:text-green-400 ${
              pathname === "/contacts" ? "text-green-600 dark:text-green-400" : "text-gray-600 dark:text-gray-300"
            }`}
          >
            Контакты
          </Link>
        </nav>

        {/* Правая часть шапки */}
        <div className="flex items-center space-x-2">
          {/* Поиск */}
          <Button
            variant="ghost"
            size="icon"
            aria-label="Поиск"
            className="text-gray-600 dark:text-gray-300"
            onClick={() => setIsSearchOpen(true)}
          >
            <Search className="h-5 w-5" />
          </Button>

          {/* Переключатель темы */}
          <ThemeToggle />

          {/* Телефон - скрыт на мобильных */}
          <Button variant="ghost" size="icon" className="hidden md:flex text-gray-600 dark:text-gray-300" asChild>
            <a href="tel:+79048179762" aria-label="Позвонить">
              <Phone className="h-5 w-5" />
            </a>
          </Button>

          {/* Профиль - скрыт на мобильных */}
          <Button
            variant="ghost"
            size="icon"
            aria-label="Профиль"
            className="hidden md:flex text-gray-600 dark:text-gray-300"
            asChild
          >
            <Link href="/profile">
              <User className="h-5 w-5" />
            </Link>
          </Button>

          {/* Корзина */}
          <Button
            variant="ghost"
            size="icon"
            aria-label="Корзина"
            className="text-gray-600 dark:text-gray-300 relative"
            asChild
          >
            <Link href="/cart">
              <ShoppingCart className="h-5 w-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-green-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </Link>
          </Button>

          {/* Админ-панель - только для админских путей */}
          {isAdminPath && (
            <div className="hidden md:block">
              <Button variant="outline" size="sm" className="ml-4" asChild>
                <Link href="/admin/dashboard">
                  Админ-панель
                  <ChevronDown className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Диалог поиска */}
      <SearchDialog open={isSearchOpen} onOpenChange={setIsSearchOpen} />
    </header>
  )
}
