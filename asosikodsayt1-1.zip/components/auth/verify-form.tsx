"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, AlertCircle, ArrowLeft } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { formatPhoneNumber } from "@/lib/utils"

interface VerifyFormProps {
  onVerify: (name: string, phone: string, exists: boolean) => void
  onBack?: () => void
}

export function VerifyForm({ onVerify, onBack }: VerifyFormProps) {
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [formattedPhone, setFormattedPhone] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [step, setStep] = useState<"name" | "phone">("name")

  // Форматирование номера телефона при вводе
  useEffect(() => {
    if (phone) {
      // Удаляем все нецифровые символы
      const digitsOnly = phone.replace(/\D/g, "")

      // Если номер начинается с 7 или 8, форматируем его
      if (digitsOnly.startsWith("7") || digitsOnly.startsWith("8")) {
        const formatted = formatPhoneNumber(digitsOnly)
        setFormattedPhone(formatted)
      } else if (digitsOnly.length > 0) {
        // Если номер не начинается с 7 или 8, добавляем 7 в начало
        const withPrefix = "7" + digitsOnly
        const formatted = formatPhoneNumber(withPrefix)
        setFormattedPhone(formatted)
      } else {
        setFormattedPhone("")
      }
    } else {
      setFormattedPhone("")
    }
  }, [phone])

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) {
      setError("Пожалуйста, введите ваше имя")
      return
    }
    setError("")
    setStep("phone")
  }

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Проверка номера телефона
    const digitsOnly = formattedPhone.replace(/\D/g, "")
    if (digitsOnly.length !== 11) {
      setError("Пожалуйста, введите корректный номер телефона")
      return
    }

    try {
      setIsLoading(true)
      setError("")

      // Проверяем, существует ли пользователь с таким номером телефона
      const response = await fetch("/api/users/check", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          phone: formattedPhone,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        // Передаем результат проверки в родительский компонент
        onVerify(name, formattedPhone, data.exists)
      } else {
        setError(data.message || "Ошибка при проверке номера телефона")
      }
    } catch (error) {
      console.error("Ошибка при проверке номера телефона:", error)
      setError("Произошла ошибка при проверке номера телефона")
    } finally {
      setIsLoading(false)
    }
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPhone(e.target.value)
  }

  const handleBackToName = () => {
    setStep("name")
    setError("")
  }

  return (
    <>
      {step === "name" ? (
        <form onSubmit={handleNameSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="name">Ваше имя</Label>
            <Input
              id="name"
              placeholder="Введите ваше имя"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
            />
          </div>

          <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
            Продолжить
          </Button>

          {onBack && (
            <div className="text-center text-sm">
              <button type="button" className="text-green-600 hover:underline" onClick={onBack}>
                Назад
              </button>
            </div>
          )}
        </form>
      ) : (
        <form onSubmit={handlePhoneSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="name">Ваше имя</Label>
            <div className="flex items-center">
              <Input id="name" value={name} disabled />
              <Button type="button" variant="ghost" size="sm" className="ml-2" onClick={handleBackToName}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Номер телефона</Label>
            <Input
              id="phone"
              placeholder="+7 (___) ___-__-__"
              value={formattedPhone}
              onChange={handlePhoneChange}
              autoComplete="tel"
              disabled={isLoading}
            />
            <p className="text-xs text-gray-500">Введите номер в формате +7 (XXX) XXX-XX-XX</p>
          </div>

          <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isLoading}>
            {isLoading ? (
              <span className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Проверка...
              </span>
            ) : (
              "Продолжить"
            )}
          </Button>
        </form>
      )}
    </>
  )
}
