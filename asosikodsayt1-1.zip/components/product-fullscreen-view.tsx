"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { X, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ProductFullscreenViewProps {
  isOpen: boolean
  onClose: () => void
  images: string[]
  videos?: string[]
  initialIndex?: number
  alt: string
  productName?: string
}

export function ProductFullscreenView({
  isOpen,
  onClose,
  images,
  videos = [],
  initialIndex = 0,
  alt,
  productName,
}: ProductFullscreenViewProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex)
  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)

  // All media combined (images and videos)
  const allMedia = [...images, ...videos]

  // Determine if current media is a video
  const isVideo = (index: number) => index >= images.length && index < allMedia.length

  // Generate SEO-friendly alt text
  const generateAltText = (index: number) => {
    const name = productName || alt
    if (isVideo(index)) {
      return `Видео ${name} - купить в Челябинске с доставкой`
    }
    return `${name} - купить в Челябинске с доставкой${index > 0 ? ` (изображение ${index + 1})` : ""}`
  }

  // Reset current index when initialIndex changes
  useEffect(() => {
    setCurrentIndex(initialIndex)
  }, [initialIndex])

  // Handle keyboard events
  useEffect(() => {
    if (!isOpen) return

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose()
      } else if (e.key === "ArrowLeft") {
        setCurrentIndex((prev) => (prev === 0 ? allMedia.length - 1 : prev - 1))
      } else if (e.key === "ArrowRight") {
        setCurrentIndex((prev) => (prev === allMedia.length - 1 ? 0 : prev + 1))
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [isOpen, allMedia.length, onClose])

  // Handle touch events for swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe) {
      setCurrentIndex((prev) => (prev === allMedia.length - 1 ? 0 : prev + 1))
    } else if (isRightSwipe) {
      setCurrentIndex((prev) => (prev === 0 ? allMedia.length - 1 : prev - 1))
    }

    setTouchStart(null)
    setTouchEnd(null)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center">
      <div
        className="relative w-full h-full flex items-center justify-center"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Close button */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-4 z-10 h-10 w-10 rounded-full bg-black/50 text-white hover:bg-black/70"
          onClick={onClose}
          aria-label="Закрыть полноэкранный просмотр"
        >
          <X className="h-6 w-6" />
        </Button>

        {/* Navigation buttons */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-4 top-1/2 -translate-y-1/2 z-10 h-12 w-12 rounded-full bg-black/50 text-white hover:bg-black/70"
          onClick={() => setCurrentIndex((prev) => (prev === 0 ? allMedia.length - 1 : prev - 1))}
          aria-label="Предыдущее изображение"
        >
          <ChevronLeft className="h-8 w-8" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-1/2 -translate-y-1/2 z-10 h-12 w-12 rounded-full bg-black/50 text-white hover:bg-black/70"
          onClick={() => setCurrentIndex((prev) => (prev === allMedia.length - 1 ? 0 : prev + 1))}
          aria-label="Следующее изображение"
        >
          <ChevronRight className="h-8 w-8" />
        </Button>

        {/* Current media */}
        <div className="max-w-full max-h-full p-4">
          {isVideo(currentIndex) ? (
            <video
              src={allMedia[currentIndex]}
              className="max-w-full max-h-[calc(100vh-8rem)] mx-auto object-contain"
              controls
              autoPlay
              loop
              aria-label={generateAltText(currentIndex)}
            />
          ) : (
            <img
              src={allMedia[currentIndex] || "/placeholder.svg"}
              alt={generateAltText(currentIndex)}
              className="max-w-full max-h-[calc(100vh-8rem)] mx-auto object-contain"
            />
          )}
        </div>

        {/* Thumbnails */}
        {allMedia.length > 1 && (
          <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2 px-4 overflow-x-auto">
            {allMedia.map((media, index) => (
              <button
                key={index}
                className={`flex-shrink-0 rounded-md overflow-hidden border-2 transition-all ${
                  index === currentIndex ? "border-white" : "border-transparent"
                }`}
                onClick={() => setCurrentIndex(index)}
                aria-label={`Переключиться на изображение ${index + 1}`}
              >
                {isVideo(index) ? (
                  <div className="relative h-16 w-16">
                    <video src={media} className="h-full w-full object-cover" muted />
                    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
                      <div className="h-6 w-6 rounded-full bg-white flex items-center justify-center">
                        <div className="h-0 w-0 border-t-4 border-b-4 border-l-8 border-transparent border-l-gray-800 ml-0.5"></div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <img
                    src={media || "/placeholder.svg"}
                    alt={`${alt} - миниатюра ${index + 1}`}
                    className="h-16 w-16 object-cover"
                    loading="lazy"
                  />
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
