"use client"

import { useEffect, useRef } from "react"

interface TelegramAuthProps {
  onAuth?: (user: any) => void
  buttonSize?: "large" | "medium" | "small"
  cornerRadius?: number
  requestAccess?: "write" | "read"
}

export function TelegramAuth({
  onAuth,
  buttonSize = "large",
  cornerRadius = 4,
  requestAccess = "write",
}: TelegramAuthProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Очищаем контейнер перед добавлением виджета
    if (containerRef.current) {
      containerRef.current.innerHTML = ""
    }

    // Создаем скрипт для виджета Telegram Login
    const script = document.createElement("script")
    script.src = "https://telegram.org/js/telegram-widget.js?22"
    script.async = true
    script.setAttribute("data-telegram-login", "Vertifolucha_bot") // Имя бота
    script.setAttribute("data-size", buttonSize)
    script.setAttribute("data-radius", cornerRadius.toString())
    script.setAttribute("data-request-access", requestAccess)
    script.setAttribute("data-userpic", "true")
    script.setAttribute("data-onauth", "onTelegramAuth(user)")

    // Добавляем обработчик авторизации в глобальную область видимости
    window.onTelegramAuth = (user: any) => {
      console.log("Telegram auth success:", user)
      if (onAuth) onAuth(user)
      // Сохраняем данные пользователя
      localStorage.setItem("telegram_user", JSON.stringify(user))
    }

    // Добавляем скрипт в контейнер
    if (containerRef.current) {
      containerRef.current.appendChild(script)
    }

    return () => {
      // Очистка при размонтировании
      if (window.onTelegramAuth) {
        delete window.onTelegramAuth
      }
    }
  }, [onAuth, buttonSize, cornerRadius, requestAccess])

  return (
    <div className="flex flex-col items-center">
      <div ref={containerRef} className="telegram-login-container"></div>
    </div>
  )
}

// Добавляем определение типа для window
declare global {
  interface Window {
    onTelegramAuth: (user: any) => void
  }
}
