import { Clock, MapPin, ShieldCheck, Truck } from "lucide-react"

export function DeliveryInfo() {
  return (
    <section className="py-12 bg-green-50">
      <div className="container">
        <h2 className="mb-8 text-center text-3xl font-bold">Быстрая доставка по Челябинску</h2>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
          <div className="flex flex-col items-center rounded-lg bg-white p-6 text-center shadow-sm">
            <div className="mb-4 rounded-full bg-green-100 p-3">
              <Truck className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">Быстрая доставка</h3>
            <p className="text-gray-600">Доставляем заказы по всему городу</p>
          </div>
          <div className="flex flex-col items-center rounded-lg bg-white p-6 text-center shadow-sm">
            <div className="mb-4 rounded-full bg-green-100 p-3">
              <ShieldCheck className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">Гарантия свежести</h3>
            <p className="text-gray-600">Мы отбираем только самые свежие и качественные продукты</p>
          </div>
          <div className="flex flex-col items-center rounded-lg bg-white p-6 text-center shadow-sm">
            <div className="mb-4 rounded-full bg-green-100 p-3">
              <MapPin className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">Вся география города</h3>
            <p className="text-gray-600">Доставляем во все районы Челябинска без исключений</p>
          </div>
          <div className="flex flex-col items-center rounded-lg bg-white p-6 text-center shadow-sm">
            <div className="mb-4 rounded-full bg-green-100 p-3">
              <Clock className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="mb-2 text-lg font-semibold">Удобное время</h3>
            <p className="text-gray-600">Работаем ежедневно с 9:00 до 21:00 без выходных</p>
          </div>
        </div>
      </div>
    </section>
  )
}
