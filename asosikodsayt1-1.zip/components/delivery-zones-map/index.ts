import DeliveryZonesMap from "../delivery-zones-map"

export default DeliveryZonesMap
