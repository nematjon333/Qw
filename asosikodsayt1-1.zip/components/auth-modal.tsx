"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { TelegramAuth } from "@/components/telegram-auth"
import { User } from "lucide-react"

export function AuthModal() {
  const [isOpen, setIsOpen] = useState(false)
  const [user, setUser] = useState<any>(null)

  // Проверяем, авторизован ли пользователь
  useEffect(() => {
    const savedUser = localStorage.getItem("telegram_user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (e) {
        console.error("Ошибка при парсинге данных пользователя:", e)
      }
    }
  }, [])

  const handleAuth = (userData: any) => {
    setUser(userData)
    setIsOpen(false)
  }

  const handleLogout = () => {
    localStorage.removeItem("telegram_user")
    setUser(null)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {user ? (
          <Button variant="outline" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden md:inline">{user.first_name}</span>
          </Button>
        ) : (
          <Button variant="outline" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden md:inline">Войти</span>
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{user ? "Личный кабинет" : "Авторизация"}</DialogTitle>
        </DialogHeader>

        {user ? (
          <div className="py-4">
            <div className="flex items-center gap-4 mb-4">
              {user.photo_url && (
                <img
                  src={user.photo_url || "/placeholder.svg"}
                  alt={user.first_name}
                  className="w-16 h-16 rounded-full"
                />
              )}
              <div>
                <p className="font-medium">
                  {user.first_name} {user.last_name}
                </p>
                <p className="text-sm text-gray-500">@{user.username}</p>
              </div>
            </div>
            <Button variant="outline" className="w-full mt-4" onClick={handleLogout}>
              Выйти
            </Button>
          </div>
        ) : (
          <div className="py-4">
            <p className="text-center mb-4">Войдите через Telegram для доступа к личному кабинету</p>
            <div className="flex justify-center">
              <TelegramAuth onAuth={handleAuth} buttonSize="medium" />
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
