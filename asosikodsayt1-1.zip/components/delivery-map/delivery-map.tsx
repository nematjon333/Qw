"use client"

import dynamic from "next/dynamic"
import { Skeleton } from "@/components/ui/skeleton"

// Динамически импортируем клиентский компонент карты с отключенным SSR
const DeliveryMapClient = dynamic(() => import("./delivery-map-client"), {
  ssr: false,
  loading: () => <Skeleton className="w-full h-[400px] rounded-md" />,
})

// Экспортируем константы из клиентского компонента
export const STORE_LATITUDE = 55.159897
export const STORE_LONGITUDE = 61.402554

// Типы для пропсов
interface DeliveryMapProps {
  onAddressSelect: (address: any, coordinates: [number, number], distance: number) => void
  initialAddress?: string
  initialCoordinates?: [number, number]
  storeCoordinates?: [number, number]
  showSaveButton?: boolean
  onSaveAddress?: (address: string, coordinates: [number, number]) => void
}

// Компонент-обертка для карты доставки
export default function DeliveryMap(props: DeliveryMapProps) {
  return <DeliveryMapClient {...props} />
}
