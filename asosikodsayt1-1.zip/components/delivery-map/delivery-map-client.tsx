"use client"

import { useEffect, useState, useRef } from "react"
import { MapContainer, TileLayer, Marker, Popup, useMap, Circle } from "react-leaflet"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Search, MapPin, Loader2, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { CustomMapAttribution } from "../custom-map-attribution"
import { getSuggestions, reverseGeocode, calculateDistance } from "@/lib/dadata-service"

// Константы для координат магазина
export const STORE_LATITUDE = 55.159897
export const STORE_LONGITUDE = 61.402554

// Ensure Leaflet icons work properly
if (typeof window !== "undefined") {
  // Fix Leaflet's icon paths using CDN URLs with specific MIME types
  delete (L.Icon.Default.prototype as any)._getIconUrl
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
    iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
    shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
  })
}

interface DeliveryZone {
  id: number
  name: string
  type: "polygon" | "circle"
  coordinates?: [number, number][]
  center?: { lat: number; lng: number }
  radius?: number
  color: string
  base_fee: number
  min_order_amount: number
  free_delivery_threshold: number | null
  per_km_fee: number
  active: boolean
}

interface DeliveryMapProps {
  onAddressSelect: (address: any, coordinates: [number, number], distance: number) => void
  initialAddress?: string
  initialCoordinates?: [number, number]
  storeCoordinates?: [number, number]
  showSaveButton?: boolean
  onSaveAddress?: (address: string, coordinates: [number, number]) => void
}

// Компонент для управления картой
function MapController({
  onAddressSelect,
  initialCoordinates,
  storeCoordinates = [STORE_LATITUDE, STORE_LONGITUDE],
}: {
  onAddressSelect: (address: any, coordinates: [number, number], distance: number) => void
  initialCoordinates?: [number, number]
  storeCoordinates?: [number, number]
}) {
  const map = useMap()
  const [selectedPosition, setSelectedPosition] = useState<[number, number] | null>(initialCoordinates || null)
  const [isLoading, setIsLoading] = useState(false)
  const markerRef = useRef<L.Marker | null>(null)

  useEffect(() => {
    if (initialCoordinates) {
      map.setView(initialCoordinates, 13)
      setSelectedPosition(initialCoordinates)
    } else if (storeCoordinates) {
      map.setView(storeCoordinates, 13)
    }
  }, [initialCoordinates, storeCoordinates, map])

  useEffect(() => {
    const handleMapClick = async (e: L.LeafletMouseEvent) => {
      const { lat, lng } = e.latlng
      setSelectedPosition([lat, lng])

      try {
        setIsLoading(true)
        // Reverse geocoding to get address from coordinates
        const address = await reverseGeocode(lat, lng)

        // Calculate distance from store
        const distance = calculateDistance(storeCoordinates[0], storeCoordinates[1], lat, lng)

        if (address) {
          onAddressSelect(address, [lat, lng], distance)
        } else {
          onAddressSelect({ value: `${lat.toFixed(6)}, ${lng.toFixed(6)}` }, [lat, lng], distance)
        }
      } catch (error) {
        console.error("Error fetching address:", error)
        const distance = calculateDistance(storeCoordinates[0], storeCoordinates[1], lat, lng)
        onAddressSelect({ value: `${lat.toFixed(6)}, ${lng.toFixed(6)}` }, [lat, lng], distance)
      } finally {
        setIsLoading(false)
      }
    }

    map.on("click", handleMapClick)

    return () => {
      map.off("click", handleMapClick)
    }
  }, [map, onAddressSelect, storeCoordinates])

  return (
    <>
      {selectedPosition && (
        <Marker
          position={selectedPosition}
          ref={markerRef}
          draggable={true}
          eventHandlers={{
            dragend: async (e) => {
              const marker = e.target
              const position = marker.getLatLng()
              const newPos: [number, number] = [position.lat, position.lng]
              setSelectedPosition(newPos)

              try {
                setIsLoading(true)
                // Reverse geocoding to get address from coordinates
                const address = await reverseGeocode(position.lat, position.lng)

                // Calculate distance from store
                const distance = calculateDistance(storeCoordinates[0], storeCoordinates[1], position.lat, position.lng)

                if (address) {
                  onAddressSelect(address, newPos, distance)
                } else {
                  onAddressSelect({ value: `${position.lat.toFixed(6)}, ${position.lng.toFixed(6)}` }, newPos, distance)
                }
              } catch (error) {
                console.error("Error fetching address:", error)
                const distance = calculateDistance(storeCoordinates[0], storeCoordinates[1], position.lat, position.lng)
                onAddressSelect({ value: `${position.lat.toFixed(6)}, ${position.lng.toFixed(6)}` }, newPos, distance)
              } finally {
                setIsLoading(false)
              }
            },
          }}
        >
          <Popup>{isLoading ? "Загрузка адреса..." : "Выбранное местоположение"}</Popup>
        </Marker>
      )}

      {/* Store location marker */}
      <Marker position={storeCoordinates}>
        <Popup>Наш магазин</Popup>
      </Marker>
    </>
  )
}

export default function DeliveryMapClient({
  onAddressSelect,
  initialAddress,
  initialCoordinates,
  storeCoordinates = [STORE_LATITUDE, STORE_LONGITUDE],
  showSaveButton = false,
  onSaveAddress,
}: DeliveryMapProps) {
  const [deliveryZones, setDeliveryZones] = useState<DeliveryZone[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [suggestions, setSuggestions] = useState<any[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [isLocating, setIsLocating] = useState(false)
  const [selectedAddress, setSelectedAddress] = useState<any>(null)
  const [selectedCoordinates, setSelectedCoordinates] = useState<[number, number] | null>(initialCoordinates || null)
  const mapRef = useRef<L.Map | null>(null)

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)
        const response = await fetch("/api/delivery-zones", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache",
          },
        })

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`)
        }

        const data = await response.json()
        setDeliveryZones(data.zones || [])
        setError(null)
      } catch (err) {
        console.error("Error fetching delivery zones:", err)
        setError("Зоны доставки не загружены")
        // Устанавливаем пустой массив зон доставки, чтобы не блокировать работу карты
        setDeliveryZones([])
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Функция для поиска адресов
  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    try {
      setIsSearching(true)
      const results = await getSuggestions(searchQuery)
      setSuggestions(results)
    } catch (error) {
      console.error("Error searching for addresses:", error)
      setError("Ошибка при поиске адресов. Пожалуйста, попробуйте еще раз.")
    } finally {
      setIsSearching(false)
    }
  }

  // Функция для выбора адреса из подсказок
  const handleSelectSuggestion = (suggestion: any) => {
    if (suggestion.data && suggestion.data.geo_lat && suggestion.data.geo_lon) {
      const lat = Number.parseFloat(suggestion.data.geo_lat)
      const lng = Number.parseFloat(suggestion.data.geo_lon)

      if (isNaN(lat) || isNaN(lng)) {
        console.error("Invalid coordinates in suggestion:", suggestion)
        setError("Некорректные координаты в выбранном адресе")
        return
      }

      // Обновляем позицию на карте
      if (mapRef.current) {
        mapRef.current.setView([lat, lng], 16)
      }

      setSelectedAddress(suggestion)
      setSelectedCoordinates([lat, lng])

      // Calculate distance from store
      const distance = calculateDistance(storeCoordinates[0], storeCoordinates[1], lat, lng)

      // Вызываем колбэк с выбранным адресом
      onAddressSelect(suggestion, [lat, lng], distance)

      // Очищаем поиск
      setSearchQuery("")
      setSuggestions([])
    } else {
      console.error("Missing geo coordinates in suggestion:", suggestion)
      setError("В выбранном адресе отсутствуют координаты")
    }
  }

  // Функция для определения местоположения пользователя
  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      setError("Геолокация не поддерживается вашим браузером")
      return
    }

    setIsLocating(true)
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords

        // Обновляем позицию на карте
        if (mapRef.current) {
          mapRef.current.setView([latitude, longitude], 16)
        }

        try {
          // Получаем адрес по координатам
          const address = await reverseGeocode(latitude, longitude)

          // Calculate distance from store
          const distance = calculateDistance(storeCoordinates[0], storeCoordinates[1], latitude, longitude)

          setSelectedCoordinates([latitude, longitude])

          if (address) {
            setSelectedAddress(address)
            onAddressSelect(address, [latitude, longitude], distance)
          } else {
            const fallbackAddress = { value: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}` }
            setSelectedAddress(fallbackAddress)
            onAddressSelect(fallbackAddress, [latitude, longitude], distance)
          }
        } catch (error) {
          console.error("Error getting address from coordinates:", error)
          const distance = calculateDistance(storeCoordinates[0], storeCoordinates[1], latitude, longitude)
          const fallbackAddress = { value: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}` }
          setSelectedAddress(fallbackAddress)
          onAddressSelect(fallbackAddress, [latitude, longitude], distance)
        } finally {
          setIsLocating(false)
        }
      },
      (error) => {
        console.error("Error getting location:", error)
        setError(
          "Не удалось определить ваше местоположение. Пожалуйста, выберите адрес на карте или воспользуйтесь поиском.",
        )
        setIsLocating(false)
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 },
    )
  }

  // Функция для сохранения выбранного адреса
  const handleSaveAddress = () => {
    if (selectedAddress && selectedCoordinates && onSaveAddress) {
      const addressValue =
        typeof selectedAddress === "string" ? selectedAddress : selectedAddress.value || JSON.stringify(selectedAddress)

      onSaveAddress(addressValue, selectedCoordinates)
    }
  }

  if (typeof window === "undefined") {
    return <Skeleton className="w-full h-[400px] rounded-md" />
  }

  return (
    <div className="space-y-4">
      {/* Поиск адреса */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            type="text"
            placeholder="Введите адрес доставки"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            className="pr-10"
          />
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-0 top-0 h-full"
            onClick={handleSearch}
            disabled={isSearching}
          >
            {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          </Button>

          {/* Подсказки */}
          {suggestions.length > 0 && (
            <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 rounded-md shadow-lg border border-gray-200 dark:border-gray-700 max-h-60 overflow-auto">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  className="w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 text-sm"
                  onClick={() => handleSelectSuggestion(suggestion)}
                >
                  {suggestion.value}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Кнопка определения местоположения */}
        <Button onClick={handleGetLocation} disabled={isLocating} variant="outline">
          {isLocating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <MapPin className="h-4 w-4 mr-2" />}
          Моё местоположение
        </Button>
      </div>

      {/* Карта */}
      <div className="relative w-full h-[400px] rounded-md overflow-hidden border">
        {loading && (
          <div className="absolute inset-0 bg-background/50 z-10 flex items-center justify-center">
            <div className="flex flex-col items-center gap-2">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              <p className="text-sm text-muted-foreground">Загрузка зон доставки...</p>
            </div>
          </div>
        )}

        {error && (
          <Alert variant="destructive" className="absolute top-2 left-2 right-2 z-10">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <MapContainer
          center={storeCoordinates}
          zoom={13}
          style={{ height: "100%", width: "100%" }}
          attributionControl={false}
          ref={mapRef}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          <CustomMapAttribution position="bottomright" />

          {/* Render delivery zones */}
          {deliveryZones.map((zone) => {
            if (zone.type === "circle" && zone.center && zone.radius) {
              return (
                <Circle
                  key={zone.id}
                  center={[zone.center.lat, zone.center.lng]}
                  radius={zone.radius}
                  pathOptions={{
                    color: zone.color || "#FF5733",
                    fillColor: zone.color || "#FF5733",
                    fillOpacity: 0.2,
                  }}
                >
                  <Popup>
                    <div>
                      <h3 className="font-medium">{zone.name}</h3>
                      <p>Базовая стоимость: {zone.base_fee} ₽</p>
                      {zone.min_order_amount > 0 && <p>Мин. сумма заказа: {zone.min_order_amount} ₽</p>}
                      {zone.free_delivery_threshold && <p>Бесплатно от: {zone.free_delivery_threshold} ₽</p>}
                    </div>
                  </Popup>
                </Circle>
              )
            } else if (zone.type === "polygon" && zone.coordinates && zone.coordinates.length > 0) {
              return null // Polygon rendering will be added if needed
            }
            return null
          })}

          <MapController
            onAddressSelect={onAddressSelect}
            initialCoordinates={initialCoordinates}
            storeCoordinates={storeCoordinates}
          />
        </MapContainer>
      </div>

      {/* Выбранный адрес и кнопка сохранения */}
      {selectedAddress && (
        <div className="p-4 border rounded-md bg-gray-50 dark:bg-gray-800">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-medium mb-1">Выбранный адрес:</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {typeof selectedAddress === "string" ? selectedAddress : selectedAddress.value || "Адрес не определен"}
              </p>
            </div>
            {showSaveButton && (
              <Button onClick={handleSaveAddress} size="sm" className="bg-green-600 hover:bg-green-700">
                <Check className="h-4 w-4 mr-2" />
                Сохранить адрес
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
