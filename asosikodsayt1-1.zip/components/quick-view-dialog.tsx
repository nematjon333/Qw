"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Plus, Minus } from "lucide-react"
import { useCart } from "@/context/cart-context"
import { toast } from "@/components/ui/use-toast"

interface QuickViewDialogProps {
  children: React.ReactNode
  product: {
    id: string
    name: string
    price: number
    image: string
    unit?: string
    discount?: number
    description?: string
    origin?: string
    stockQuantity?: number
    videoUrl?: string
  }
}

export function QuickViewDialog({ children, product }: QuickViewDialogProps) {
  const [isOpen, setIsOpen] = useState(false)
  const { addItem, items, updateQuantity } = useCart()

  // Check if product is in stock
  const isInStock = (product.stockQuantity || 0) > 0

  // Check if the product is already in cart
  const cartItem = items.find((item) => item.id === product.id)
  const isInCart = Boolean(cartItem)

  const discountedPrice = product.discount ? product.price - (product.price * product.discount) / 100 : null

  const handleAddToCart = () => {
    if (!isInStock) {
      toast({
        title: "Товар недоступен",
        description: "К сожалению, данный товар отсутствует в наличии",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      unit: product.unit || "кг",
      discount: product.discount,
      quantity: 1,
    })

    toast({
      title: "Товар добавлен в корзину",
      description: `${product.name} (1 ${product.unit || "кг"})`,
      variant: "success",
      duration: 3000,
    })
  }

  const handleIncreaseQuantity = () => {
    if (!isInStock) {
      toast({
        title: "Товар недоступен",
        description: "К сожалению, данный товар отсутствует в наличии",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    if (!isInCart) {
      // If product is not in cart, add it
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        unit: product.unit || "кг",
        discount: product.discount,
        quantity: 1,
      })
    } else {
      // If product is already in cart, increase quantity
      updateQuantity(product.id, cartItem.quantity + 1)
    }

    toast({
      title: "Товар добавлен в корзину",
      description: `${product.name}`,
      variant: "success",
      duration: 3000,
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="relative aspect-square bg-gray-100">
            {product.videoUrl ? (
              <video src={product.videoUrl} controls autoPlay loop muted className="w-full h-full object-contain">
                Ваш браузер не поддерживает видео.
              </video>
            ) : (
              <img
                src={product.image || "/placeholder.svg?height=400&width=400"}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            )}

            {/* Out of stock badge */}
            {!isInStock && (
              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
                <span className="bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-md">Нет в наличии</span>
              </div>
            )}
          </div>
          <div className="p-6 flex flex-col">
            <h3 className="text-xl font-bold mb-2">{product.name}</h3>

            <div className="flex items-baseline gap-2 mb-4">
              {discountedPrice ? (
                <>
                  <span className="text-xl font-bold text-green-600">{discountedPrice.toFixed(0)} ₽</span>
                  <span className="text-sm text-gray-500 line-through">{product.price.toFixed(0)} ₽</span>
                </>
              ) : (
                <span className="text-xl font-bold text-green-600">{product.price.toFixed(0)} ₽</span>
              )}
              <span className="text-xs text-gray-500">/{product.unit || "кг"}</span>
            </div>

            {/* Stock status */}
            {!isInStock && <div className="mb-4 p-2 bg-red-50 text-red-600 rounded-md font-medium">Нет в наличии</div>}

            {product.description && <p className="text-sm text-gray-600 mb-4 flex-grow">{product.description}</p>}

            {product.origin && (
              <div className="text-sm text-gray-600 mb-4">
                <span className="font-medium">Происхождение:</span> {product.origin}
              </div>
            )}

            <div className="mt-auto">
              {!isInStock ? (
                <Button className="w-full gap-2 bg-gray-300 hover:bg-gray-400 cursor-not-allowed" disabled>
                  Нет в наличии
                </Button>
              ) : !isInCart ? (
                <Button
                  className="w-full h-12 rounded-full bg-green-600 hover:bg-green-700"
                  onClick={handleIncreaseQuantity}
                >
                  <Plus className="h-5 w-5" />
                </Button>
              ) : (
                <div className="flex items-center justify-between w-full rounded-full overflow-hidden border border-gray-200">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-12 w-12 rounded-l-full"
                    onClick={() => {
                      if (cartItem.quantity <= 1) {
                        // Remove from cart
                        updateQuantity(product.id, 0)
                      } else {
                        // Decrease quantity
                        updateQuantity(product.id, cartItem.quantity - 1)
                      }
                    }}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="flex-1 text-center font-medium">
                    {cartItem?.quantity} {product.unit || "кг"}
                  </span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-12 w-12 rounded-r-full"
                    onClick={() => {
                      updateQuantity(product.id, cartItem.quantity + 1)
                    }}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
