"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, CheckCircle, RefreshCw, Send } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export function TelegramCheck() {
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const checkTelegramConnection = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/telegram/check")
      const data = await response.json()

      setResult(data)

      if (data.success) {
        toast({
          title: "Успешно",
          description: "Соединение с Telegram установлено успешно",
          variant: "success",
        })
      } else {
        toast({
          title: "Ошибка",
          description: data.message || "Не удалось установить соединение с Telegram",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Ошибка при проверке Telegram:", error)
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при проверке соединения с Telegram",
        variant: "destructive",
      })
      setResult({ success: false, message: "Произошла ошибка при проверке соединения" })
    } finally {
      setIsLoading(false)
    }
  }

  const sendTestMessage = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/telegram/test")
      const data = await response.json()

      if (data.success) {
        toast({
          title: "Успешно",
          description: "Тестовое сообщение отправлено успешно",
          variant: "success",
        })
      } else {
        toast({
          title: "Ошибка",
          description: data.message || "Не удалось отправить тестовое сообщение",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Ошибка при отправке тестового сообщения:", error)
      toast({
        title: "Ошибка",
        description: "Произошла ошибка при отправке тестового сообщения",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Проверка Telegram бота</CardTitle>
        <CardDescription>Проверьте настройки и работу Telegram бота для уведомлений о заказах</CardDescription>
      </CardHeader>
      <CardContent>
        {result && (
          <div className="mb-4 p-4 rounded-lg border">
            <div className="flex items-center mb-2">
              {result.success ? (
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
              )}
              <span className={result.success ? "text-green-600" : "text-red-600"}>{result.message}</span>
            </div>

            {result.config && (
              <div className="text-sm mt-2 space-y-1">
                <div>
                  Токен бота: <span className="font-mono">{result.config.botToken}</span>
                </div>
                <div>
                  ID администратора: <span className="font-mono">{result.config.adminId}</span>
                </div>
                <div>
                  Имя бота: <span className="font-mono">{result.config.botUsername}</span>
                </div>
              </div>
            )}

            {result.timestamp && (
              <div className="text-xs text-gray-500 mt-2">
                Проверка выполнена: {new Date(result.timestamp).toLocaleString()}
              </div>
            )}
          </div>
        )}

        <div className="text-sm space-y-2">
          <p>Для работы уведомлений о заказах необходимо настроить следующие переменные окружения:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>
              <code className="text-xs font-mono bg-gray-100 p-1 rounded">TELEGRAM_BOT_TOKEN</code> - токен бота,
              полученный от @BotFather
            </li>
            <li>
              <code className="text-xs font-mono bg-gray-100 p-1 rounded">TELEGRAM_ADMIN_ID</code> - ID администратора
              (ваш ID в Telegram)
            </li>
            <li>
              <code className="text-xs font-mono bg-gray-100 p-1 rounded">TELEGRAM_BOT_USERNAME</code> - имя бота
              (необязательно)
            </li>
          </ul>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={checkTelegramConnection} disabled={isLoading}>
          {isLoading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
          Проверить соединение
        </Button>
        <Button onClick={sendTestMessage} disabled={isLoading || (result && !result.success)}>
          <Send className="h-4 w-4 mr-2" />
          Отправить тестовое сообщение
        </Button>
      </CardFooter>
    </Card>
  )
}
