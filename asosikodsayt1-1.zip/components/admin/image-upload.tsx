"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Upload, X, Camera, Loader2, ImageIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"

interface ImageUploadProps {
  onImageUploaded?: (imageUrl: string) => void
  onImageUpload?: (imageUrl: string) => void
  currentImage?: string
  initialImage?: string
  onRemove?: () => void
  maxSize?: number // в МБ
  accept?: string
  folder?: string
}

export function ImageUpload({
  onImageUploaded,
  onImageUpload,
  currentImage,
  initialImage,
  onRemove,
  maxSize = 10,
  accept = "image/*",
  folder = "uploads",
}: ImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [preview, setPreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const cameraInputRef = useRef<HTMLInputElement>(null)
  const [error, setError] = useState<string | null>(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [apiStatus, setApiStatus] = useState<any>(null)

  // Устанавливаем начальное изображение
  useEffect(() => {
    if (currentImage) {
      console.log("Установка начального изображения (currentImage):", currentImage)
      setPreview(currentImage)
    } else if (initialImage) {
      console.log("Установка начального изображения (initialImage):", initialImage)
      setPreview(initialImage)
    }

    // Проверяем состояние API при монтировании компонента
    checkApiStatus()
  }, [currentImage, initialImage])

  // Функция для проверки состояния API
  const checkApiStatus = async () => {
    try {
      const response = await fetch("/api/upload", {
        method: "GET",
      })

      const data = await response.json()
      setApiStatus(data)

      if (!data.success) {
        console.error("Проблема с API загрузки:", data.message)
        setError("Проблема с API загрузки: " + data.message)
      } else if (data.note) {
        console.warn("API загрузки работает в резервном режиме:", data.note)
        setError(null)
      } else {
        console.log("API загрузки доступно:", data.status)
        setError(null)
      }
    } catch (error) {
      console.error("Ошибка при проверке API загрузки:", error)
      setError("Ошибка при проверке API загрузки")
    }
  }

  const validateFile = (file: File): boolean => {
    // Проверка типа файла
    if (!file.type.startsWith("image/")) {
      setError("Пожалуйста, выберите изображение")
      return false
    }

    // Проверка размера файла
    if (file.size > maxSize * 1024 * 1024) {
      setError(`Размер файла не должен превышать ${maxSize} МБ`)
      return false
    }

    setError(null)
    return true
  }

  const uploadFile = async (file: File): Promise<string> => {
    // Создаем FormData для отправки файла
    const formData = new FormData()
    formData.append("file", file)
    formData.append("folder", folder)

    try {
      console.log("Начало загрузки файла:", file.name)

      // Отправляем файл на сервер
      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      console.log("Получен ответ от сервера:", response.status)

      const data = await response.json()

      if (!response.ok && !data.success) {
        console.error("Ошибка от сервера:", data)
        throw new Error(data.error || "Ошибка при загрузке файла")
      }

      console.log("Успешно загружен файл, получен URL:", data.url)

      // Если есть примечание, показываем его как предупреждение
      if (data.note) {
        console.warn("Примечание от сервера:", data.note)
        toast({
          title: "Информация",
          description: data.note,
          variant: "default",
        })
      }

      return data.url
    } catch (error) {
      console.error("Ошибка при загрузке файла:", error)
      throw error
    }
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    console.log("Выбран файл:", file.name, "размер:", file.size, "тип:", file.type)

    if (!validateFile(file)) {
      return
    }

    setIsUploading(true)
    setUploadProgress(0)

    try {
      // Создаем URL для предпросмотра
      const previewUrl = URL.createObjectURL(file)
      setPreview(previewUrl)
      console.log("Создан URL для предпросмотра:", previewUrl)

      // Имитация прогресса загрузки
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          const newProgress = prev + Math.random() * 10
          return newProgress > 90 ? 90 : newProgress
        })
      }, 200)

      // Загружаем файл на сервер
      const imageUrl = await uploadFile(file)
      console.log("Файл успешно загружен, URL:", imageUrl)

      // Завершаем прогресс загрузки
      clearInterval(progressInterval)
      setUploadProgress(100)

      // Передаем URL изображения родительскому компоненту
      if (onImageUploaded) {
        console.log("Вызываем onImageUploaded с URL:", imageUrl)
        onImageUploaded(imageUrl)
      }

      if (onImageUpload) {
        console.log("Вызываем onImageUpload с URL:", imageUrl)
        onImageUpload(imageUrl)
      }

      toast({
        title: "Изображение загружено",
        description: "Изображение успешно загружено",
        variant: "success",
      })
    } catch (error) {
      console.error("Ошибка при загрузке файла:", error)
      setError(error.message || "Ошибка при загрузке файла")

      // Если произошла ошибка, используем локальную заглушку
      const placeholderUrl = `/placeholder.svg?height=800&width=800&seed=${Date.now()}`

      // Передаем URL заглушки родительскому компоненту
      if (onImageUploaded) {
        onImageUploaded(placeholderUrl)
      }

      if (onImageUpload) {
        onImageUpload(placeholderUrl)
      }

      toast({
        title: "Внимание",
        description: "Используется заглушка из-за ошибки загрузки",
        variant: "default",
      })
    } finally {
      setIsUploading(false)
      setUploadProgress(0)

      // Сбрасываем значение input, чтобы можно было загрузить тот же файл повторно
      if (fileInputRef.current) fileInputRef.current.value = ""
      if (cameraInputRef.current) cameraInputRef.current.value = ""
    }
  }

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  const handleRemove = () => {
    console.log("Удаление изображения")
    setPreview(null)
    setError(null)
    if (onRemove) {
      onRemove()
    }
  }

  const handleCameraCapture = () => {
    if (cameraInputRef.current) {
      cameraInputRef.current.click()
    }
  }

  return (
    <div className="space-y-2">
      {/* Скрытый input для выбора файла из галереи */}
      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept={accept} className="hidden" />

      {/* Скрытый input для камеры */}
      <input
        type="file"
        ref={cameraInputRef}
        onChange={handleFileChange}
        accept={accept}
        capture="environment"
        className="hidden"
      />

      {preview ? (
        <div className="relative rounded-md overflow-hidden">
          <img
            src={preview || "/placeholder.svg"}
            alt="Preview"
            className="w-full h-48 object-cover"
            onError={(e) => {
              console.error("Ошибка загрузки изображения:", preview)
              e.currentTarget.src = "/placeholder.svg?height=400&width=400"
            }}
          />
          {isUploading && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-50">
              <Loader2 className="h-8 w-8 text-white animate-spin mb-2" />
              <div className="w-3/4 bg-gray-200 rounded-full h-2.5">
                <div className="bg-green-600 h-2.5 rounded-full" style={{ width: `${uploadProgress}%` }}></div>
              </div>
              <p className="text-white text-sm mt-2">{Math.round(uploadProgress)}%</p>
            </div>
          )}
          <Button
            type="button"
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2"
            onClick={handleRemove}
            disabled={isUploading}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      ) : (
        <div
          className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors"
          onClick={triggerFileInput}
        >
          <Upload className="h-10 w-10 text-gray-400 mb-2" />
          <p className="text-sm font-medium">Нажмите для загрузки</p>
          <p className="text-xs text-gray-500 mt-1">PNG, JPG, GIF до {maxSize} МБ</p>
        </div>
      )}

      {error && <div className="text-sm text-red-500 mt-1">{error}</div>}

      {apiStatus && apiStatus.note && (
        <div className="text-sm text-yellow-600 mt-1 p-2 bg-yellow-50 rounded-md">{apiStatus.note}</div>
      )}

      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="w-full"
          onClick={triggerFileInput}
          disabled={isUploading}
        >
          {isUploading ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Загрузка...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <ImageIcon className="h-4 w-4" />
              Галерея
            </span>
          )}
        </Button>

        <Button
          type="button"
          variant="outline"
          size="sm"
          className="w-full"
          onClick={handleCameraCapture}
          disabled={isUploading}
        >
          <Camera className="h-4 w-4 mr-2" />
          Камера
        </Button>
      </div>

      <Button type="button" variant="ghost" size="sm" className="w-full text-xs" onClick={checkApiStatus}>
        Проверить API загрузки
      </Button>
    </div>
  )
}
