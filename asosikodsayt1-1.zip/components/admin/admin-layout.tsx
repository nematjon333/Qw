"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { AdminLogin } from "./admin-login"
import { isAdminAuthenticated, adminLogout } from "@/lib/auth-service"
import { Button } from "@/components/ui/button"
import { LogOut, Package, Users, Settings, Tag, MapPin, LayoutDashboard, Database, ImageIcon } from "lucide-react"

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const [authenticated, setAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)
  const pathname = usePathname()
  const router = useRouter()

  useEffect(() => {
    const checkAuth = () => {
      const isAuth = isAdminAuthenticated()
      setAuthenticated(isAuth)
      setLoading(false)
    }

    checkAuth()
  }, [])

  const handleLogout = () => {
    adminLogout()
    setAuthenticated(false)
    router.push("/admin/login")
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-current border-t-transparent text-green-600" />
      </div>
    )
  }

  if (!authenticated) {
    return <AdminLogin onLogin={() => setAuthenticated(true)} />
  }

  const isActive = (path: string) => {
    return pathname === path || pathname?.startsWith(path + "/")
  }

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      {/* Боковая панель */}
      <div className="w-full border-b bg-card md:w-64 md:border-b-0 md:border-r">
        <div className="flex h-14 items-center border-b px-4">
          <Link href="/admin/dashboard" className="flex items-center font-semibold">
            Админ-панель
          </Link>
        </div>
        <nav className="space-y-1 p-2">
          <Link
            href="/admin/dashboard"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/dashboard")
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <LayoutDashboard className="mr-2 h-4 w-4" />
            Заказы
          </Link>
          <Link
            href="/admin/products"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/products")
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <Package className="mr-2 h-4 w-4" />
            Товары
          </Link>
          <Link
            href="/admin/customers"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/customers")
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <Users className="mr-2 h-4 w-4" />
            Клиенты
          </Link>
          <Link
            href="/admin/promo-codes"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/promo-codes")
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <Tag className="mr-2 h-4 w-4" />
            Промокоды
          </Link>
          <Link
            href="/admin/slideshows"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/slideshows")
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <ImageIcon className="mr-2 h-4 w-4" />
            Слайд-шоу
          </Link>
          <Link
            href="/admin/delivery-zones"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/delivery-zones")
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <MapPin className="mr-2 h-4 w-4" />
            Зоны доставки
          </Link>
          <Link
            href="/admin/settings"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/settings")
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <Settings className="mr-2 h-4 w-4" />
            Настройки
          </Link>
          <Link
            href="/admin/site-settings"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/site-settings")
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <Settings className="mr-2 h-4 w-4" />
            Настройки сайта
          </Link>
          <Link
            href="/admin/setup"
            className={`flex items-center rounded-md px-3 py-2 text-sm font-medium ${
              isActive("/admin/setup") ? "bg-primary text-primary-foreground" : "hover:bg-muted hover:text-foreground"
            }`}
          >
            <Database className="mr-2 h-4 w-4" />
            Настройка БД
          </Link>
        </nav>
        <div className="p-2">
          <Button variant="outline" className="w-full justify-start" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            Выйти
          </Button>
        </div>
      </div>

      {/* Основной контент */}
      <div className="flex-1 overflow-auto p-4 md:p-6">{children}</div>
    </div>
  )
}
