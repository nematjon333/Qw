"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export function SetupDatabaseButton() {
  const [isLoading, setIsLoading] = useState(false)

  const handleSetupDatabase = async () => {
    setIsLoading(true)
    try {
      // Сначала создаем SQL-функцию
      await fetch("/api/setup-sql-function")

      // Затем инициализируем таблицу категорий
      await fetch("/api/setup-categories")

      // Затем инициализируем остальные таблицы
      const response = await fetch("/api/setup-database")
      const data = await response.json()

      if (data.success) {
        toast({
          title: "База данных инициализирована",
          description: "Все необходимые таблицы успешно созданы",
          variant: "success",
        })
      } else {
        throw new Error(data.message || "Ошибка при инициализации базы данных")
      }
    } catch (error) {
      console.error("Ошибка при инициализации базы данных:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось инициализировать базу данных",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={handleSetupDatabase} disabled={isLoading} className="bg-green-600 hover:bg-green-700">
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Инициализация...
        </>
      ) : (
        "Инициализировать базу данных"
      )}
    </Button>
  )
}
