"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

export function CookieConsent() {
  const [showConsent, setShowConsent] = useState(false)

  useEffect(() => {
    // Проверяем, было ли уже получено согласие
    const consent = localStorage.getItem("cookie_consent")
    if (!consent) {
      // Если согласия нет, показываем баннер
      setShowConsent(true)
    }
  }, [])

  const acceptCookies = () => {
    localStorage.setItem("cookie_consent", "accepted")
    setShowConsent(false)
  }

  const declineCookies = () => {
    localStorage.setItem("cookie_consent", "declined")
    setShowConsent(false)
  }

  if (!showConsent) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 p-4 md:flex md:items-center md:justify-between">
      <div className="mb-4 md:mb-0 md:mr-4">
        <h3 className="text-lg font-medium">Мы используем cookies 🍪</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
          Мы используем файлы cookie для улучшения работы сайта и предоставления вам персонализированного опыта.
        </p>
      </div>
      <div className="flex gap-2 md:flex-shrink-0">
        <Button variant="outline" size="sm" onClick={declineCookies}>
          Отклонить
        </Button>
        <Button className="bg-green-600 hover:bg-green-700" size="sm" onClick={acceptCookies}>
          Принять все
        </Button>
        <Button variant="ghost" size="icon" className="ml-2" onClick={declineCookies}>
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
