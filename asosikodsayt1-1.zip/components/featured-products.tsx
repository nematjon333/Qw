import { ArrowRight } from "lucide-react"
import Link from "next/link"
import { ProductCard } from "@/components/product-card"

// Sample product data
const featuredProducts = [
  {
    id: "1",
    name: "Яблоки Голден",
    price: 159,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    discount: 15,
  },
  {
    id: "2",
    name: "Бананы",
    price: 129,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
  },
  {
    id: "3",
    name: "Апельсины",
    price: 189,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    discount: 10,
  },
  {
    id: "4",
    name: "Огурцы",
    price: 199,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
  },
  {
    id: "5",
    name: "Помидоры",
    price: 249,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    discount: 20,
  },
  {
    id: "6",
    name: "Курага",
    price: 399,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
  },
  {
    id: "7",
    name: "Сок апельсиновый",
    price: 159,
    image: "/placeholder.svg?height=200&width=200",
    unit: "л",
  },
  {
    id: "8",
    name: "Чернослив",
    price: 459,
    image: "/placeholder.svg?height=200&width=200",
    unit: "кг",
    discount: 5,
  },
]

export function FeaturedProducts() {
  return (
    <section className="py-12">
      <div className="container">
        <div className="mb-8 flex items-center justify-between">
          <h2 className="text-3xl font-bold">Популярные товары</h2>
          <Link href="/catalog" className="flex items-center gap-2 text-green-600 hover:underline">
            Смотреть все
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>
      </div>
    </section>
  )
}
