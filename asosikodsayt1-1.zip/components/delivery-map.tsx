"use client"

import { useEffect, useRef, useState } from "react"
import Script from "next/script"
import { Loader2, MapPin, ExternalLink } from "lucide-react"

export function DeliveryMap() {
  const mapRef = useRef<HTMLDivElement>(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const [scriptLoaded, setScriptLoaded] = useState(false)
  const [scriptError, setScriptError] = useState(false)

  // Координаты магазинов
  const storeCoordinates = [
    { id: 1, coords: [55.17227, 61.431893], address: "г. Челябинск, ул. Артиллерийская 116/1" },
    { id: 2, coords: [55.165638, 61.457634], address: "г. Челябинск, ул. Первый пятилетки 13б" },
  ]

  const initMap = () => {
    if (!mapRef.current || !window.ymaps) return

    window.ymaps.ready(() => {
      try {
        // Создаем карту
        const map = new window.ymaps.Map(mapRef.current, {
          center: [55.169, 61.445], // Центр между двумя магазинами
          zoom: 12,
          controls: ["zoomControl"],
        })

        // Добавляем метки магазинов
        storeCoordinates.forEach((store) => {
          const storePoint = new window.ymaps.Placemark(
            store.coords,
            {
              hintContent: "Olucha-fresh",
              balloonContent: store.address,
            },
            {
              preset: "islands#greenShoppingIcon",
            },
          )
          map.geoObjects.add(storePoint)

          // Добавляем круг радиуса доставки (10 км)
          const deliveryZone = new window.ymaps.Circle(
            [store.coords, 10000],
            {
              hintContent: "Зона доставки (10 км)",
            },
            {
              fillColor: "#22c55e33",
              strokeColor: "#16a34a",
              strokeWidth: 2,
            },
          )
          map.geoObjects.add(deliveryZone)
        })

        setMapLoaded(true)
      } catch (error) {
        console.error("Ошибка при инициализации карты:", error)
      }
    })
  }

  useEffect(() => {
    if (scriptLoaded && mapRef.current) {
      initMap()
    }
  }, [scriptLoaded])

  const handleScriptLoad = () => {
    setScriptLoaded(true)
    setScriptError(false)
  }

  const handleScriptError = () => {
    setScriptError(true)
    setScriptLoaded(false)
  }

  return (
    <div className="space-y-4">
      <Script
        src="https://api-maps.yandex.ru/2.1/?apikey=d2039fa2-1119-4c88-91ff-d5bb1a6c7859&lang=ru_RU"
        onLoad={handleScriptLoad}
        onError={handleScriptError}
      />

      <div className="aspect-video w-full rounded-lg border">
        {scriptError && (
          <div className="flex h-full items-center justify-center bg-gray-100">
            <div className="text-center p-4">
              <p className="text-red-500 font-medium">Не удалось загрузить карту</p>
              <p className="text-sm text-gray-500 mt-2">Пожалуйста, проверьте подключение к интернету</p>
            </div>
          </div>
        )}

        {!scriptError && !mapLoaded && (
          <div className="flex h-full items-center justify-center bg-gray-100">
            <Loader2 className="h-8 w-8 animate-spin text-green-600" />
            <span className="ml-2">Загрузка карты...</span>
          </div>
        )}

        <div ref={mapRef} className="h-full w-full rounded-lg"></div>
      </div>

      <div className="rounded-lg bg-green-50 p-4">
        <h3 className="mb-2 font-semibold">Наши магазины:</h3>
        <ul className="space-y-2">
          {storeCoordinates.map((store) => (
            <li key={store.id} className="flex items-start gap-2">
              <MapPin className="h-5 w-5 text-green-600 mt-0.5" />
              <span>{store.address}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="text-xs text-gray-500 flex items-center justify-center">
        <span>© Карта предоставлена </span>
        <a
          href="https://yandex.ru/maps"
          target="_blank"
          rel="noopener noreferrer"
          className="text-green-600 hover:underline ml-1 inline-flex items-center"
        >
          Яндекс Картами <ExternalLink className="h-3 w-3 ml-0.5" />
        </a>
      </div>
    </div>
  )
}
