"use client"

import { useState, useEffect } from "react"
import { X, Download, Plus, ArrowDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface PWABannerProps {
  position?: "top" | "bottom"
  className?: string
}

export function PWABanner({ position = "bottom", className }: PWABannerProps) {
  const [showBanner, setShowBanner] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [isIOS, setIsIOS] = useState(false)

  useEffect(() => {
    // Проверяем, был ли баннер уже закрыт
    const bannerClosed = localStorage.getItem("pwa_banner_closed")
    const bannerInstalled = localStorage.getItem("pwa_installed")

    if (bannerClosed || bannerInstalled) {
      return
    }

    // Определяем iOS устройства
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream
    setIsIOS(isIOSDevice)

    // Для не-iOS устройств используем стандартный механизм PWA
    if (!isIOSDevice) {
      const handleBeforeInstallPrompt = (e: Event) => {
        // Предотвращаем показ стандартного баннера браузера
        e.preventDefault()
        // Сохраняем событие, чтобы использовать его позже
        setDeferredPrompt(e)
        // Показываем наш баннер
        setShowBanner(true)
      }

      window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

      return () => {
        window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
      }
    } else {
      // Для iOS просто показываем баннер с инструкциями
      // Проверяем, запущено ли приложение в режиме standalone (уже установлено)
      const isStandalone = "standalone" in window.navigator && (window.navigator as any).standalone === true
      if (!isStandalone) {
        setShowBanner(true)
      }
    }
  }, [])

  const handleAddToHomeScreen = async () => {
    if (isIOS) {
      // Для iOS просто показываем инструкции
      return
    }

    if (!deferredPrompt) return

    // Показываем диалог установки
    deferredPrompt.prompt()

    // Ждем ответа пользователя
    const { outcome } = await deferredPrompt.userChoice
    console.log(`User response: ${outcome}`)

    if (outcome === "accepted") {
      localStorage.setItem("pwa_installed", "true")
    }

    // Очищаем сохраненное событие
    setDeferredPrompt(null)
    // Скрываем баннер
    setShowBanner(false)
  }

  const handleClose = () => {
    setShowBanner(false)
    // Запоминаем, что пользователь закрыл баннер
    localStorage.setItem("pwa_banner_closed", "true")
  }

  if (!showBanner) return null

  return (
    <Card
      className={cn(
        "fixed z-50 left-4 right-4 md:left-auto md:right-4 md:w-80 shadow-lg border border-green-100 dark:border-green-900 bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900/50 dark:to-green-800/50",
        position === "top" ? "top-4" : "bottom-16 md:bottom-4",
        className,
      )}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-medium text-gray-900 dark:text-gray-100 flex items-center">
              <Download className="h-4 w-4 mr-2 text-green-600 dark:text-green-400" />
              Добавьте на главный экран
            </h3>

            {isIOS ? (
              <div className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                <p className="mb-1">Чтобы установить приложение:</p>
                <ol className="list-decimal pl-5 space-y-1">
                  <li>
                    Нажмите{" "}
                    <span className="inline-flex items-center">
                      <ArrowDown className="h-3 w-3 mx-1" />
                    </span>{" "}
                    (Поделиться)
                  </li>
                  <li>
                    Прокрутите и выберите{" "}
                    <span className="inline-flex items-center">
                      <Plus className="h-3 w-3 mx-1" />
                    </span>{" "}
                    "На экран «‎Домой»"
                  </li>
                </ol>
              </div>
            ) : (
              <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                Установите наше приложение для быстрого доступа к свежим продуктам
              </p>
            )}

            <div className="mt-3 flex gap-2">
              {!isIOS && (
                <Button
                  size="sm"
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={handleAddToHomeScreen}
                >
                  Установить
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={handleClose}>
                {isIOS ? "Понятно" : "Не сейчас"}
              </Button>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="h-6 w-6 -mt-1 -mr-1" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
