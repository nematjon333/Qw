"use client"

import { useState } from "react"
import dynamic from "next/dynamic"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { STORE_LATITUDE, STORE_LONGITUDE } from "@/lib/dadata-service"

// Динамически импортируем карту доставки с отключенным SSR
const DeliveryMap = dynamic(() => import("./delivery-map/delivery-map"), {
  ssr: false,
  loading: () => <Skeleton className="w-full h-[400px] rounded-md" />,
})

interface CheckoutMapProps {
  onAddressSelect: (address: any, coordinates: [number, number]) => void
  initialAddress?: string
  initialCoordinates?: [number, number]
  storeCoordinates?: [number, number]
}

export default function CheckoutMap({
  onAddressSelect,
  initialAddress,
  initialCoordinates,
  storeCoordinates = [STORE_LATITUDE, STORE_LONGITUDE],
}: CheckoutMapProps) {
  const [error, setError] = useState<string | null>(null)

  // Обработчик выбора адреса с расчетом расстояния
  const handleAddressSelect = (address: any, coordinates: [number, number], distance: number) => {
    // Проверяем, что адрес и координаты корректны
    if (!address || !coordinates || coordinates.length !== 2) {
      setError("Некорректный адрес или координаты")
      return
    }

    // Сбрасываем ошибку, если она была
    if (error) setError(null)

    // Вызываем колбэк с выбранным адресом и координатами
    onAddressSelect(address, coordinates)

    // Сохраняем адрес в localStorage для последующего использования
    try {
      localStorage.setItem(
        "deliveryAddress",
        JSON.stringify({
          address: typeof address === "string" ? address : address.value || "",
          coordinates,
          distance,
        }),
      )
    } catch (err) {
      console.error("Error saving address to localStorage:", err)
    }
  }

  return (
    <div className="space-y-2">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <DeliveryMap
        onAddressSelect={handleAddressSelect}
        initialAddress={initialAddress}
        initialCoordinates={initialCoordinates}
        storeCoordinates={storeCoordinates}
      />
    </div>
  )
}

// Также экспортируем как именованный экспорт для обратной совместимости
export { CheckoutMap }
