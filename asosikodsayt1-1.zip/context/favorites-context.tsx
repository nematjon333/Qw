"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface FavoriteItem {
  id: string
  name: string
  price: number
  image?: string
  unit?: string
  discount?: number
}

interface FavoritesContextType {
  items: FavoriteItem[]
  addItem: (item: FavoriteItem) => void
  removeItem: (id: string) => void
  clearFavorites: () => void
  isInFavorites: (id: string) => boolean
  itemCount: number
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined)

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<FavoriteItem[]>([])

  // Загрузка избранного из localStorage при инициализации
  useEffect(() => {
    try {
      const savedFavorites = localStorage.getItem("favorites")
      if (savedFavorites) {
        setItems(JSON.parse(savedFavorites))
      }
    } catch (error) {
      console.error("Ошибка при загрузке избранного:", error)
      // If there's an error, initialize with empty array
      setItems([])
    }
  }, [])

  // Сохранение избранного в localStorage при изменении
  useEffect(() => {
    try {
      localStorage.setItem("favorites", JSON.stringify(items))
    } catch (error) {
      console.error("Ошибка при сохранении избранного:", error)
    }
  }, [items])

  const addItem = (item: FavoriteItem) => {
    setItems((prevItems) => {
      // Check if item already exists
      if (prevItems.some((i) => i.id === item.id)) {
        return prevItems
      }
      return [...prevItems, item]
    })
  }

  const removeItem = (id: string) => {
    setItems((prevItems) => prevItems.filter((item) => item.id !== id))
  }

  const clearFavorites = () => {
    setItems([])
    try {
      localStorage.removeItem("favorites")
    } catch (error) {
      console.error("Ошибка при очистке избранного:", error)
    }
  }

  const isInFavorites = (id: string) => {
    return items.some((item) => item.id === id)
  }

  // Расчет общего количества товаров в избранном
  const itemCount = items.length

  return (
    <FavoritesContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        clearFavorites,
        isInFavorites,
        itemCount,
      }}
    >
      {children}
    </FavoritesContext.Provider>
  )
}

export function useFavorites() {
  const context = useContext(FavoritesContext)
  if (context === undefined) {
    throw new Error("useFavorites must be used within a FavoritesProvider")
  }
  return context
}
