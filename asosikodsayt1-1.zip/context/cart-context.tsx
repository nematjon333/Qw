"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { supabase } from "@/lib/supabase-client"
import { CartAddressModal } from "@/components/cart-address-modal"

export interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  unit: string
  image?: string
  discount?: number
  weight?: number
  stockQuantity?: number
  dimensions?: {
    length: number
    width: number
    height: number
  }
}

interface DeliveryInfo {
  fee: number
  minOrderAmount: number
  freeDeliveryThreshold: number | null
  estimatedTime: number
  isSurgeActive: boolean
  surgeReason: string | null
  zoneName: string
}

// Добавим функции isInCart и getItemQuantity в интерфейс CartContextType
interface CartContextType {
  items: CartItem[]
  addItem: (item: CartItem) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  itemCount: number
  subtotal: number
  deliveryFee: number
  setDeliveryFee: (fee: number) => void
  total: number
  promoCode: string | null
  promoDiscount: number
  applyPromoCode: (code: string, discount: number) => void
  removePromoCode: () => void
  validateCartItems: () => Promise<void>
  showAddressModal: boolean
  setShowAddressModal: (show: boolean) => void
  deliveryAddress: string | null
  deliveryCoordinates: [number, number] | null
  deliveryDistance: number | null
  setDeliveryAddress: (address: string, coordinates: [number, number], distance: number) => void
  deliveryInfo: DeliveryInfo | null
  setDeliveryInfo: (info: DeliveryInfo | null) => void
  checkMinimumOrderAmount: () => { isValid: boolean; minAmount: number | null }
  checkFreeDeliveryThreshold: () => { isFree: boolean; threshold: number | null; remaining: number | null }
  isInCart: (id: string) => boolean
  getItemQuantity: (id: string) => number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

// Добавим реализации функций в CartProvider
export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [deliveryFee, setDeliveryFee] = useState(0)
  const [promoCode, setPromoCode] = useState<string | null>(null)
  const [promoDiscount, setPromoDiscount] = useState(0)
  const [showAddressModal, setShowAddressModal] = useState(false)
  const [deliveryAddress, setDeliveryAddressState] = useState<string | null>(null)
  const [deliveryCoordinates, setDeliveryCoordinates] = useState<[number, number] | null>(null)
  const [deliveryDistance, setDeliveryDistance] = useState<number | null>(null)
  const [deliveryInfo, setDeliveryInfo] = useState<DeliveryInfo | null>(null)

  // Загрузка корзины из localStorage при инициализации
  useEffect(() => {
    const savedCart = localStorage.getItem("cart")
    const savedPromo = localStorage.getItem("promoCode")
    const savedPromoDiscount = localStorage.getItem("promoDiscount")

    if (savedCart) {
      try {
        setItems(JSON.parse(savedCart))
      } catch (error) {
        console.error("Ошибка при загрузке корзины:", error)
      }
    }

    if (savedPromo) {
      setPromoCode(savedPromo)
    }

    if (savedPromoDiscount) {
      try {
        setPromoDiscount(Number(savedPromoDiscount))
      } catch (error) {
        console.error("Ошибка при загрузке скидки по промокоду:", error)
      }
    }
  }, [])

  // Validate cart items on initial load and periodically
  useEffect(() => {
    // Validate cart items on initial load
    if (items.length > 0) {
      validateCartItems()
    }

    // Set up periodic validation (every minute)
    const intervalId = setInterval(() => {
      if (items.length > 0) {
        validateCartItems()
      }
    }, 60 * 1000)

    return () => clearInterval(intervalId)
  }, [items.length])

  // Сохранение корзины в localStorage при изменении
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(items))
  }, [items])

  // Сохранение промокода в localStorage при изменении
  useEffect(() => {
    if (promoCode) {
      localStorage.setItem("promoCode", promoCode)
    } else {
      localStorage.removeItem("promoCode")
    }
  }, [promoCode])

  // Сохранение скидки по промокоду в localStorage при изменении
  useEffect(() => {
    localStorage.setItem("promoDiscount", promoDiscount.toString())
  }, [promoDiscount])

  // Загрузка сохраненного адреса доставки
  useEffect(() => {
    const savedAddress = localStorage.getItem("deliveryAddress")
    if (savedAddress) {
      try {
        const addressData = JSON.parse(savedAddress)
        setDeliveryAddressState(addressData.address)
        setDeliveryCoordinates(addressData.coordinates)
        setDeliveryDistance(addressData.distance)
      } catch (error) {
        console.error("Ошибка при загрузке сохраненного адреса:", error)
      }
    }
  }, [])

  // Сброс корзины в 22:59 по времени Челябинска (UTC+5)
  useEffect(() => {
    const checkTimeAndResetCart = () => {
      // Получаем текущее время в Челябинске (UTC+5)
      const now = new Date()
      const chelyabinskTime = new Date(now.getTime() + 5 * 60 * 60 * 1000) // UTC+5

      const hours = chelyabinskTime.getUTCHours()
      const minutes = chelyabinskTime.getUTCMinutes()

      // Если время 22:59 по Челябинску, сбрасываем корзину
      if (hours === 22 && minutes === 59) {
        clearCart()
        console.log("Корзина автоматически очищена в 22:59 по времени Челябинска")
      }
    }

    // Проверяем время каждую минуту
    const intervalId = setInterval(checkTimeAndResetCart, 60 * 1000)

    return () => clearInterval(intervalId)
  }, [])

  // Validate cart items against current product stock
  const validateCartItems = async () => {
    try {
      // Get all product IDs in the cart
      const productIds = items.map((item) => item.id)

      if (productIds.length === 0) return

      // Fetch current product data from Supabase
      // Removed the slug field from the query since it doesn't exist in the database
      const { data: products, error } = await supabase
        .from("products")
        .select("id, stock_quantity, active, price, discount")
        .in("id", productIds)

      if (error) {
        console.error("Error fetching product data:", error)
        return
      }

      // Create a map of product data for easy lookup
      const productMap = new Map(products.map((p) => [p.id, p]))

      // Update cart items based on current product data
      const updatedItems = items.map((item) => {
        const product = productMap.get(item.id)

        // If product doesn't exist or is inactive, mark as out of stock
        if (!product || !product.active) {
          return { ...item, stockQuantity: 0 }
        }

        // Update stock quantity and price information
        // Removed the slug property since it doesn't exist in the database
        return {
          ...item,
          stockQuantity: product.stock_quantity || 0,
          price: product.price,
          discount: product.discount,
        }
      })

      // Update cart items
      setItems(updatedItems)
    } catch (error) {
      console.error("Error validating cart items:", error)
    }
  }

  const addItem = (item: CartItem) => {
    setItems((prevItems) => {
      const existingItem = prevItems.find((i) => i.id === item.id)
      if (existingItem) {
        return prevItems.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + item.quantity, stockQuantity: item.stockQuantity } : i,
        )
      } else {
        return [...prevItems, item]
      }
    })

    // Show address modal if no delivery address is set
    if (!deliveryAddress) {
      setShowAddressModal(true)
    }
  }

  const removeItem = (id: string) => {
    setItems((prevItems) => prevItems.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(id)
      return
    }

    setItems((prevItems) => prevItems.map((item) => (item.id === id ? { ...item, quantity } : item)))
  }

  const clearCart = () => {
    setItems([])
    setPromoCode(null)
    setPromoDiscount(0)
    localStorage.removeItem("cart")
    localStorage.removeItem("promoCode")
    localStorage.removeItem("promoDiscount")
  }

  const applyPromoCode = (code: string, discount: number) => {
    setPromoCode(code)
    setPromoDiscount(discount)
  }

  const removePromoCode = () => {
    setPromoCode(null)
    setPromoDiscount(0)
  }

  const setDeliveryAddress = (address: string, coordinates: [number, number], distance: number) => {
    setDeliveryAddressState(address)
    setDeliveryCoordinates(coordinates)
    setDeliveryDistance(distance)

    // Save to localStorage
    const addressData = {
      address,
      coordinates,
      distance,
    }
    localStorage.setItem("deliveryAddress", JSON.stringify(addressData))
  }

  // Проверка минимальной суммы заказа
  const checkMinimumOrderAmount = () => {
    if (!deliveryInfo || !deliveryInfo.minOrderAmount) {
      return { isValid: true, minAmount: null }
    }

    const currentTotal = subtotal - promoDiscount
    return {
      isValid: currentTotal >= deliveryInfo.minOrderAmount,
      minAmount: deliveryInfo.minOrderAmount,
    }
  }

  // Проверка порога бесплатной доставки
  const checkFreeDeliveryThreshold = () => {
    if (!deliveryInfo || !deliveryInfo.freeDeliveryThreshold) {
      return { isFree: false, threshold: null, remaining: null }
    }

    const currentTotal = subtotal - promoDiscount
    const remaining = deliveryInfo.freeDeliveryThreshold - currentTotal

    return {
      isFree: currentTotal >= deliveryInfo.freeDeliveryThreshold,
      threshold: deliveryInfo.freeDeliveryThreshold,
      remaining: remaining > 0 ? remaining : 0,
    }
  }

  // Расчет общего количества товаров
  const itemCount = items.reduce((count, item) => {
    // Only count items that are in stock
    return item.stockQuantity && item.stockQuantity > 0 ? count + item.quantity : count
  }, 0)

  // Расчет суммы товаров
  const subtotal = items.reduce((total, item) => {
    // Skip items that are out of stock
    if (!item.stockQuantity || item.stockQuantity <= 0) return total

    const price = item.discount ? item.price - (item.price * item.discount) / 100 : item.price
    return total + price * item.quantity
  }, 0)

  // Расчет общей суммы
  const total = subtotal - promoDiscount + deliveryFee

  // Добавляем функцию проверки наличия товара в корзине
  const isInCart = (id: string) => {
    return items.some((item) => item.id === id)
  }

  // Добавляем функцию получения количества товара в корзине
  const getItemQuantity = (id: string) => {
    const item = items.find((item) => item.id === id)
    return item ? item.quantity : 0
  }

  // В return добавляем новые функции
  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        itemCount,
        subtotal,
        deliveryFee,
        setDeliveryFee,
        total,
        promoCode,
        promoDiscount,
        applyPromoCode,
        removePromoCode,
        validateCartItems,
        showAddressModal,
        setShowAddressModal,
        deliveryAddress,
        deliveryCoordinates,
        deliveryDistance,
        setDeliveryAddress,
        deliveryInfo,
        setDeliveryInfo,
        checkMinimumOrderAmount,
        checkFreeDeliveryThreshold,
        isInCart,
        getItemQuantity,
      }}
    >
      {children}
      <CartAddressModal
        isOpen={showAddressModal}
        onClose={() => setShowAddressModal(false)}
        onAddressConfirm={setDeliveryAddress}
      />
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
