"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, CreditCard, Loader2, MapPin, X, Zap } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useCart } from "@/context/cart-context"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { toast } from "@/components/ui/use-toast"
import { CheckoutMap } from "@/components/checkout-map"
import { PromoCodeInput } from "@/components/promo-code-input"
import { Badge } from "@/components/ui/badge"
import { DeliveryInfoCard } from "@/components/delivery-info-card"

// Импортируем функцию для отслеживания событий
import { ecommerceEvents } from "@/lib/analytics"
import {
  isAddressInRange,
  MAX_DELIVERY_DISTANCE,
  calculateDistance,
  STORE_LATITUDE,
  STORE_LONGITUDE,
} from "@/lib/dadata-service"

export default function CheckoutPage() {
  const router = useRouter()
  const {
    items,
    subtotal,
    deliveryFee,
    total,
    clearCart,
    promoCode,
    promoDiscount,
    applyPromoCode,
    removePromoCode,
    setDeliveryFee,
    deliveryInfo,
    setDeliveryInfo,
    checkMinimumOrderAmount,
    checkFreeDeliveryThreshold,
  } = useCart()

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    address: "",
    entrance: "",
    floor: "",
    deliveryType: "door",
    paymentMethod: "cash",
    comment: "",
  })
  const [coordinates, setCoordinates] = useState<[number, number] | null>(null)
  const [distance, setDistance] = useState<number | null>(null)
  const [isWithinDeliveryZone, setIsWithinDeliveryZone] = useState(true)
  const [formErrors, setFormErrors] = useState({
    name: false,
    phone: false,
    address: false,
  })
  const [debugInfo, setDebugInfo] = useState<string | null>(null)

  // Состояния для доставки
  const [isLoadingDeliveryInfo, setIsLoadingDeliveryInfo] = useState(false)
  const [deliveryError, setDeliveryError] = useState<string | null>(null)
  const [deliveryZone, setDeliveryZone] = useState<any>(null)

  // Проверки для минимальной суммы заказа и бесплатной доставки
  const minimumOrderCheck = checkMinimumOrderAmount()
  const freeDeliveryCheck = checkFreeDeliveryThreshold()

  // Добавим useEffect для отслеживания начала оформления заказа
  useEffect(() => {
    if (items.length > 0) {
      // Отслеживаем начало оформления заказа
      ecommerceEvents.beginCheckout({
        items,
        total,
      })
    }
  }, []) // Пустой массив зависимостей, чтобы событие сработало только при монтировании компонента

  // Загрузка сохраненных данных пользователя
  useEffect(() => {
    const savedUserData = localStorage.getItem("userData")
    if (savedUserData) {
      try {
        const userData = JSON.parse(savedUserData)
        setFormData((prev) => ({
          ...prev,
          name: userData.name || prev.name,
          phone: userData.phone || prev.phone,
          address: userData.address || prev.address,
          entrance: userData.entrance || prev.entrance,
          floor: userData.floor || prev.floor,
        }))
      } catch (error) {
        console.error("Ошибка при загрузке данных пользователя:", error)
      }
    }
  }, [])

  // Add this useEffect after the other initialization useEffects
  useEffect(() => {
    // Load saved delivery address
    const savedAddress = localStorage.getItem("deliveryAddress")
    if (savedAddress) {
      try {
        const addressData = JSON.parse(savedAddress)
        setFormData((prev) => ({
          ...prev,
          address: addressData.address,
        }))
        setCoordinates(addressData.coordinates)
        setDistance(addressData.distance)

        // Проверяем, находится ли адрес в пределах максимального расстояния доставки
        if (addressData.coordinates && addressData.coordinates.length === 2) {
          const isInRange = isAddressInRange(
            addressData.coordinates[0],
            addressData.coordinates[1],
            MAX_DELIVERY_DISTANCE,
          )
          setIsWithinDeliveryZone(isInRange)
        }

        // Fetch delivery info for the saved address
        fetchDeliveryInfo(addressData.coordinates, addressData.distance)
      } catch (error) {
        console.error("Ошибка при загрузке сохраненного адреса:", error)
      }
    }
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Сбрасываем ошибку для поля при изменении
    if (formErrors[name]) {
      setFormErrors((prev) => ({ ...prev, [name]: false }))
    }
  }

  const handleRadioChange = (name, value) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Исправим функцию handleAddressSelect для корректной обработки выбора адреса
  const handleAddressSelect = async (address: any, coords: [number, number]) => {
    // Проверяем, что address - это объект и имеет свойство value
    if (address && typeof address === "object" && address.value) {
      setFormData((prev) => ({ ...prev, address: address.value }))
    } else if (typeof address === "string") {
      setFormData((prev) => ({ ...prev, address: address }))
    } else {
      // Если address не имеет нужной структуры, используем координаты
      setFormData((prev) => ({ ...prev, address: `${coords[0].toFixed(6)}, ${coords[1].toFixed(6)}` }))
    }

    setCoordinates(coords)

    // Рассчитываем расстояние от магазина до точки доставки
    const calculatedDistance = calculateDistance(STORE_LATITUDE, STORE_LONGITUDE, coords[0], coords[1])
    setDistance(calculatedDistance)

    // Проверяем, находится ли адрес в пределах максимального расстояния доставки
    const isInRange = isAddressInRange(coords[0], coords[1], MAX_DELIVERY_DISTANCE)
    setIsWithinDeliveryZone(isInRange)

    // Сбрасываем ошибку для адреса при выборе
    if (formErrors.address) {
      setFormErrors((prev) => ({ ...prev, address: false }))
    }

    // Получаем информацию о доставке
    await fetchDeliveryInfo(coords, calculatedDistance)

    // Сохраняем адрес в localStorage
    try {
      localStorage.setItem(
        "deliveryAddress",
        JSON.stringify({
          address: typeof address === "string" ? address : address.value || "",
          coordinates: coords,
          distance: calculatedDistance,
        }),
      )
    } catch (err) {
      console.error("Error saving address to localStorage:", err)
    }
  }

  // Исправим функцию fetchDeliveryInfo для корректного расчета стоимости доставки
  async function fetchDeliveryInfo(coords: [number, number], distance: number) {
    try {
      setIsLoadingDeliveryInfo(true)
      setDeliveryError(null) // Сбрасываем предыдущие ошибки

      console.log("Fetching delivery info for coordinates:", coords, "distance:", distance)

      const response = await fetch("/api/delivery-zones/calculate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          latitude: coords[0],
          longitude: coords[1],
          distance: distance,
        }),
        cache: "no-store",
      })

      // Проверяем тип контента ответа
      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        // Если ответ не JSON, получаем текст ошибки
        const errorText = await response.text()
        console.error("Сервер вернул не JSON ответ:", errorText)
        throw new Error("Сервер вернул некорректный формат ответа. Пожалуйста, попробуйте позже.")
      }

      // Теперь безопасно парсим JSON
      const data = await response.json()
      console.log("Delivery info response:", data)

      if (!response.ok) {
        const errorMessage = data.error || data.message || `Ошибка сервера: ${response.status}`
        console.error("Ошибка при расчете доставки:", errorMessage)
        throw new Error(`Ошибка при расчете доставки: ${errorMessage}`)
      }

      // Проверяем наличие ошибки в ответе
      if (data.error) {
        console.error("Ошибка в ответе API:", data.error)
        throw new Error(`Ошибка при расчете доставки: ${data.error}`)
      }

      setDeliveryInfo(data)
      setDeliveryFee(data.fee || 0)

      if (data.zoneName) {
        setDeliveryZone({
          name: data.zoneName,
          id: data.zoneId,
          minOrderAmount: data.minOrderAmount,
          freeDeliveryThreshold: data.freeDeliveryThreshold,
        })
      }

      return data
    } catch (error) {
      console.error("Ошибка при получении информации о доставке:", error)
      setDeliveryError(
        `Ошибка при получении информации о доставке: ${error instanceof Error ? error.message : String(error)}`,
      )
      // Возвращаем базовую информацию о доставке при ошибке
      return {
        isDeliveryAvailable: false,
        fee: 0,
        minOrderAmount: 0,
        message: "Не удалось рассчитать стоимость доставки",
        distance: distance,
        estimatedTime: "Недоступно",
      }
    } finally {
      setIsLoadingDeliveryInfo(false)
    }
  }

  const validateForm = () => {
    const errors = {
      name: !formData.name.trim(),
      phone: !formData.phone.trim(),
      address: !formData.address.trim(),
    }

    setFormErrors(errors)

    return !Object.values(errors).some(Boolean)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")
    setDebugInfo(null)

    if (items.length === 0) {
      setError("Ваша корзина пуста")
      return
    }

    if (!isWithinDeliveryZone) {
      setError("Доставка по указанному адресу недоступна")
      return
    }

    if (!deliveryInfo) {
      setError("Пожалуйста, выберите адрес доставки")
      return
    }

    // Проверка минимальной суммы заказа
    if (!minimumOrderCheck.isValid) {
      setError(`Минимальная сумма заказа для выбранной зоны: ${minimumOrderCheck.minAmount} ₽`)
      return
    }

    if (!validateForm()) {
      setError("Пожалуйста, заполните все обязательные поля")
      return
    }

    setIsSubmitting(true)

    try {
      // Сохраняем данные пользователя для будущих заказов
      const userData = {
        name: formData.name,
        phone: formData.phone,
        address: formData.address,
        entrance: formData.entrance,
        floor: formData.floor,
      }
      localStorage.setItem("userData", JSON.stringify(userData))

      // Подготовка данных для отправки
      const orderData = {
        items: items.map((item) => ({
          id: item.id,
          name: item.name,
          price: Number(item.price),
          quantity: Number(item.quantity),
          unit: item.unit,
          discount: item.discount ? Number(item.discount) : undefined,
          image: item.image,
        })),
        customer: {
          ...formData,
          phone: formData.phone.replace(/\D/g, ""), // Удаляем все нецифровые символы
        },
        totals: {
          subtotal: Number(subtotal),
          deliveryFee: deliveryInfo.fee,
          promoCode: promoCode,
          promoDiscount: Number(promoDiscount),
          total: Number(subtotal - promoDiscount + deliveryInfo.fee),
        },
        delivery: {
          zone: deliveryInfo.zoneName,
          fee: deliveryInfo.fee,
          estimatedTime: deliveryInfo.estimatedTime,
          coordinates: coordinates,
          distance: distance,
          zoneName: deliveryZone ? deliveryZone.name : null,
        },
      }

      // Для отладки
      setDebugInfo(JSON.stringify(orderData, null, 2))

      // Отправка данных на сервер
      const response = await fetch("/api/order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(orderData),
      })

      // Проверяем тип контента ответа
      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        // Если ответ не JSON, получаем текст ошибки
        const errorText = await response.text()
        console.error("Сервер вернул не JSON ответ:", errorText)
        throw new Error("Сервер вернул некорректный формат ответа. Пожалуйста, попробуйте позже.")
      }

      const data = await response.json()

      if (!response.ok) {
        console.error("Server error:", data)
        throw new Error(data.message || "Ошибка при оформлении заказа")
      }

      if (data.success) {
        // Очищаем корзину
        clearCart()

        // Показываем уведомление
        toast({
          title: "Заказ успешно оформлен",
          description: `Номер заказа: ${data.orderNumber || "N/A"}`,
          duration: 5000,
          variant: "success",
        })

        // Создаем данные для WhatsApp
        const whatsappData = {
          order_number: data.orderNumber || "N/A",
          customer_name: formData.name,
          customer_phone: formData.phone,
          customer_address: formData.address,
          items: items,
          total: subtotal - promoDiscount + deliveryInfo.fee,
          delivery: deliveryInfo.zoneName,
        }

        // Сохраняем данные заказа в localStorage для использования на странице успеха
        localStorage.setItem("lastOrderData", JSON.stringify(whatsappData))

        // Перенаправление на страницу успешного оформления заказа
        router.push("/checkout/success")
      } else {
        console.error("Order creation failed:", data)
        throw new Error(data.message || "Ошибка при оформлении заказа")
      }
    } catch (error) {
      console.error("Error details:", error)
      setError(error.message || "Произошла ошибка при оформлении заказа. Пожалуйста, попробуйте еще раз.")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Функция для перевода способа оплаты на русский
  const getPaymentMethodText = (method) => {
    switch (method) {
      case "cash":
        return "Наличными при получении"
      case "online":
        return "Онлайн оплата"
      default:
        return method
    }
  }

  // Функция для перевода типа доставки на русский
  const getDeliveryTypeText = (type) => {
    switch (type) {
      case "door":
        return "До двери"
      case "entrance":
        return "До подъезда"
      default:
        return type
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-8">
          <div className="mb-4 flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link href="/cart">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад в корзину
              </Link>
            </Button>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              <Link href="/" className="hover:text-green-600 dark:hover:text-green-400">
                Главная
              </Link>
              {" > "}
              <Link href="/cart" className="hover:text-green-600 dark:hover:text-green-400">
                Корзина
              </Link>
              {" > "}
              <span>Оформление заказа</span>
            </div>
          </div>

          <h1 className="mb-6 text-3xl font-bold">Оформление заказа</h1>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertTitle>Ошибка</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {debugInfo && (
            <Alert className="mb-6 bg-gray-100 dark:bg-gray-800">
              <AlertTitle>Отладочная информация</AlertTitle>
              <AlertDescription>
                <pre className="whitespace-pre-wrap text-xs">{debugInfo}</pre>
              </AlertDescription>
            </Alert>
          )}

          {items.length === 0 ? (
            <div className="rounded-lg border p-6 text-center dark:border-gray-700">
              <p className="mb-4">Ваша корзина пуста. Добавьте товары перед оформлением заказа.</p>
              <Button asChild className="bg-green-600 hover:bg-green-700">
                <Link href="/catalog">Перейти в каталог</Link>
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="rounded-lg border p-6 space-y-6 modern-card dark:border-gray-700">
                    <h2 className="text-xl font-semibold flex items-center gap-2 modern-heading">
                      <MapPin className="h-5 w-5 text-green-600" />
                      Адрес доставки
                    </h2>

                    <CheckoutMap
                      onAddressSelect={handleAddressSelect}
                      initialAddress={formData.address}
                      initialCoordinates={coordinates || undefined}
                    />

                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div className="md:col-span-2">
                        <Label htmlFor="address" className={formErrors.address ? "text-red-500" : ""}>
                          Адрес <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="address"
                          name="address"
                          placeholder="Улица, дом"
                          value={formData.address}
                          onChange={handleChange}
                          required
                          className={`modern-input ${formErrors.address ? "border-red-500" : ""}`}
                        />
                        {formErrors.address && (
                          <p className="mt-1 text-xs text-red-500">Пожалуйста, укажите адрес доставки</p>
                        )}
                      </div>
                      <div>
                        <Label htmlFor="entrance">Подъезд</Label>
                        <Input
                          id="entrance"
                          name="entrance"
                          placeholder="Номер подъезда"
                          value={formData.entrance}
                          onChange={handleChange}
                          className="modern-input"
                        />
                      </div>
                      <div>
                        <Label htmlFor="floor">Этаж</Label>
                        <Input
                          id="floor"
                          name="floor"
                          placeholder="Номер этажа"
                          value={formData.floor}
                          onChange={handleChange}
                          className="modern-input"
                        />
                      </div>
                    </div>

                    {/* Информация о доставке */}
                    {(deliveryInfo || isLoadingDeliveryInfo || deliveryError) && (
                      <DeliveryInfoCard
                        deliveryInfo={deliveryInfo}
                        isLoading={isLoadingDeliveryInfo}
                        error={deliveryError}
                      />
                    )}

                    <div className="space-y-2">
                      <Label className="mb-2 block">Тип доставки</Label>
                      <RadioGroup
                        value={formData.deliveryType}
                        onValueChange={(value) => handleRadioChange("deliveryType", value)}
                        className="grid grid-cols-2 gap-4"
                      >
                        <div
                          className={`p-4 rounded-lg border cursor-pointer transition-all ${
                            formData.deliveryType === "door"
                              ? "border-green-500 bg-green-50 dark:bg-green-900/20 dark:border-green-700"
                              : "hover:border-gray-300 dark:border-gray-700 dark:hover:border-gray-600"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <RadioGroupItem value="door" id="door" />
                            <Label htmlFor="door" className="cursor-pointer">
                              До двери
                            </Label>
                          </div>
                        </div>
                        <div
                          className={`p-4 rounded-lg border cursor-pointer transition-all ${
                            formData.deliveryType === "entrance"
                              ? "border-green-500 bg-green-50 dark:bg-green-900/20 dark:border-green-700"
                              : "hover:border-gray-300 dark:border-gray-700 dark:hover:border-gray-600"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <RadioGroupItem value="entrance" id="entrance-radio" />
                            <Label htmlFor="entrance-radio" className="cursor-pointer">
                              До подъезда
                            </Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>

                  <div className="rounded-lg border p-6 dark:border-gray-700">
                    <h2 className="mb-4 text-xl font-semibold">Контактная информация</h2>
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div>
                        <Label htmlFor="name" className={formErrors.name ? "text-red-500" : ""}>
                          Имя <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="name"
                          name="name"
                          placeholder="Ваше имя"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className={formErrors.name ? "border-red-500" : ""}
                        />
                        {formErrors.name && <p className="mt-1 text-xs text-red-500">Пожалуйста, укажите ваше имя</p>}
                      </div>
                      <div>
                        <Label htmlFor="phone" className={formErrors.phone ? "text-red-500" : ""}>
                          Телефон <span className="text-red-500">*</span>
                        </Label>
                        <Input
                          id="phone"
                          name="phone"
                          placeholder="Ваш телефон"
                          value={formData.phone}
                          onChange={handleChange}
                          required
                          className={formErrors.phone ? "border-red-500" : ""}
                        />
                        {formErrors.phone && (
                          <p className="mt-1 text-xs text-red-500">Пожалуйста, укажите ваш телефон</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-6 dark:border-gray-700">
                    <h2 className="mb-4 text-xl font-semibold flex items-center gap-2">
                      <CreditCard className="h-5 w-5 text-green-600" />
                      Способ оплаты
                    </h2>
                    <RadioGroup
                      defaultValue="cash"
                      value={formData.paymentMethod}
                      onValueChange={(value) => handleRadioChange("paymentMethod", value)}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="cash" id="cash" />
                        <Label htmlFor="cash">Наличными при получении</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="online" id="online" />
                        <Label htmlFor="online">Онлайн оплата</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="rounded-lg border p-6 dark:border-gray-700">
                    <h2 className="mb-4 text-xl font-semibold">Дополнительно</h2>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="comment">Комментарий к заказу</Label>
                        <Textarea
                          id="comment"
                          name="comment"
                          placeholder="Дополнительная информация к заказу"
                          value={formData.comment}
                          onChange={handleChange}
                        />
                      </div>

                      {!promoCode && <PromoCodeInput subtotal={subtotal} onApply={applyPromoCode} />}
                    </div>
                  </div>
                </form>
              </div>

              <div>
                <div className="rounded-lg border p-6 sticky top-20 dark:border-gray-700">
                  <h2 className="mb-4 text-xl font-semibold">Ваш заказ</h2>
                  <div className="space-y-4">
                    {items.map((item) => {
                      const discountedPrice = item.discount
                        ? item.price - (item.price * item.discount) / 100
                        : item.price
                      return (
                        <div key={item.id} className="flex items-center gap-3">
                          <div className="h-12 w-12 flex-shrink-0 overflow-hidden rounded-md">
                            <img
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{item.name}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              {item.quantity} {item.unit} x {discountedPrice.toFixed(0)} ₽
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">{(discountedPrice * item.quantity).toFixed(0)} ₽</p>
                          </div>
                        </div>
                      )
                    })}

                    <Separator className="dark:border-gray-700" />

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Товары ({items.length})</span>
                        <span>{subtotal.toFixed(0)} ₽</span>
                      </div>

                      {promoCode && (
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600 flex items-center">
                            Промокод:
                            <Badge variant="outline" className="ml-2 font-normal">
                              {promoCode}
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-4 w-4 p-0 ml-1"
                                onClick={removePromoCode}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </Badge>
                          </span>
                          <span className="text-green-600">-{promoDiscount.toFixed(0)} ₽</span>
                        </div>
                      )}

                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Доставка</span>
                        <span>
                          {deliveryInfo ? (
                            <>
                              {deliveryInfo.isSurgeActive && (
                                <Zap className="inline-block h-3 w-3 text-amber-500 mr-1" />
                              )}
                              {deliveryInfo.fee === 0 ? (
                                <span className="text-green-600 dark:text-green-400">Бесплатно</span>
                              ) : (
                                `${deliveryInfo.fee} ₽`
                              )}
                            </>
                          ) : isLoadingDeliveryInfo ? (
                            <span className="flex items-center">
                              <Loader2 className="h-3 w-3 animate-spin mr-1" />
                              Расчет...
                            </span>
                          ) : (
                            "Укажите адрес"
                          )}
                        </span>
                      </div>

                      {deliveryInfo && (
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600 dark:text-gray-400">
                            Время доставки: ~{deliveryInfo.estimatedTime}
                          </span>
                        </div>
                      )}

                      <Separator className="dark:border-gray-700" />
                      <div className="flex justify-between text-lg font-semibold">
                        <span>Итого</span>
                        <span>
                          {deliveryInfo
                            ? (subtotal - promoDiscount + deliveryInfo.fee).toFixed(0)
                            : (subtotal - promoDiscount).toFixed(0)}{" "}
                          ₽
                        </span>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-green-600 hover:bg-green-700"
                      disabled={isSubmitting || !isWithinDeliveryZone}
                      onClick={handleSubmit}
                    >
                      {isSubmitting ? (
                        <>
                          Оформление...
                          <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                        </>
                      ) : (
                        "Оформить заказ"
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
