"use client"

import Link from "next/link"
import { CheckCircle, Home, ShoppingBag, Phone } from "lucide-react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { useCart } from "@/context/cart-context"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

// Импортируем функцию для отслеживания событий
import { ecommerceEvents } from "@/lib/analytics"

interface OrderData {
  order_number: string
  customer_name: string
  customer_phone: string
  customer_address: string
  items: Array<{
    id: string
    name: string
    price: number
    quantity: number
    unit: string
    discount?: number
    image?: string
  }>
  total: number
}

export default function CheckoutSuccessPage() {
  const router = useRouter()
  const { items } = useCart()
  const [orderData, setOrderData] = useState<OrderData | null>(null)
  const [whatsappLink, setWhatsappLink] = useState("")

  // Загружаем данные заказа из localStorage
  useEffect(() => {
    const savedOrderData = localStorage.getItem("lastOrderData")

    if (savedOrderData) {
      try {
        const parsedData = JSON.parse(savedOrderData)
        setOrderData(parsedData)

        // Отслеживаем событие покупки
        if (parsedData) {
          ecommerceEvents.purchase({
            id: parsedData.order_number,
            total: parsedData.total,
            items: parsedData.items || [],
          })
        }

        // Создаем ссылку на WhatsApp
        const whatsappLink = createWhatsAppLink(parsedData)
        setWhatsappLink(whatsappLink)

        // Удаляем данные заказа из localStorage после использования
        localStorage.removeItem("lastOrderData")
      } catch (error) {
        console.error("Ошибка при загрузке данных заказа:", error)
      }
    } else if (items.length > 0) {
      // Если нет данных заказа, но корзина не пуста, перенаправляем на страницу оформления
      router.push("/checkout")
    }
  }, [items, router])

  // Функция для создания ссылки на WhatsApp
  const createWhatsAppLink = (orderData: OrderData): string => {
    if (!orderData) return ""

    const { order_number, customer_name, customer_phone, customer_address, items, total } = orderData

    // Формируем список товаров
    const itemsList = items
      .map((item) => {
        const price = item.discount ? item.price - (item.price * item.discount) / 100 : item.price
        return `${item.name} - ${item.quantity} ${item.unit} x ${price.toFixed(0)}₽`
      })
      .join("\n")

    // Формируем текст сообщения
    const message =
      `Здравствуйте! Я оформил(а) заказ #${order_number}.\n\n` +
      `Имя: ${customer_name}\n` +
      `Телефон: ${customer_phone}\n` +
      `Адрес: ${customer_address}\n\n` +
      `Состав заказа:\n${itemsList}\n\n` +
      `Итого: ${total.toFixed(0)}₽\n\n` +
      `Прошу прислать фотоотчет по заказу.`

    // Кодируем сообщение для URL
    const encodedMessage = encodeURIComponent(message)

    // Формируем ссылку на WhatsApp
    return `https://wa.me/79507249862?text=${encodedMessage}`
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-16">
          <div className="mx-auto max-w-md text-center">
            <div className="mb-6 flex justify-center">
              <CheckCircle className="h-16 w-16 text-green-600" />
            </div>
            <h1 className="mb-4 text-3xl font-bold">Заказ успешно оформлен!</h1>
            <p className="mb-8 text-gray-600 dark:text-gray-400">
              Спасибо за ваш заказ! Мы отправили подтверждение на вашу электронную почту. Наш менеджер свяжется с вами в
              ближайшее время для подтверждения заказа.
            </p>

            {orderData && (
              <div className="mb-8 p-6 bg-green-50 dark:bg-green-900/20 rounded-lg text-left">
                <h2 className="text-xl font-semibold mb-4">Информация о заказе</h2>
                <p className="mb-2">
                  <strong>Номер заказа:</strong> {orderData.order_number}
                </p>
                <p className="mb-2">
                  <strong>Сумма заказа:</strong> {orderData.total.toFixed(0)} ₽
                </p>
                <p className="mb-6">
                  <strong>Статус:</strong> <span className="text-green-600 dark:text-green-400">Принят</span>
                </p>

                <div className="bg-white dark:bg-gray-800 p-4 rounded-lg mb-4">
                  <h3 className="font-medium mb-2">Получить фотоотчет заказа</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    Чтобы получить фотоотчет вашего заказа, напишите нам в WhatsApp
                  </p>
                  <Button asChild className="w-full gap-2 bg-green-600 hover:bg-green-700">
                    <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                      <Phone className="h-4 w-4" />
                      Запросить фотоотчет в WhatsApp
                    </a>
                  </Button>
                </div>
              </div>
            )}

            <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
              <Button asChild className="gap-2 bg-green-600 hover:bg-green-700">
                <Link href="/">
                  <Home className="h-4 w-4" />
                  На главную
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                className="gap-2 border-green-600 text-green-600 hover:bg-green-50 dark:text-green-400 dark:border-green-700 dark:hover:bg-green-900/20"
              >
                <Link href="/catalog">
                  <ShoppingBag className="h-4 w-4" />
                  Продолжить покупки
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
