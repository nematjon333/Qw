"use client"

import Link from "next/link"
import { ArrowRight, Truck, Clock, ShieldCheck } from "lucide-react"
import { useEffect, useState } from "react"

import { Button } from "@/components/ui/button"
import { CategoryCard } from "@/components/category-card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ImageSlider } from "@/components/image-slider"
import { AddToHomescreen } from "@/components/add-to-homescreen"
import { PWAHeroBanner } from "@/components/pwa-hero-banner"
import { supabase } from "@/lib/supabase-client"
import { ProductCard } from "@/components/product-card"

// Import the site settings service at the top of the file
import { getSetting } from "@/lib/site-settings-service"

export default function Home() {
  const [categories, setCategories] = useState([])
  const [featuredProducts, setFeaturedProducts] = useState([])
  const [sliderImages, setSliderImages] = useState([])
  const [loading, setLoading] = useState(true)
  const [siteSettings, setSiteSettings] = useState({
    home: {
      banner_title: "",
      banner_subtitle: "",
      categories_title: "",
      delivery_title: "",
    },
    delivery: {
      description: "",
      min_free_delivery: "",
    },
  })

  // Скролл в начало страницы при загрузке
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  // Modify the useEffect to also fetch site settings
  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)

        // Инициализируем таблицу категорий, если она не существует
        await fetch("/api/setup-categories")

        // Fetch categories
        const { data: categoriesData, error: categoriesError } = await supabase.from("categories").select("*")

        if (categoriesError) {
          console.error("Ошибка при получении категорий:", categoriesError)
          // Используем запасные категории
        }

        // Fetch featured products
        const { data: productsData, error: productsError } = await supabase
          .from("products")
          .select("*")
          .eq("active", true)
          .eq("on_homepage", true)
          .limit(7)

        if (productsError) {
          console.error("Ошибка при получении товаров:", productsError)
          // Используем запасные товары
        }

        // Fetch slideshows
        const { data: slideshowsData, error: slideshowsError } = await supabase
          .from("slideshows")
          .select("*")
          .eq("is_active", true)
          .order("slide_order", { ascending: true })

        if (slideshowsError) {
          console.error("Ошибка при получении слайдов:", slideshowsError)
          // Используем запасные слайды
        }

        // Fetch site settings
        const homeBannerTitle = await getSetting("home", "banner_title", "Свежие продукты с доставкой")
        const homeBannerSubtitle = await getSetting(
          "home",
          "banner_subtitle",
          "Доставляем свежие фрукты, овощи, сухофрукты и напитки по всему Челябинску",
        )
        const homeCategoriesTitle = await getSetting("home", "categories_title", "Категории")
        const homeDeliveryTitle = await getSetting("home", "delivery_title", "Быстрая доставка по Челябинску")
        const deliveryDescription = await getSetting(
          "delivery",
          "description",
          "Мы доставляем свежие фрукты, овощи, сухофрукты и напитки по всему Челябинску. Наша цель — обеспечить вас качественными продуктами в кратчайшие сроки.",
        )
        const deliveryMinFree = await getSetting("delivery", "min_free_delivery", "2000")

        setSiteSettings({
          home: {
            banner_title: homeBannerTitle,
            banner_subtitle: homeBannerSubtitle,
            categories_title: homeCategoriesTitle,
            delivery_title: homeDeliveryTitle,
          },
          delivery: {
            description: deliveryDescription,
            min_free_delivery: deliveryMinFree,
          },
        })

        setCategories(categoriesData || [])
        setFeaturedProducts(productsData || [])

        // Extract image URLs from slideshows
        const images = slideshowsData?.map((slide) => slide.image_url) || []
        setSliderImages(
          images.length > 0
            ? images
            : [
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/slide1-tCtPU2yW7etIhwiW9F23jliG49b90k.jpeg",
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/slide2-0pdujLAoTkLJg9g0YsngCDnNvzRua6.jpeg",
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/slide3-9wCIkHbrCm4EI8izR97P5GR0F8Pakf.jpeg",
              ],
        )
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Fallback categories if database is empty
  const fallbackCategories = [
    {
      id: "fruits",
      name: "Фрукты",
      image_url: "/placeholder.svg?height=400&width=600&text=Фрукты",
      description: "Свежие и сочные фрукты со всего мира",
      slug: "fruits",
    },
    {
      id: "vegetables",
      name: "Овощи",
      image_url: "/placeholder.svg?height=400&width=600&text=Овощи",
      description: "Свежие овощи, выращенные с заботой",
      slug: "vegetables",
    },
    {
      id: "berries",
      name: "Ягоды",
      image_url: "/placeholder.svg?height=400&width=600&text=Ягоды",
      description: "Сочные и спелые ягоды",
      slug: "berries",
    },
    {
      id: "dried-fruits",
      name: "Сухофрукты и орехи",
      image_url: "/placeholder.svg?height=400&width=600&text=Сухофрукты",
      description: "Натуральные сухофрукты без добавок",
      slug: "dried-fruits",
    },
    {
      id: "greens",
      name: "Зелень",
      image_url: "/placeholder.svg?height=400&width=600&text=Зелень",
      description: "Свежая зелень и травы",
      slug: "greens",
    },
    {
      id: "beverages",
      name: "Напитки",
      image_url: "/placeholder.svg?height=400&width=600&text=Напитки",
      description: "Освежающие и полезные напитки",
      slug: "beverages",
    },
    {
      id: "bread",
      name: "Лепёшки и хлеб",
      image_url: "/placeholder.svg?height=400&width=600&text=Хлеб",
      description: "Домашние лепёшки, лаваш, хлеб и булочки",
      slug: "bread",
    },
    {
      id: "sets",
      name: "Готовые наборы",
      image_url: "/placeholder.svg?height=400&width=600&text=Наборы",
      description: "Фруктовые или овощные боксы, подарочные корзины",
      slug: "sets",
    },
    {
      id: "exotic",
      name: "Экзотические продукты",
      image_url: "/placeholder.svg?height=400&width=600&text=Экзотика",
      description: "Манго, авокадо, питахайя и прочие редкие продукты",
      slug: "exotic",
    },
    {
      id: "promotions",
      name: "Акции и новинки",
      image_url: "/placeholder.svg?height=400&width=600&text=Акции",
      description: "Временные предложения, сезонные товары",
      slug: "promotions",
    },
  ]

  const displayCategories = categories.length > 0 ? categories : fallbackCategories

  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      {/* Слайдер */}
      <section className="relative bg-white py-8 md:py-12 overflow-hidden">
        <div className="container">
          <PWAHeroBanner />
          <div className="relative z-10">
            <div className="mb-8 text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight modern-heading">
                {siteSettings.home.banner_title}
              </h1>
              <p className="mt-4 text-lg md:text-xl text-gray-700 max-w-3xl mx-auto">
                {siteSettings.home.banner_subtitle}
              </p>
              <div className="mt-6">
                <Button
                  asChild
                  size="lg"
                  className="bg-green-600 hover:bg-green-700 pulse-animation btn-modern rounded-full"
                >
                  <Link href="/catalog">Перейти в каталог</Link>
                </Button>
              </div>
            </div>

            <ImageSlider images={sliderImages} interval={2000} />
          </div>
        </div>
      </section>

      {/* Преимущества */}
      <section className="py-12 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-green-50 hover:shadow-md transition-shadow hover-effect">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                <Truck className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Быстрая доставка</h3>
              <p className="text-gray-600">Доставляем заказы по всему Челябинску</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-green-50 hover:shadow-md transition-shadow hover-effect">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                <Clock className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Свежие продукты</h3>
              <p className="text-gray-600">Ежедневные поставки свежих продуктов от проверенных поставщиков</p>
            </div>
            <div className="flex flex-col items-center text-center p-6 rounded-xl bg-green-50 hover:shadow-md transition-shadow hover-effect">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                <ShieldCheck className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Гарантия качества</h3>
              <p className="text-gray-600">Тщательный отбор и контроль качества каждого продукта</p>
            </div>
          </div>
        </div>
      </section>

      {/* Категории */}
      <section className="py-12 bg-gray-50">
        <div className="container">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold modern-heading">{siteSettings.home.categories_title}</h2>
            <Button asChild variant="ghost" className="gap-1">
              <Link href="/catalog">
                Все категории
                <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {displayCategories.slice(0, 6).map((category) => (
              <CategoryCard
                key={category.id}
                id={category.slug || category.id}
                name={category.name}
                image={category.image_url}
                description={category.description}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Популярные товары */}
      {featuredProducts.length > 0 && (
        <section className="py-12 bg-white">
          <div className="container">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl font-bold modern-heading">Популярные товары</h2>
              <Button asChild variant="ghost" className="gap-1">
                <Link href="/catalog">
                  Все товары
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  id={product.id}
                  name={product.name}
                  price={product.price}
                  image={product.images?.[0] || "/placeholder.svg?height=200&width=200"}
                  unit={product.unit}
                  discount={product.discount}
                  step={product.step || 1}
                  minQuantity={product.min_quantity || 1}
                  maxQuantity={product.max_quantity || 10}
                  stockQuantity={product.stock_quantity}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* О доставке */}
      <section className="py-12 bg-gradient-to-r from-green-50 to-green-100">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4 modern-heading">{siteSettings.home.delivery_title}</h2>
              <p className="text-gray-700 mb-6">{siteSettings.delivery.description}</p>
              <Button asChild className="bg-green-600 hover:bg-green-700 btn-modern rounded-full">
                <Link href="/delivery">Подробнее о доставке</Link>
              </Button>
            </div>
            <div className="md:w-1/2">
              <div className="relative rounded-xl overflow-hidden shadow-xl">
                <div className="absolute -inset-1 rounded-xl bg-green-500 opacity-50 blur-md"></div>
                <div className="relative rounded-xl overflow-hidden">
                  <img
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/delivery-banner-OfXT4tpHlDHC6EElXkFP2y42ku3v3B.png"
                    alt="Доставка свежих продуктов"
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <AddToHomescreen />
    </div>
  )
}
