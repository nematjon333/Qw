"use client"

import { Clock, MapPin, ShieldCheck, Truck } from "lucide-react"
import Link from "next/link"

import { Separator } from "@/components/ui/separator"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ClientDeliveryMap } from "@/components/client-delivery-map"

export default function DeliveryPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-8">
          <h1 className="mb-6 text-3xl font-bold">Доставка</h1>

          <div className="mb-12 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
            <div className="flex flex-col items-center rounded-lg bg-white p-6 text-center shadow-sm border dark:bg-gray-800 dark:border-gray-700">
              <div className="mb-4 rounded-full bg-green-100 p-3 dark:bg-green-900/30">
                <Truck className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Быстрая доставка</h3>
              <p className="text-gray-600 dark:text-gray-400">Доставляем заказы по всему городу</p>
            </div>
            <div className="flex flex-col items-center rounded-lg bg-white p-6 text-center shadow-sm border dark:bg-gray-800 dark:border-gray-700">
              <div className="mb-4 rounded-full bg-green-100 p-3 dark:bg-green-900/30">
                <ShieldCheck className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Гарантия свежести</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Мы отбираем только самые свежие и качественные продукты
              </p>
            </div>
            <div className="flex flex-col items-center rounded-lg bg-white p-6 text-center shadow-sm border dark:bg-gray-800 dark:border-gray-700">
              <div className="mb-4 rounded-full bg-green-100 p-3 dark:bg-green-900/30">
                <MapPin className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Вся география города</h3>
              <p className="text-gray-600 dark:text-gray-400">Доставляем во все районы Челябинска без исключений</p>
            </div>
            <div className="flex flex-col items-center rounded-lg bg-white p-6 text-center shadow-sm border dark:bg-gray-800 dark:border-gray-700">
              <div className="mb-4 rounded-full bg-green-100 p-3 dark:bg-green-900/30">
                <Clock className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Удобное время</h3>
              <p className="text-gray-600 dark:text-gray-400">Работаем ежедневно с 9:00 до 21:00 без выходных</p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div>
              <h2 className="mb-4 text-2xl font-bold">Условия доставки</h2>
              <p className="mb-4 text-gray-600 dark:text-gray-400">
                Мы доставляем свежие фрукты, овощи, сухофрукты и напитки по всему Челябинску. Наша цель — обеспечить вас
                качественными продуктами в кратчайшие сроки.
              </p>

              <div className="mb-6 space-y-4">
                <div className="rounded-lg border p-4 dark:border-gray-700">
                  <h3 className="mb-2 font-semibold">Стоимость доставки</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Стоимость доставки зависит от вашего адреса доставки до нашего ближайшего магазина. Чем ближе, тем
                    дешевле. Также при заказе от определённой суммы бесплатная доставка. Обо всем этом можете
                    ознакомиться при оформлении заказа.
                  </p>
                </div>
                <div className="rounded-lg border p-4 dark:border-gray-700">
                  <h3 className="mb-2 font-semibold">Время доставки</h3>
                  <p className="text-gray-600 dark:text-gray-400">Быстрая доставка по Челябинску</p>
                </div>
                <div className="rounded-lg border p-4 dark:border-gray-700">
                  <h3 className="mb-2 font-semibold">Часы работы</h3>
                  <p className="text-gray-600 dark:text-gray-400">Ежедневно с 9:00 до 21:00</p>
                </div>
              </div>
            </div>

            <div>
              <h2 className="mb-4 text-2xl font-bold">Часто задаваемые вопросы</h2>

              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>Как отслеживать заказ?</AccordionTrigger>
                  <AccordionContent>
                    После оформления заказа вы получите SMS-уведомление с информацией о статусе вашего заказа. Также вы
                    можете позвонить нам по телефону +7 (904) 817-97-62 для уточнения информации.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2">
                  <AccordionTrigger>Что делать, если я не доволен качеством продуктов?</AccordionTrigger>
                  <AccordionContent>
                    Мы гарантируем качество всех наших продуктов. Если вы не удовлетворены качеством, сообщите нам в
                    течение 24 часов после получения заказа, и мы заменим товар или вернем деньги.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3">
                  <AccordionTrigger>Можно ли изменить заказ после его оформления?</AccordionTrigger>
                  <AccordionContent>
                    Вы можете изменить заказ в течение 10 минут после его оформления, позвонив по телефону +7 (904)
                    817-97-62. После этого времени изменение заказа может быть невозможно, так как он уже может
                    находиться в процессе сборки или доставки.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4">
                  <AccordionTrigger>Как оплатить заказ?</AccordionTrigger>
                  <AccordionContent>
                    Вы можете оплатить заказ наличными или банковской картой при получении. Также доступна онлайн-оплата
                    на сайте при оформлении заказа.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5">
                  <AccordionTrigger>Доставляете ли вы в пригород?</AccordionTrigger>
                  <AccordionContent>
                    Да, мы доставляем в пригородные районы Челябинска. Стоимость доставки в пригород рассчитывается
                    индивидуально в зависимости от расстояния. Уточнить стоимость можно при оформлении заказа или по
                    телефону.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>

          <Separator className="my-12" />

          <div>
            <h2 className="mb-6 text-2xl font-bold">Зоны доставки</h2>
            <div className="mb-6">
              <ClientDeliveryMap />
            </div>
            <p className="mt-4 text-sm text-gray-500 dark:text-gray-400">
              * Время доставки может варьироваться в зависимости от погодных условий, дорожной ситуации и загруженности
              службы доставки.
            </p>
          </div>

          <div className="mt-8">
            <p className="text-gray-600 dark:text-gray-400">
              Если у вас возникли вопросы по доставке, вы можете обратиться по электронной почте{" "}
              <a href="mailto:oluchafresh@gmail.com" className="text-green-600 hover:underline dark:text-green-400">
                oluchafresh@gmail.com
              </a>
            </p>
          </div>

          <div className="mt-12 text-right">
            <Link href="/admin/login" className="text-xs text-gray-400 hover:text-gray-500 dark:hover:text-gray-300">
              Панель управления
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
