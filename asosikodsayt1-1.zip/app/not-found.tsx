"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Home } from "lucide-react"

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center">
        <div className="container max-w-md py-16 text-center">
          <div className="mb-8 flex justify-center">
            <div className="rounded-full bg-red-100 p-6">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="h-16 w-16 text-red-500"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"
                />
              </svg>
            </div>
          </div>
          <h1 className="mb-4 text-3xl font-bold">Упс, страница не найдена</h1>
          <p className="mb-8 text-gray-600">
            Страница, которую вы ищете, не существует или была перемещена. Пожалуйста, вернитесь на главную страницу.
          </p>
          <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
            <Link href="/" className="flex items-center gap-2">
              <Home className="h-5 w-5" />
              Перейти на главную
            </Link>
          </Button>
        </div>
      </main>
      <Footer />
    </div>
  )
}
