import { getProducts } from "@/lib/product-service"
import type { MetadataRoute } from "next"

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://olucha.ru"

  // Получаем все продукты
  const products = await getProducts()

  // Создаем записи для продуктов
  const productEntries = products
    .filter((product) => product.active) // Только активные продукты
    .map((product) => ({
      url: `${baseUrl}/product/${product.slug || product.id}`,
      lastModified: product.updated_at || new Date(),
      changeFrequency: "weekly" as const,
      priority: 0.8,
    }))

  // Статические страницы
  const staticPages = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: "daily" as const,
      priority: 1.0,
    },
    {
      url: `${baseUrl}/catalog`,
      lastModified: new Date(),
      changeFrequency: "daily" as const,
      priority: 0.9,
    },
    {
      url: `${baseUrl}/contacts`,
      lastModified: new Date(),
      changeFrequency: "monthly" as const,
      priority: 0.7,
    },
    {
      url: `${baseUrl}/delivery`,
      lastModified: new Date(),
      changeFrequency: "monthly" as const,
      priority: 0.7,
    },
  ]

  return [...staticPages, ...productEntries]
}
