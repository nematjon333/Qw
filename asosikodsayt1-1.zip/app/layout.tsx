import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import { CartProvider } from "@/context/cart-context"
import { FavoritesProvider } from "@/context/favorites-context"
import { Toaster } from "@/components/ui/toaster"
import { ThemeProvider } from "@/components/theme-provider"
import { MobileBottomMenu } from "@/components/mobile-bottom-menu"
import { CookieConsent } from "@/components/cookie-consent"

export const metadata: Metadata = {
  title: "Olucha-Fresh - Доставка свежих фруктов и овощей в Челябинске",
  description:
    "Быстрая доставка свежих фруктов, овощей, сухофруктов и напитков по Челябинску. Гарантия качества и свежести.",
  keywords:
    "доставка фруктов, доставка овощей, свежие фрукты, свежие овощи, Челябинск, быстрая доставка, сухофрукты, напитки",
  openGraph: {
    title: "Olucha-Fresh - Доставка свежих фруктов и овощей в Челябинске",
    description:
      "Быстрая доставка свежих фруктов, овощей, сухофруктов и напитков по Челябинску. Гарантия качества и свежести.",
    url: "https://olucha-fresh.ru",
    siteName: "Olucha-Fresh",
    locale: "ru_RU",
    type: "website",
  },
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="theme-color" content="#16a34a" />
        <link rel="icon" href="/favicon.ico" />
        <script
          async
          src="https://telegram.org/js/telegram-widget.js?22"
          data-telegram-login="Vertifolucha_bot"
          data-size="large"
          data-auth-url="https://olucha-fresh.ru"
          data-request-access="write"
        ></script>
      </head>
      <body className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <ThemeProvider>
          <FavoritesProvider>
            <CartProvider>
              {children}
              <MobileBottomMenu />
              <CookieConsent />
              <Toaster />
            </CartProvider>
          </FavoritesProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
