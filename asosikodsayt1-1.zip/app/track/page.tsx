"use client"

import { useState } from "react"
import Link from "next/link"
import { Package, Search, Truck, CheckCircle, Clock } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Logo } from "@/components/logo"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"

export default function TrackOrderPage() {
  const [orderNumber, setOrderNumber] = useState("")
  const [orderPhone, setOrderPhone] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [orders, setOrders] = useState([])
  const [error, setError] = useState("")

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      // Определяем, какой тип поиска используется
      const searchType = e.currentTarget.getAttribute("data-search-type")

      let payload = {}
      if (searchType === "number") {
        if (!orderNumber.trim()) {
          throw new Error("Пожалуйста, введите номер заказа")
        }
        payload = { orderNumber: orderNumber.trim() }
      } else {
        if (!orderPhone.trim()) {
          throw new Error("Пожалуйста, введите номер телефона")
        }
        payload = { phone: orderPhone.trim() }
      }

      const response = await fetch("/api/track", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Ошибка при отслеживании заказа")
      }

      if (data.success) {
        setOrders(data.orders)
        if (data.orders.length === 0) {
          setError("Заказы не найдены. Пожалуйста, проверьте введенные данные.")
        }
      } else {
        throw new Error(data.message || "Ошибка при отслеживании заказа")
      }
    } catch (error) {
      console.error("Ошибка при отслеживании заказа:", error)
      setError(error.message || "Произошла ошибка при отслеживании заказа")
      toast({
        title: "Ошибка",
        description: error.message || "Произошла ошибка при отслеживании заказа",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusInfo = (status) => {
    switch (status) {
      case "new":
        return {
          icon: <Clock className="h-8 w-8 text-blue-500" />,
          text: "Новый",
          description: "Ваш заказ получен и ожидает обработки",
          color: "text-blue-500",
        }
      case "processing":
        return {
          icon: <Package className="h-8 w-8 text-yellow-500" />,
          text: "В обработке",
          description: "Ваш заказ собирается и готовится к отправке",
          color: "text-yellow-500",
        }
      case "delivering":
        return {
          icon: <Truck className="h-8 w-8 text-orange-500" />,
          text: "В пути",
          description: "Ваш заказ уже в пути к вам",
          color: "text-orange-500",
        }
      case "delivered":
        return {
          icon: <CheckCircle className="h-8 w-8 text-green-500" />,
          text: "Доставлен",
          description: "Ваш заказ успешно доставлен",
          color: "text-green-500",
        }
      default:
        return {
          icon: <Clock className="h-8 w-8 text-gray-500" />,
          text: "Статус неизвестен",
          description: "Информация о статусе заказа отсутствует",
          color: "text-gray-500",
        }
    }
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b bg-white">
        <div className="container flex h-16 items-center justify-between">
          <Logo />
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium hover:text-green-600 transition-colors">
              Главная
            </Link>
            <Link href="/catalog" className="text-sm font-medium hover:text-green-600 transition-colors">
              Каталог
            </Link>
            <Link href="/delivery" className="text-sm font-medium hover:text-green-600 transition-colors">
              Доставка
            </Link>
            <Link href="/contacts" className="text-sm font-medium hover:text-green-600 transition-colors">
              Контакты
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 py-12">
        <div className="container max-w-4xl">
          <h1 className="text-3xl font-bold mb-8 text-center">Отслеживание заказа</h1>

          <Tabs defaultValue="number">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="number">По номеру заказа</TabsTrigger>
              <TabsTrigger value="phone">По номеру телефона</TabsTrigger>
            </TabsList>

            <TabsContent value="number">
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Введите номер заказа</CardTitle>
                  <CardDescription>Для отслеживания заказа введите его 4-значный номер</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} data-search-type="number" className="space-y-4">
                    <div className="space-y-2">
                      <label htmlFor="order-number" className="text-sm font-medium">
                        Номер заказа
                      </label>
                      <Input
                        id="order-number"
                        placeholder="Например: 1234"
                        value={orderNumber}
                        onChange={(e) => setOrderNumber(e.target.value)}
                        required
                      />
                    </div>

                    {error && <p className="text-red-500 text-sm">{error}</p>}

                    <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isLoading}>
                      {isLoading ? (
                        <span className="flex items-center gap-2">
                          <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                          Поиск...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <Search className="h-4 w-4" />
                          Отследить заказ
                        </span>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="phone">
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Введите номер телефона</CardTitle>
                  <CardDescription>
                    Для отслеживания заказа введите номер телефона, указанный при оформлении
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} data-search-type="phone" className="space-y-4">
                    <div className="space-y-2">
                      <label htmlFor="order-phone" className="text-sm font-medium">
                        Номер телефона
                      </label>
                      <Input
                        id="order-phone"
                        placeholder="Например: 9048179762"
                        value={orderPhone}
                        onChange={(e) => setOrderPhone(e.target.value)}
                        required
                      />
                    </div>

                    {error && <p className="text-red-500 text-sm">{error}</p>}

                    <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isLoading}>
                      {isLoading ? (
                        <span className="flex items-center gap-2">
                          <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                          Поиск...
                        </span>
                      ) : (
                        <span className="flex items-center gap-2">
                          <Search className="h-4 w-4" />
                          Найти заказы
                        </span>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {orders.length > 0 && (
            <div className="space-y-6">
              {orders.map((order) => (
                <Card key={order.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Заказ #{order.order_number || order.id.substring(0, 8)}</CardTitle>
                        <CardDescription>от {formatDate(order.created_at)}</CardDescription>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className={`font-medium ${getStatusInfo(order.status).color}`}>
                          {getStatusInfo(order.status).text}
                        </span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex flex-col items-center sm:flex-row sm:items-start gap-4 p-4 bg-gray-50 rounded-lg">
                      {getStatusInfo(order.status).icon}
                      <div>
                        <h3 className="font-medium">{getStatusInfo(order.status).text}</h3>
                        <p className="text-gray-600">{getStatusInfo(order.status).description}</p>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium mb-2">Информация о доставке</h3>
                      <div className="space-y-1 text-sm">
                        <p>
                          <span className="text-gray-500">Получатель:</span> {order.customer_name}
                        </p>
                        <p>
                          <span className="text-gray-500">Телефон:</span> {order.customer_phone}
                        </p>
                        <p>
                          <span className="text-gray-500">Адрес:</span> {order.customer_address}
                        </p>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium mb-2">Состав заказа</h3>
                      <div className="space-y-2">
                        {Array.isArray(order.items) ? (
                          order.items.map((item, index) => (
                            <div key={index} className="flex justify-between">
                              <span>
                                {item.product_name} x {item.quantity} {item.unit}
                              </span>
                              <span className="font-medium">{(item.price * item.quantity).toFixed(0)} ₽</span>
                            </div>
                          ))
                        ) : (
                          <p className="text-gray-500">Информация о товарах недоступна</p>
                        )}
                        <Separator className="my-2" />
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Подытог:</span>
                          <span>{order.subtotal.toFixed(0)} ₽</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Доставка:</span>
                          <span>{order.delivery_fee.toFixed(0)} ₽</span>
                        </div>
                        <div className="flex justify-between font-medium">
                          <span>Итого:</span>
                          <span>{order.total.toFixed(0)} ₽</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>

      <footer className="border-t bg-gray-50 py-6">
        <div className="container text-center text-sm text-gray-500">
          <p>© 2025 Olucha-Fresh. Все права защищены.</p>
        </div>
      </footer>
    </div>
  )
}
