import { Mail, MapPin, Phone } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function ContactsPage() {
  return (
    <div className="container py-8">
      <h1 className="mb-6 text-3xl font-bold">Контакты</h1>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        <div>
          <div className="mb-6 space-y-4">
            <div className="flex items-start gap-3">
              <MapPin className="mt-1 h-5 w-5 text-green-600" />
              <div>
                <h3 className="font-semibold">Адрес</h3>
                <p className="text-gray-600">г. Челябинск, ул. Артиллерийская 116/1</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Phone className="mt-1 h-5 w-5 text-green-600" />
              <div>
                <h3 className="font-semibold">Телефон</h3>
                <p className="text-gray-600">
                  <a href="tel:+79048179762" className="hover:text-green-600">
                    +7 (904) 817-97-62
                  </a>
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Mail className="mt-1 h-5 w-5 text-green-600" />
              <div>
                <h3 className="font-semibold">Email</h3>
                <p className="text-gray-600">
                  <a href="mailto:info@olucha-fresh.ru" className="hover:text-green-600">
                    info@olucha-fresh.ru
                  </a>
                </p>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h2 className="mb-4 text-xl font-bold">Часы работы</h2>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Понедельник - Пятница</span>
                <span>9:00 - 21:00</span>
              </div>
              <div className="flex justify-between">
                <span>Суббота - Воскресенье</span>
                <span>9:00 - 21:00</span>
              </div>
            </div>
          </div>

          <div className="aspect-video w-full rounded-lg bg-gray-100 flex items-center justify-center">
            <p className="text-gray-500">Карта с расположением офиса</p>
          </div>
        </div>

        <div>
          <div className="rounded-lg border p-6">
            <h2 className="mb-4 text-xl font-bold">Напишите нам</h2>
            <form className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="name" className="mb-2 block text-sm font-medium">
                    Имя
                  </label>
                  <Input id="name" placeholder="Ваше имя" />
                </div>
                <div>
                  <label htmlFor="email" className="mb-2 block text-sm font-medium">
                    Email
                  </label>
                  <Input id="email" type="email" placeholder="Ваш email" />
                </div>
              </div>
              <div>
                <label htmlFor="phone" className="mb-2 block text-sm font-medium">
                  Телефон
                </label>
                <Input id="phone" placeholder="Ваш телефон" />
              </div>
              <div>
                <label htmlFor="message" className="mb-2 block text-sm font-medium">
                  Сообщение
                </label>
                <Textarea id="message" placeholder="Ваше сообщение" rows={5} />
              </div>
              <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                Отправить
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
