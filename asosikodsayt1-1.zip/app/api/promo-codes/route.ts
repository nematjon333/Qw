import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

// Демо-промокоды для резервного режима
const demoPromoCodes = [
  {
    id: "1",
    code: "WELCOME",
    discount_percent: 15,
    min_order_amount: 1000,
    max_discount_amount: 500,
    usage_limit: 100,
    usage_count: 0,
    active: true,
    created_at: new Date().toISOString(),
  },
  {
    id: "2",
    code: "SALE20",
    discount_percent: 20,
    min_order_amount: 2000,
    max_discount_amount: 1000,
    usage_limit: 50,
    usage_count: 0,
    active: true,
    created_at: new Date().toISOString(),
  },
]

// Проверка существования таблицы
async function checkTableExists(tableName: string): Promise<boolean> {
  try {
    const { error } = await supabase.from(tableName).select("id").limit(1)

    if (error && error.code === "42P01") {
      console.log(`Таблица ${tableName} не существует`)
      return false
    }

    return true
  } catch (error) {
    console.error(`Ошибка при проверке таблицы ${tableName}:`, error)
    return false
  }
}

export async function GET() {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists("promo_codes")

    if (!tableExists) {
      console.log("Таблица promo_codes не существует, используем демо-режим")
      return NextResponse.json({
        success: true,
        promoCodes: demoPromoCodes,
      })
    }

    // Получаем промокоды из Supabase
    const { data, error } = await supabase.from("promo_codes").select("*").order("created_at", { ascending: false })

    if (error) {
      console.error("Ошибка при получении промокодов из Supabase:", error)
      return NextResponse.json({ success: true, promoCodes: demoPromoCodes })
    }

    return NextResponse.json({
      success: true,
      promoCodes: data || demoPromoCodes,
    })
  } catch (error) {
    console.error("Ошибка при получении промокодов:", error)
    return NextResponse.json({ success: true, promoCodes: demoPromoCodes })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    console.log("Получены данные для создания промокода:", data)

    // Проверка обязательных полей
    if (!data.code || data.discount_percent === undefined) {
      return NextResponse.json(
        { success: false, message: "Отсутствуют обязательные поля: code, discount_percent" },
        { status: 400 },
      )
    }

    // Проверяем существование таблицы
    const tableExists = await checkTableExists("promo_codes")

    if (!tableExists) {
      console.log("Таблица promo_codes не существует, используем демо-режим")

      // Создаем демо-промокод
      const newPromoCode = {
        id: crypto.randomUUID(),
        code: data.code.toUpperCase(),
        discount_percent: Number(data.discount_percent),
        min_order_amount: data.min_order_amount ? Number(data.min_order_amount) : 0,
        max_discount_amount: data.max_discount_amount ? Number(data.max_discount_amount) : null,
        usage_limit: data.usage_limit ? Number(data.usage_limit) : null,
        usage_count: 0,
        active: data.active !== undefined ? data.active : true,
        expires_at: data.expires_at || null,
        created_at: new Date().toISOString(),
      }

      demoPromoCodes.push(newPromoCode)

      return NextResponse.json({
        success: true,
        message: "Промокод успешно создан (демо-режим)",
        promoCode: newPromoCode,
      })
    }

    // Подготовка данных для вставки
    const promoCodeData = {
      code: data.code.toUpperCase(),
      discount_percent: Number(data.discount_percent),
      min_order_amount: data.min_order_amount ? Number(data.min_order_amount) : 0,
      max_discount_amount: data.max_discount_amount ? Number(data.max_discount_amount) : null,
      usage_limit: data.usage_limit ? Number(data.usage_limit) : null,
      usage_count: 0,
      active: data.active !== undefined ? data.active : true,
      expires_at: data.expires_at || null,
    }

    // Вставка в Supabase
    const { data: insertedData, error } = await supabase.from("promo_codes").insert([promoCodeData]).select()

    if (error) {
      console.error("Ошибка при создании промокода в Supabase:", error)

      // Создаем демо-промокод в случае ошибки
      const newPromoCode = {
        id: crypto.randomUUID(),
        ...promoCodeData,
        created_at: new Date().toISOString(),
      }

      demoPromoCodes.push(newPromoCode)

      return NextResponse.json({
        success: true,
        message: "Промокод успешно создан (демо-режим)",
        promoCode: newPromoCode,
      })
    }

    return NextResponse.json({
      success: true,
      message: "Промокод успешно создан",
      promoCode: insertedData?.[0] || promoCodeData,
    })
  } catch (error: any) {
    console.error("Ошибка при создании промокода:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при создании промокода",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
