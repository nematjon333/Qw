import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // Проверяем, если id равен "new", возвращаем пустой шаблон промокода
    if (id === "new") {
      return NextResponse.json({
        success: true,
        promoCode: {
          id: "",
          code: "",
          discount_percent: 10,
          min_order_amount: 1000,
          max_discount_amount: 500,
          usage_limit: 100,
          usage_count: 0,
          active: true,
          expires_at: "",
          created_at: new Date().toISOString(),
        },
      })
    }

    // Получаем промокод из Supabase
    const { data, error } = await supabase.from("promo_codes").select("*").eq("id", id).single()

    if (error) {
      console.error(`Ошибка при получении промокода с ID ${id}:`, error)
      return NextResponse.json({ success: false, message: "Промокод не найден" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      promoCode: data,
    })
  } catch (error) {
    console.error(`Ошибка при получении промокода:`, error)
    return NextResponse.json({ success: false, message: "Ошибка при получении промокода" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()

    // Проверка обязательных полей
    if (!data.code || data.discount_percent === undefined) {
      return NextResponse.json(
        { success: false, message: "Отсутствуют обязательные поля: code, discount_percent" },
        { status: 400 },
      )
    }

    // Подготовка данных для обновления
    const updateData = {
      code: data.code.toUpperCase(),
      discount_percent: Number(data.discount_percent),
      min_order_amount: data.min_order_amount ? Number(data.min_order_amount) : 0,
      max_discount_amount: data.max_discount_amount ? Number(data.max_discount_amount) : null,
      usage_limit: data.usage_limit ? Number(data.usage_limit) : null,
      active: data.active !== undefined ? data.active : true,
      expires_at: data.expires_at || null,
    }

    // Обновление в Supabase
    const { data: updatedData, error } = await supabase.from("promo_codes").update(updateData).eq("id", id).select()

    if (error) {
      console.error(`Ошибка при обновлении промокода с ID ${id}:`, error)
      return NextResponse.json(
        { success: false, message: "Ошибка при обновлении промокода", error: error.message },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Промокод успешно обновлен",
      promoCode: updatedData?.[0] || updateData,
    })
  } catch (error) {
    console.error(`Ошибка при обновлении промокода:`, error)
    return NextResponse.json(
      { success: false, message: "Ошибка при обновлении промокода", error: error.message },
      { status: 500 },
    )
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    // Удаление из Supabase
    const { error } = await supabase.from("promo_codes").delete().eq("id", id)

    if (error) {
      console.error(`Ошибка при удалении промокода с ID ${id}:`, error)
      return NextResponse.json(
        { success: false, message: "Ошибка при удалении промокода", error: error.message },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Промокод успешно удален",
    })
  } catch (error) {
    console.error(`Ошибка при удалении промокода:`, error)
    return NextResponse.json(
      { success: false, message: "Ошибка при удалении промокода", error: error.message },
      { status: 500 },
    )
  }
}
