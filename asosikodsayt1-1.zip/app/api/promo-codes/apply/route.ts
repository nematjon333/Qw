import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function POST(request: Request) {
  try {
    const { code, subtotal } = await request.json()

    if (!code) {
      return NextResponse.json({ success: false, message: "Необходимо указать код промокода" }, { status: 400 })
    }

    // Проверяем, настроен ли Supabase
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
      console.warn("Supabase не настроен, используем демо-режим для промокодов")

      // Демо-промокоды для тестирования
      const demoPromoCodes = [
        { code: "WELCOME", discount_percent: 10, min_order_amount: 1000, max_discount_amount: 500 },
        { code: "SALE20", discount_percent: 20, min_order_amount: 2000, max_discount_amount: 1000 },
        { code: "FIRST", discount_percent: 15, min_order_amount: 0, max_discount_amount: null },
      ]

      // Ищем промокод в демо-данных
      const promoCode = demoPromoCodes.find((p) => p.code.toLowerCase() === code.toLowerCase())

      if (!promoCode) {
        return NextResponse.json({ success: false, message: "Промокод не найден" }, { status: 404 })
      }

      // Проверяем минимальную сумму заказа
      if (promoCode.min_order_amount && subtotal < promoCode.min_order_amount) {
        return NextResponse.json(
          {
            success: false,
            message: `Минимальная сумма заказа для применения промокода: ${promoCode.min_order_amount} ₽`,
          },
          { status: 400 },
        )
      }

      // Рассчитываем скидку
      let discount = (subtotal * promoCode.discount_percent) / 100

      // Ограничиваем скидку максимальным значением, если оно указано
      if (promoCode.max_discount_amount && discount > promoCode.max_discount_amount) {
        discount = promoCode.max_discount_amount
      }

      return NextResponse.json({
        success: true,
        message: "Промокод успешно применен",
        discount,
        discountPercent: promoCode.discount_percent,
        promoCode: promoCode.code,
      })
    }

    // Получаем промокод из базы данных
    const { data: promoCodes, error } = await supabase
      .from("promo_codes")
      .select("*")
      .eq("code", code.toUpperCase())
      .eq("active", true)
      .single()

    if (error || !promoCodes) {
      return NextResponse.json({ success: false, message: "Промокод не найден или неактивен" }, { status: 404 })
    }

    const promoCode = promoCodes

    // Проверяем, не истек ли срок действия промокода
    if (promoCode.expires_at && new Date(promoCode.expires_at) < new Date()) {
      return NextResponse.json({ success: false, message: "Срок действия промокода истек" }, { status: 400 })
    }

    // Проверяем, не превышен ли лимит использования
    if (promoCode.usage_limit !== null && promoCode.usage_count >= promoCode.usage_limit) {
      return NextResponse.json({ success: false, message: "Превышен лимит использования промокода" }, { status: 400 })
    }

    // Проверяем минимальную сумму заказа
    if (promoCode.min_order_amount && subtotal < promoCode.min_order_amount) {
      return NextResponse.json(
        {
          success: false,
          message: `Минимальная сумма заказа для применения промокода: ${promoCode.min_order_amount} ₽`,
        },
        { status: 400 },
      )
    }

    // Рассчитываем скидку
    let discount = (subtotal * promoCode.discount_percent) / 100

    // Ограничиваем скидку максимальным значением, если оно указано
    if (promoCode.max_discount_amount && discount > promoCode.max_discount_amount) {
      discount = promoCode.max_discount_amount
    }

    // Увеличиваем счетчик использования промокода
    await supabase
      .from("promo_codes")
      .update({ usage_count: promoCode.usage_count + 1 })
      .eq("id", promoCode.id)

    return NextResponse.json({
      success: true,
      message: "Промокод успешно применен",
      discount,
      discountPercent: promoCode.discount_percent,
      promoCode: promoCode.code,
    })
  } catch (error: any) {
    console.error("Ошибка при применении промокода:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Произошла ошибка при применении промокода",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
