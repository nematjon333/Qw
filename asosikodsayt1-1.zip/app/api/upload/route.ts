import { NextResponse } from "next/server"
import { put } from "@vercel/blob"
import { nanoid } from "nanoid"

export async function POST(request: Request) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "Файл не найден" }, { status: 400 })
    }

    // Проверка типа файла
    if (!file.type.startsWith("image/")) {
      return NextResponse.json({ error: "Пожалуйста, загрузите изображение" }, { status: 400 })
    }

    // Проверка наличия токена Blob
    const hasBlobToken = !!process.env.BLOB_READ_WRITE_TOKEN

    if (!hasBlobToken) {
      console.warn("BLOB_READ_WRITE_TOKEN не найден, используется резервный режим")

      // Резервный механизм: возвращаем URL заглушки
      const placeholderUrl = `/placeholder.svg?height=800&width=800&seed=${Date.now()}`

      return NextResponse.json({
        success: true,
        message: "Используется заглушка (резервный режим)",
        url: placeholderUrl,
        note: "Для работы с Vercel Blob необходимо настроить BLOB_READ_WRITE_TOKEN. Сейчас используется резервный режим с заглушками.",
      })
    }

    // Генерация уникального имени файла
    const fileExtension = file.name.split(".").pop()
    const uniqueId = nanoid(10)
    const fileName = `products/${uniqueId}-${Date.now()}.${fileExtension}`

    try {
      // Попытка загрузки файла в Vercel Blob
      const blob = await put(fileName, file, {
        access: "public",
        contentType: file.type,
      })

      console.log("Файл успешно загружен в Vercel Blob:", blob.url)

      return NextResponse.json({
        success: true,
        message: "Файл успешно загружен",
        url: blob.url,
      })
    } catch (blobError) {
      console.error("Ошибка при загрузке в Vercel Blob:", blobError.message)

      // Резервный механизм: возвращаем URL заглушки
      const placeholderUrl = `/placeholder.svg?height=800&width=800&seed=${Date.now()}`

      return NextResponse.json({
        success: true,
        message: "Используется заглушка (резервный режим)",
        url: placeholderUrl,
        note: "Произошла ошибка при загрузке в Vercel Blob. Сейчас используется резервный режим с заглушками.",
        error: blobError.message,
      })
    }
  } catch (error) {
    console.error("Ошибка при загрузке файла:", error)

    // Резервный механизм при любой ошибке
    const placeholderUrl = `/placeholder.svg?height=800&width=800&seed=${Date.now()}`

    return NextResponse.json({
      success: true,
      message: "Используется заглушка из-за ошибки",
      url: placeholderUrl,
      error: error.message,
      note: "Временное решение. В реальном приложении здесь был бы URL загруженного изображения.",
    })
  }
}

// Для проверки статуса API
export async function GET() {
  try {
    // Проверяем наличие токена
    const hasToken = !!process.env.BLOB_READ_WRITE_TOKEN

    return NextResponse.json({
      success: true,
      message: "API загрузки файлов работает",
      provider: "Vercel Blob",
      status: hasToken
        ? "Настроен (BLOB_READ_WRITE_TOKEN найден)"
        : "Работает в резервном режиме (BLOB_READ_WRITE_TOKEN не найден)",
      note: hasToken
        ? undefined
        : "Для полноценной работы необходимо настроить BLOB_READ_WRITE_TOKEN в переменных окружения",
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при проверке API загрузки",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
