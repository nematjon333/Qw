import { NextResponse } from "next/server"
import { createOrder, type Order, type OrderItem } from "@/lib/order-service"
import { sendTelegramMessage, createOrderNotificationMessage } from "@/lib/telegram-service"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Проверяем наличие необходимых данных
    if (!data.customer || !data.totals || !data.items || !Array.isArray(data.items)) {
      return NextResponse.json({ success: false, message: "Неверный формат данных заказа" }, { status: 400 })
    }

    // Подготавливаем данные заказа
    const orderItems: OrderItem[] = data.items.map((item: any) => ({
      product_id: item.id,
      product_name: item.name,
      price: Number(item.price),
      quantity: Number(item.quantity),
      unit: item.unit,
      discount: item.discount ? Number(item.discount) : undefined,
    }))

    const order: Order = {
      customer_name: data.customer.name,
      customer_phone: data.customer.phone,
      customer_address: data.customer.address,
      entrance: data.customer.entrance,
      floor: data.customer.floor,
      delivery_type: data.customer.deliveryType,
      payment_method: data.customer.paymentMethod,
      comment: data.customer.comment,
      promo_code: data.totals.promoCode,
      promo_discount: Number(data.totals.promoDiscount),
      subtotal: Number(data.totals.subtotal),
      delivery_fee: Number(data.totals.deliveryFee),
      total: Number(data.totals.total),
      items: orderItems,
    }

    // Сохраняем заказ в базу данных
    const createdOrder = await createOrder(order)

    if (!createdOrder) {
      return NextResponse.json({ success: false, message: "Не удалось создать заказ" }, { status: 500 })
    }

    // Отправляем уведомление в Telegram
    try {
      const telegramData = {
        order_number: createdOrder.order_number,
        customer_name: createdOrder.customer_name,
        customer_phone: createdOrder.customer_phone,
        customer_address: createdOrder.customer_address,
        entrance: createdOrder.entrance,
        floor: createdOrder.floor,
        payment_method: createdOrder.payment_method,
        delivery_type: createdOrder.delivery_type,
        comment: createdOrder.comment,
        items: createdOrder.items,
        subtotal: createdOrder.subtotal,
        delivery_fee: createdOrder.delivery_fee,
        total: createdOrder.total,
      }

      const message = createOrderNotificationMessage(telegramData)
      await sendTelegramMessage(message)
    } catch (telegramError) {
      console.error("Ошибка при отправке уведомления в Telegram:", telegramError)
      // Продолжаем выполнение, даже если не удалось отправить уведомление
    }

    return NextResponse.json({
      success: true,
      message: "Заказ успешно создан",
      orderNumber: createdOrder.order_number,
      orderId: createdOrder.id,
    })
  } catch (error) {
    console.error("Ошибка при создании заказа:", error)
    return NextResponse.json({ success: false, message: "Произошла ошибка при обработке заказа" }, { status: 500 })
  }
}
