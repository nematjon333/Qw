import { NextResponse } from "next/server"
import { testEmailConnection, sendEmail } from "@/lib/email-service"

export async function GET() {
  try {
    const result = await testEmailConnection()

    return NextResponse.json({
      success: result.success,
      message: result.message,
      config: result.config,
      error: result.error,
    })
  } catch (error) {
    console.error("Ошибка при проверке конфигурации email:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при проверке конфигурации email",
        error: error.message,
      },
      { status: 500 },
    )
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const { to, subject, html } = data

    if (!to || !subject || !html) {
      return NextResponse.json(
        { success: false, message: "Отсутствуют обязательные поля: to, subject, html" },
        { status: 400 },
      )
    }

    const result = await sendEmail({ to, subject, html })

    return NextResponse.json({
      success: true,
      message: result.message || "Email успешно отправлен",
      messageId: result.messageId,
      error: result.error,
    })
  } catch (error) {
    console.error("Ошибка при отправке email:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при отправке email",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
