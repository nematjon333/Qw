import { NextResponse } from "next/server"
import { sendTelegramMessage } from "@/lib/telegram-service"

export async function GET() {
  try {
    const message = `
<b>🧪 Тестовое сообщение</b>

Это тестовое сообщение для проверки работы уведомлений о заказах.

<b>Время отправки:</b> ${new Date().toLocaleString()}

Если вы видите это сообщение, значит уведомления о заказах работают корректно.
`

    const sent = await sendTelegramMessage(message)

    if (sent) {
      return NextResponse.json({
        success: true,
        message: "Тестовое сообщение успешно отправлено",
        timestamp: new Date().toISOString(),
      })
    } else {
      return NextResponse.json({
        success: false,
        message: "Не удалось отправить тестовое сообщение",
        timestamp: new Date().toISOString(),
      })
    }
  } catch (error) {
    console.error("Ошибка при отправке тестового сообщения:", error)

    return NextResponse.json(
      {
        success: false,
        message: "Произошла ошибка при отправке тестового сообщения",
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
