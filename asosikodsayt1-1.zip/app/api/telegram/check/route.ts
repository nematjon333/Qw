import { NextResponse } from "next/server"
import { testTelegramConnection } from "@/lib/telegram-service"

export async function GET() {
  try {
    const result = await testTelegramConnection()

    return NextResponse.json({
      success: result.success,
      message: result.message,
      config: result.config,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Ошибка при проверке соединения с Telegram:", error)

    return NextResponse.json(
      {
        success: false,
        message: "Произошла ошибка при проверке соединения с Telegram",
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
