import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const phone = searchParams.get("phone")

    if (!phone) {
      return NextResponse.json(
        {
          success: false,
          message: "Не указан номер телефона",
        },
        { status: 400 },
      )
    }

    // Получаем заказы пользователя
    const { data: orders, error } = await supabase
      .from("orders")
      .select(`
        id,
        order_number,
        status,
        total,
        created_at,
        updated_at,
        order_items (
          id,
          product_id,
          product_name,
          quantity,
          unit,
          price
        )
      `)
      .eq("customer_phone", phone)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Ошибка при получении заказов:", error)
      return NextResponse.json(
        {
          success: false,
          message: "Ошибка при получении заказов",
          error,
        },
        { status: 500 },
      )
    }

    // Преобразуем данные для удобства использования на клиенте
    const formattedOrders = orders.map((order) => ({
      ...order,
      items: order.order_items || [],
    }))

    return NextResponse.json({
      success: true,
      orders: formattedOrders,
    })
  } catch (error) {
    console.error("Ошибка при получении заказов:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при получении заказов",
        error,
      },
      { status: 500 },
    )
  }
}
