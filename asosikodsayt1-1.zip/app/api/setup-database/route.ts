import { NextResponse } from "next/server"
import { setupDatabase } from "@/lib/setup-database"

export async function GET() {
  try {
    console.log("Получен GET запрос на /api/setup-database")
    const result = await setupDatabase()
    console.log("Результат настройки базы данных:", result)
    return NextResponse.json(result)
  } catch (error) {
    console.error("Ошибка при настройке базы данных:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при настройке базы данных",
        error: error.message,
      },
      { status: 500 },
    )
  }
}

export async function POST() {
  try {
    console.log("Получен POST запрос на /api/setup-database")
    const result = await setupDatabase()
    console.log("Результат настройки базы данных:", result)
    return NextResponse.json(result)
  } catch (error) {
    console.error("Ошибка при настройке базы данных:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при настройке базы данных",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
