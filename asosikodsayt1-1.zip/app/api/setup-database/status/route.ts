import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"
import { checkTableExists } from "@/lib/setup-database"

export async function GET() {
  try {
    console.log("Получен запрос на проверку статуса базы данных")

    // Проверяем существование всех необходимых таблиц
    const tables = {
      orders: await checkTableExists("orders"),
      order_items: await checkTableExists("order_items"),
      customers: await checkTableExists("customers"),
      promo_codes: await checkTableExists("promo_codes"),
      delivery_zones: await checkTableExists("delivery_zones"),
      products: await checkTableExists("products"),
      site_settings: await checkTableExists("site_settings"),
    }

    console.log("Статус таблиц:", tables)

    // Проверяем существование бакета для хранения изображений
    const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets()

    if (bucketsError) {
      console.error("Ошибка при получении списка бакетов:", bucketsError)
      return NextResponse.json({
        success: false,
        message: "Ошибка при получении списка бакетов",
        error: bucketsError.message,
        tables,
      })
    }

    const bucketName = process.env.SUPABASE_BUCKET || "noviy"
    const bucketExists = buckets?.some((b) => b.name === bucketName)

    console.log("Статус хранилища:", {
      buckets: buckets?.map((b) => b.name) || [],
      configuredBucket: bucketName,
      bucketExists,
    })

    return NextResponse.json({
      success: true,
      tables,
      storage: {
        buckets: buckets?.map((b) => b.name) || [],
        configuredBucket: bucketName,
        bucketExists,
      },
    })
  } catch (error) {
    console.error("Ошибка при проверке статуса базы данных:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при проверке статуса базы данных",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
