import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { createClient } from "@/lib/supabase-client"

export async function GET() {
  try {
    const cookieStore = cookies()
    const supabase = createClient()

    // Получаем сессию из куки
    const {
      data: { session },
      error: sessionError,
    } = await supabase.auth.getSession()

    if (sessionError) {
      console.error("Ошибка при получении сессии:", sessionError)
      return NextResponse.json({ success: false, message: "Ошибка при получении сессии" })
    }

    if (!session) {
      return NextResponse.json({ success: false, message: "Пользователь не авторизован" })
    }

    // Получаем данные пользователя
    const { data: user, error: userError } = await supabase.from("users").select("*").eq("id", session.user.id).single()

    if (userError) {
      console.error("Ошибка при получении данных пользователя:", userError)
      return NextResponse.json({ success: false, message: "Ошибка при получении данных пользователя" })
    }

    return NextResponse.json({ success: true, user })
  } catch (error) {
    console.error("Ошибка при проверке аутентификации:", error)
    return NextResponse.json({ success: false, message: "Ошибка при проверке аутентификации" })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    let { phone } = body

    if (!phone) {
      return NextResponse.json({ success: false, message: "Номер телефона обязателен" }, { status: 400 })
    }

    // Нормализация номера телефона (удаление всех нецифровых символов)
    phone = phone.replace(/\D/g, "")

    // Если номер начинается с 8, заменяем на 7
    if (phone.startsWith("8")) {
      phone = "7" + phone.substring(1)
    }

    // Если номер не начинается с 7, добавляем 7
    if (!phone.startsWith("7")) {
      phone = "7" + phone
    }

    // Добавляем + в начало
    phone = "+" + phone

    const supabase = createClient()

    // Проверяем, существует ли пользователь с таким номером телефона
    const { data, error } = await supabase.from("users").select("id").eq("phone", phone).maybeSingle()

    if (error) {
      console.error("Ошибка при проверке пользователя:", error)
      return NextResponse.json({ success: false, message: "Ошибка при проверке пользователя", error }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      exists: !!data,
    })
  } catch (error) {
    console.error("Ошибка при проверке пользователя:", error)
    return NextResponse.json({ success: false, message: "Ошибка при проверке пользователя", error }, { status: 500 })
  }
}
