import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"
import * as bcrypt from "bcryptjs"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    let { name, phone, password } = body

    if (!name || !phone || !password) {
      return NextResponse.json({ success: false, message: "Имя, номер телефона и пароль обязательны" }, { status: 400 })
    }

    // Нормализация номера телефона (удаление всех нецифровых символов)
    phone = phone.replace(/\D/g, "")

    // Если номер начинается с 8, заменяем на 7
    if (phone.startsWith("8")) {
      phone = "7" + phone.substring(1)
    }

    // Если номер не начинается с +, добавляем +
    if (!phone.startsWith("+")) {
      phone = "+" + phone
    }

    // Проверяем, существует ли пользователь с таким номером телефона
    const { data: existingUser, error: checkError } = await supabase
      .from("users")
      .select("id")
      .eq("phone", phone)
      .maybeSingle()

    if (checkError) {
      console.error("Ошибка при проверке пользователя:", checkError)
      return NextResponse.json(
        { success: false, message: "Ошибка при проверке пользователя", error: checkError },
        { status: 500 },
      )
    }

    if (existingUser) {
      return NextResponse.json(
        { success: false, message: "Пользователь с таким номером телефона уже существует" },
        { status: 409 },
      )
    }

    // Хешируем пароль
    const hashedPassword = await bcrypt.hash(password, 10)

    // Создаем нового пользователя
    const { data: newUser, error: createError } = await supabase
      .from("users")
      .insert([
        {
          name,
          phone,
          password: hashedPassword,
        },
      ])
      .select()

    if (createError) {
      console.error("Ошибка при создании пользователя:", createError)
      return NextResponse.json(
        { success: false, message: "Ошибка при создании пользователя", error: createError },
        { status: 500 },
      )
    }

    // Не возвращаем пароль клиенту
    const { password: _, ...userWithoutPassword } = newUser[0]

    return NextResponse.json({
      success: true,
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Ошибка при регистрации:", error)
    return NextResponse.json({ success: false, message: "Ошибка при регистрации", error }, { status: 500 })
  }
}
