import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"
import * as bcrypt from "bcryptjs"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    let { phone, password } = body

    if (!phone || !password) {
      return NextResponse.json({ success: false, message: "Номер телефона и пароль обязательны" }, { status: 400 })
    }

    // Нормализация номера телефона (удаление всех нецифровых символов)
    phone = phone.replace(/\D/g, "")

    // Если номер начинается с 8, заменяем на 7
    if (phone.startsWith("8")) {
      phone = "7" + phone.substring(1)
    }

    // Если номер не начинается с +, добавляем +
    if (!phone.startsWith("+")) {
      phone = "+" + phone
    }

    // Получаем пользователя по номеру телефона
    const { data: user, error } = await supabase.from("users").select("*").eq("phone", phone).single()

    if (error || !user) {
      return NextResponse.json({ success: false, message: "Пользователь не найден" }, { status: 404 })
    }

    // Проверяем пароль
    const isPasswordValid = await bcrypt.compare(password, user.password)

    if (!isPasswordValid) {
      return NextResponse.json({ success: false, message: "Неверный пароль" }, { status: 401 })
    }

    // Не возвращаем пароль клиенту
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      success: true,
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Ошибка при входе:", error)
    return NextResponse.json({ success: false, message: "Ошибка при входе в систему", error }, { status: 500 })
  }
}
