import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"
import * as bcrypt from "bcryptjs"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { phone, newPassword } = body

    if (!phone || !newPassword) {
      return NextResponse.json(
        { success: false, message: "Номер телефона и новый пароль обязательны" },
        { status: 400 },
      )
    }

    // Проверяем, существует ли пользователь с таким номером телефона
    const { data: user, error: checkError } = await supabase.from("users").select("id").eq("phone", phone).single()

    if (checkError) {
      return NextResponse.json({ success: false, message: "Пользователь не найден" }, { status: 404 })
    }

    // Хешируем новый пароль
    const hashedPassword = await bcrypt.hash(newPassword, 10)

    // Обновляем пароль пользователя
    const { error: updateError } = await supabase
      .from("users")
      .update({ password: hashedPassword, updated_at: new Date().toISOString() })
      .eq("id", user.id)

    if (updateError) {
      console.error("Ошибка при сбросе пароля:", updateError)
      return NextResponse.json(
        { success: false, message: "Ошибка при сбросе пароля", error: updateError },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Пароль успешно сброшен",
    })
  } catch (error) {
    console.error("Ошибка при сбросе пароля:", error)
    return NextResponse.json({ success: false, message: "Ошибка при сбросе пароля", error }, { status: 500 })
  }
}
