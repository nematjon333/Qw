import { NextResponse } from "next/server"
import { getStoreSettings, updateStoreSettings } from "@/lib/delivery-zone-service"

export async function GET() {
  try {
    const settings = await getStoreSettings()

    if (!settings) {
      return NextResponse.json({ success: false, message: "Настройки магазина не найдены" }, { status: 404 })
    }

    return NextResponse.json({ success: true, settings })
  } catch (error) {
    console.error("Ошибка при получении настроек магазина:", error)
    return NextResponse.json(
      { success: false, message: "Ошибка при получении настроек магазина", error: error.message },
      { status: 500 },
    )
  }
}

export async function PUT(request: Request) {
  try {
    const data = await request.json()

    // Проверка обязательных полей
    const requiredFields = ["name", "address", "latitude", "longitude"]
    for (const field of requiredFields) {
      if (data[field] === undefined) {
        return NextResponse.json(
          { success: false, message: `Отсутствует обязательное поле: ${field}` },
          { status: 400 },
        )
      }
    }

    // Обновляем настройки магазина
    const settings = await updateStoreSettings({
      name: data.name,
      address: data.address,
      latitude: Number(data.latitude),
      longitude: Number(data.longitude),
    })

    if (!settings) {
      return NextResponse.json({ success: false, message: "Не удалось обновить настройки магазина" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Настройки магазина успешно обновлены",
      settings,
    })
  } catch (error) {
    console.error("Ошибка при обновлении настроек магазина:", error)
    return NextResponse.json(
      { success: false, message: "Ошибка при обновлении настроек магазина", error: error.message },
      { status: 500 },
    )
  }
}
