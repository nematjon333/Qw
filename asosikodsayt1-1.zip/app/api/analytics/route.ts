import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const period = searchParams.get("period") || "month"

    // Определяем временной интервал
    const now = new Date()
    let startDate: Date

    switch (period) {
      case "week":
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 7)
        break
      case "month":
        startDate = new Date(now)
        startDate.setMonth(now.getMonth() - 1)
        break
      case "quarter":
        startDate = new Date(now)
        startDate.setMonth(now.getMonth() - 3)
        break
      case "year":
        startDate = new Date(now)
        startDate.setFullYear(now.getFullYear() - 1)
        break
      default:
        startDate = new Date(now)
        startDate.setMonth(now.getMonth() - 1)
    }

    const startDateStr = startDate.toISOString()

    // Получаем заказы за выбранный период
    const { data: orders, error } = await supabase
      .from("orders")
      .select("*")
      .gte("created_at", startDateStr)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Ошибка при получении заказов:", error)
      return NextResponse.json({ success: false, message: "Ошибка при получении данных аналитики" }, { status: 500 })
    }

    // Если нет заказов, возвращаем пустую статистику
    if (!orders || orders.length === 0) {
      return NextResponse.json({
        success: true,
        totalOrders: 0,
        totalRevenue: 0,
        averageOrderValue: 0,
        deliveryZoneStats: {},
        timeStats: {},
        dayStats: {},
        monthStats: {},
      })
    }

    // Рассчитываем общую статистику
    const totalOrders = orders.length
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0)
    const averageOrderValue = totalRevenue / totalOrders

    // Статистика по зонам доставки
    const deliveryZoneStats = {}

    // Группируем заказы по зонам доставки
    orders.forEach((order) => {
      const zoneId = order.delivery_zone_id || "unknown"

      if (!deliveryZoneStats[zoneId]) {
        deliveryZoneStats[zoneId] = {
          orders: 0,
          revenue: 0,
          averageValue: 0,
        }
      }

      deliveryZoneStats[zoneId].orders += 1
      deliveryZoneStats[zoneId].revenue += order.total
    })

    // Рассчитываем средний чек для каждой зоны
    Object.keys(deliveryZoneStats).forEach((zoneId) => {
      deliveryZoneStats[zoneId].averageValue = deliveryZoneStats[zoneId].revenue / deliveryZoneStats[zoneId].orders
    })

    // Статистика по времени
    const timeStats = {}
    const dayStats = {
      Пн: 0,
      Вт: 0,
      Ср: 0,
      Чт: 0,
      Пт: 0,
      Сб: 0,
      Вс: 0,
    }
    const monthStats = {
      Янв: 0,
      Фев: 0,
      Мар: 0,
      Апр: 0,
      Май: 0,
      Июн: 0,
      Июл: 0,
      Авг: 0,
      Сен: 0,
      Окт: 0,
      Ноя: 0,
      Дек: 0,
    }

    const dayNames = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"]
    const monthNames = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"]

    // Группируем заказы по времени
    orders.forEach((order) => {
      const orderDate = new Date(order.created_at)
      const hour = orderDate.getHours()
      const day = dayNames[orderDate.getDay()]
      const month = monthNames[orderDate.getMonth()]

      // По часам
      if (!timeStats[hour]) {
        timeStats[hour] = 0
      }
      timeStats[hour] += 1

      // По дням недели
      dayStats[day] += 1

      // По месяцам
      monthStats[month] += 1
    })

    return NextResponse.json({
      success: true,
      totalOrders,
      totalRevenue,
      averageOrderValue,
      deliveryZoneStats,
      timeStats,
      dayStats,
      monthStats,
    })
  } catch (error) {
    console.error("Ошибка при формировании аналитики:", error)
    return NextResponse.json({ success: false, message: "Ошибка при формировании аналитики" }, { status: 500 })
  }
}
