import { NextResponse } from "next/server"
import { nanoid } from "nanoid"
import { put } from "@vercel/blob"

// Демо-продукты для инициализации базы данных
const demoProducts = [
  {
    id: "demo1",
    name: "Яблоки Голден",
    price: 159,
    description:
      "Сочные и сладкие яблоки сорта Голден. Идеально подходят для употребления в свежем виде, а также для приготовления десертов и выпечки.",
    category: "fruits",
    unit: "кг",
    discount: 15,
    images: ["/placeholder.svg?height=400&width=400"],
    origin: "Краснодарский край",
    weight: 1,
    min_quantity: 0.1,
    max_quantity: 10,
    step: 0.1,
    active: true,
    seo_title: "Яблоки Голден - свежие фрукты с доставкой",
    seo_description:
      "Купите свежие яблоки Голден с доставкой по Челябинску. Высокое качество, доступные цены, быстрая доставка.",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "demo2",
    name: "Бананы",
    price: 129,
    description: "Спелые и сладкие бананы. Богаты калием и другими полезными веществами.",
    category: "fruits",
    unit: "кг",
    images: ["/placeholder.svg?height=400&width=400"],
    origin: "Эквадор",
    weight: 1,
    min_quantity: 0.1,
    max_quantity: 10,
    step: 0.1,
    active: true,
    seo_title: "Бананы - свежие фрукты с доставкой",
    seo_description:
      "Купите свежие бананы с доставкой по Челябинску. Высокое качество, доступные цены, быстрая доставка.",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "demo3",
    name: "Апельсины",
    price: 189,
    description: "Сочные апельсины с ярким цитрусовым ароматом. Богаты витамином C и другими полезными веществами.",
    category: "fruits",
    unit: "кг",
    discount: 10,
    images: ["/placeholder.svg?height=400&width=400"],
    origin: "Марокко",
    weight: 1,
    min_quantity: 0.1,
    max_quantity: 10,
    step: 0.1,
    active: true,
    seo_title: "Апельсины - свежие фрукты с доставкой",
    seo_description:
      "Купите свежие апельсины с доставкой по Челябинску. Высокое качество, доступные цены, быстрая доставка.",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// Вспомогательная функция для сохранения продукта в Blob
async function saveProductToBlob(product) {
  const id = product.id || nanoid(10)
  const now = new Date().toISOString()

  const productData = {
    ...product,
    id,
    created_at: product.created_at || now,
    updated_at: now,
  }

  try {
    // Сохраняем продукт в Blob
    await put(`products/data/${id}.json`, JSON.stringify(productData), {
      contentType: "application/json",
      access: "public",
    })

    return { success: true, product: productData }
  } catch (error) {
    console.error(`Ошибка при сохранении продукта в Blob (products/data/${id}.json):`, error)
    return { success: false, error: error.message }
  }
}

export async function GET() {
  try {
    // Проверяем наличие токена Blob
    const hasBlobToken = !!process.env.BLOB_READ_WRITE_TOKEN

    if (!hasBlobToken) {
      return NextResponse.json({
        success: false,
        message: "BLOB_READ_WRITE_TOKEN не настроен, невозможно инициализировать демо-данные",
      })
    }

    // Сохраняем демо-продукты в Blob
    const results = await Promise.all(demoProducts.map((product) => saveProductToBlob(product)))

    const successCount = results.filter((result) => result.success).length
    const failedCount = results.length - successCount

    return NextResponse.json({
      success: true,
      message: `Демо-данные инициализированы: ${successCount} продуктов сохранено, ${failedCount} ошибок`,
      results,
    })
  } catch (error) {
    console.error("Ошибка при инициализации демо-данных:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Произошла ошибка при инициализации демо-данных",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
