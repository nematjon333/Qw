import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase-client"

export async function GET() {
  try {
    const supabase = createClient()

    // Проверяем подключение к базе данных
    if (!supabase) {
      console.error("Failed to create Supabase client")
      return NextResponse.json(
        { error: "Database connection error", message: "Не удалось подключиться к базе данных" },
        { status: 500 },
      )
    }

    // Получаем все зоны доставки
    const { data: zones, error } = await supabase.from("delivery_zones").select("*")

    if (error) {
      console.error("Error fetching delivery zones:", error)
      return NextResponse.json({ error: "Failed to fetch delivery zones", message: error.message }, { status: 500 })
    }

    // Возвращаем зоны доставки
    return NextResponse.json({ zones: zones || [] }, { status: 200 })
  } catch (error) {
    console.error("Error in delivery zones API:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch delivery zones",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
