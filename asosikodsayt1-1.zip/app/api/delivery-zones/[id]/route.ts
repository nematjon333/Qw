import { NextResponse } from "next/server"
import { getDeliveryZoneById, updateDeliveryZone, deleteDeliveryZone } from "@/lib/delivery-zone-service"

// Получение зоны доставки по ID
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)
    if (isNaN(id)) {
      return NextResponse.json({ error: "Некорректный ID зоны доставки" }, { status: 400 })
    }

    const zone = await getDeliveryZoneById(id)
    if (!zone) {
      return NextResponse.json({ error: "Зона доставки не найдена" }, { status: 404 })
    }

    return NextResponse.json(zone)
  } catch (error) {
    console.error("Ошибка при получении зоны доставки:", error)
    return NextResponse.json(
      { error: "Ошибка при получении зоны доставки", details: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    )
  }
}

// Обновление зоны доставки
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)
    if (isNaN(id)) {
      return NextResponse.json({ error: "Некорректный ID зоны доставки" }, { status: 400 })
    }

    const data = await request.json()
    const updatedZone = await updateDeliveryZone(id, data)

    return NextResponse.json(updatedZone)
  } catch (error) {
    console.error("Ошибка при обновлении зоны доставки:", error)
    return NextResponse.json(
      { error: "Ошибка при обновлении зоны доставки", details: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    )
  }
}

// Удаление зоны доставки
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)
    if (isNaN(id)) {
      return NextResponse.json({ error: "Некорректный ID зоны доставки" }, { status: 400 })
    }

    await deleteDeliveryZone(id)

    return NextResponse.json({ success: true, message: "Зона доставки успешно удалена" })
  } catch (error) {
    console.error("Ошибка при удалении зоны доставки:", error)
    return NextResponse.json(
      { error: "Ошибка при удалении зоны доставки", details: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    )
  }
}
