import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase-client"
import { STORE_LATITUDE, STORE_LONGITUDE, calculateDistance } from "@/lib/dadata-service"

// Функция для проверки, находится ли точка внутри полигона
function isPointInPolygon(point: [number, number], polygon: [number, number][]): boolean {
  const [lat, lng] = point
  let inside = false

  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const [xi, yi] = polygon[i]
    const [xj, yj] = polygon[j]

    const intersect = yi > lat !== yj > lat && lng < ((xj - xi) * (lat - yi)) / (yj - yi) + xi
    if (intersect) inside = !inside
  }

  return inside
}

export async function POST(request: NextRequest) {
  try {
    const { latitude, longitude, distance: providedDistance } = await request.json()

    if (!latitude || !longitude) {
      return NextResponse.json({ error: "Latitude and longitude are required" }, { status: 400 })
    }

    // Создаем клиент Supabase
    const supabase = createClient()

    // Проверяем подключение к базе данных
    if (!supabase) {
      console.error("Failed to create Supabase client")
      return NextResponse.json(
        { error: "Database connection error", message: "Не удалось подключиться к базе данных" },
        { status: 500 },
      )
    }

    // Получаем все активные зоны доставки
    const { data: zones, error } = await supabase.from("delivery_zones").select("*").eq("active", true)

    if (error) {
      console.error("Error fetching delivery zones:", error)
      return NextResponse.json({ error: "Failed to fetch delivery zones", message: error.message }, { status: 500 })
    }

    // Если зоны не найдены, возвращаем ошибку
    if (!zones || zones.length === 0) {
      return NextResponse.json(
        {
          isDeliveryAvailable: false,
          fee: 0,
          minOrderAmount: 0,
          message: "Зоны доставки не настроены",
          distance: providedDistance || 0,
          estimatedTime: "Недоступно",
        },
        { status: 200 },
      )
    }

    console.log("Fetched delivery zones:", zones)

    // Рассчитываем расстояние от магазина до точки доставки, если оно не предоставлено
    const distance = providedDistance || calculateDistance(STORE_LATITUDE, STORE_LONGITUDE, latitude, longitude)
    console.log("Calculated distance:", distance, "meters")

    // Находим зону доставки, в которой находится точка
    let matchingZone = null

    for (const zone of zones) {
      if (zone.type === "circle" && zone.center) {
        const zoneCenter: [number, number] = [zone.center.lat, zone.center.lng]
        const distanceToCenter = calculateDistance(zoneCenter[0], zoneCenter[1], latitude, longitude)

        console.log(
          `Checking circle zone ${zone.name}: distance to center = ${distanceToCenter}, radius = ${zone.radius}`,
        )

        if (distanceToCenter <= zone.radius) {
          matchingZone = zone
          console.log(`Found matching circle zone: ${zone.name}`)
          break
        }
      } else if (zone.type === "polygon" && zone.coordinates && zone.coordinates.length > 0) {
        console.log(`Checking polygon zone ${zone.name}`)

        if (isPointInPolygon([latitude, longitude], zone.coordinates)) {
          matchingZone = zone
          console.log(`Found matching polygon zone: ${zone.name}`)
          break
        }
      }
    }

    // Если не нашли подходящую зону, проверяем по расстоянию
    if (!matchingZone) {
      console.log("No matching zone by location, checking by distance")

      // Сортируем зоны по минимальному расстоянию
      const sortedZones = [...zones].sort((a, b) => {
        const aMinDistance = a.min_distance || 0
        const bMinDistance = b.min_distance || 0
        return aMinDistance - bMinDistance
      })

      // Находим зону, в диапазон которой попадает расстояние
      for (const zone of sortedZones) {
        const minDistance = zone.min_distance || 0
        const maxDistance = zone.max_distance || Number.POSITIVE_INFINITY

        console.log(
          `Checking zone ${zone.name} by distance: min=${minDistance}, max=${maxDistance}, actual=${distance}`,
        )

        if (distance >= minDistance && distance <= maxDistance) {
          matchingZone = zone
          console.log(`Found matching zone by distance: ${zone.name}`)
          break
        }
      }
    }

    if (!matchingZone) {
      console.log("No matching delivery zone found")
      return NextResponse.json(
        {
          isDeliveryAvailable: false,
          fee: 0,
          minOrderAmount: 0,
          message: "Доставка по этому адресу недоступна",
          distance: distance,
          estimatedTime: "Недоступно",
        },
        { status: 200 },
      )
    }

    // Рассчитываем стоимость доставки
    let deliveryFee = matchingZone.base_fee || 0
    console.log(`Base delivery fee: ${deliveryFee}`)

    // Добавляем стоимость за километр, если указана
    if (matchingZone.per_km_fee && matchingZone.per_km_fee > 0) {
      const kmFee = Math.ceil(distance / 1000) * matchingZone.per_km_fee
      deliveryFee += kmFee
      console.log(`Added per km fee: ${kmFee}, total now: ${deliveryFee}`)
    }

    // Проверяем, есть ли временная надбавка (например, в плохую погоду)
    let isSurgeActive = false
    let surgeReason = ""
    let surgeAmount = 0

    try {
      const { data: surgeSettings, error: surgeError } = await supabase
        .from("delivery_surge_settings")
        .select("*")
        .eq("active", true)
        .single()

      if (!surgeError && surgeSettings) {
        isSurgeActive = true
        surgeReason = surgeSettings.reason || "Временная надбавка"
        surgeAmount = surgeSettings.amount || 0
        deliveryFee += surgeAmount
        console.log(`Added surge fee: ${surgeAmount}, total now: ${deliveryFee}`)
      }
    } catch (surgeError) {
      console.error("Error fetching surge settings:", surgeError)
      // Продолжаем выполнение без надбавки
    }

    // Рассчитываем примерное время доставки
    const baseTime = matchingZone.estimated_time || "30-45 минут"
    const estimatedTime = baseTime

    console.log("Final delivery calculation:", {
      isDeliveryAvailable: true,
      fee: deliveryFee,
      minOrderAmount: matchingZone.min_order_amount || 0,
      freeDeliveryThreshold: matchingZone.free_delivery_threshold || null,
      message: `Стоимость доставки: ${deliveryFee} ₽`,
      distance: distance,
      estimatedTime: estimatedTime,
      zoneName: matchingZone.name,
      zoneId: matchingZone.id,
      isSurgeActive,
      surgeReason,
      surgeAmount,
    })

    return NextResponse.json(
      {
        isDeliveryAvailable: true,
        fee: deliveryFee,
        minOrderAmount: matchingZone.min_order_amount || 0,
        freeDeliveryThreshold: matchingZone.free_delivery_threshold || null,
        message: `Стоимость доставки: ${deliveryFee} ₽`,
        distance: distance,
        estimatedTime: estimatedTime,
        zoneName: matchingZone.name,
        zoneId: matchingZone.id,
        isSurgeActive,
        surgeReason,
        surgeAmount,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Error calculating delivery fee:", error)
    return NextResponse.json(
      {
        error: "Failed to calculate delivery fee",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
