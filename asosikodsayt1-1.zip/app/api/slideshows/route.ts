import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET() {
  try {
    const { data, error } = await supabase.from("slideshows").select("*").order("slide_order", { ascending: true })

    if (error) {
      console.error("Ошибка при получении слайдов:", error)
      return NextResponse.json(
        {
          success: false,
          message: "Ошибка при получении слайдов",
          error,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      slideshows: data,
    })
  } catch (error) {
    console.error("Ошибка при получении слайдов:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при получении слайдов",
        error,
      },
      { status: 500 },
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Получаем максимальный порядок слайда
    const { data: maxOrderData, error: maxOrderError } = await supabase
      .from("slideshows")
      .select("slide_order")
      .order("slide_order", { ascending: false })
      .limit(1)

    if (maxOrderError) {
      console.error("Ошибка при получении максимального порядка слайда:", maxOrderError)
      return NextResponse.json(
        {
          success: false,
          message: "Ошибка при получении максимального порядка слайда",
          error: maxOrderError,
        },
        { status: 500 },
      )
    }

    const maxOrder = maxOrderData.length > 0 ? maxOrderData[0].slide_order : 0
    const newOrder = maxOrder + 1

    // Создаем новый слайд
    const { data, error } = await supabase
      .from("slideshows")
      .insert([
        {
          title: body.title,
          subtitle: body.subtitle,
          image_url: body.image_url,
          link_url: body.link_url,
          button_text: body.button_text,
          slide_order: newOrder,
          is_active: body.is_active,
        },
      ])
      .select()

    if (error) {
      console.error("Ошибка при создании слайда:", error)
      return NextResponse.json(
        {
          success: false,
          message: "Ошибка при создании слайда",
          error,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      slideshow: data[0],
    })
  } catch (error) {
    console.error("Ошибка при создании слайда:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при создании слайда",
        error,
      },
      { status: 500 },
    )
  }
}
