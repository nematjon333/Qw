import { NextResponse } from "next/server"
import { reorderSlideshows } from "@/lib/slideshow-service"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Проверка обязательных полей
    if (!data.slideshowIds || !Array.isArray(data.slideshowIds)) {
      return NextResponse.json(
        { success: false, message: "Отсутствует обязательное поле: slideshowIds" },
        { status: 400 },
      )
    }

    // Изменяем порядок слайдов
    const success = await reorderSlideshows(data.slideshowIds)

    if (!success) {
      return NextResponse.json({ success: false, message: "Не удалось изменить порядок слайдов" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Порядок слайдов успешно изменен",
    })
  } catch (error) {
    console.error("Ошибка при изменении порядка слайдов:", error)
    return NextResponse.json(
      { success: false, message: "Ошибка при изменении порядка слайдов", error: error.message },
      { status: 500 },
    )
  }
}
