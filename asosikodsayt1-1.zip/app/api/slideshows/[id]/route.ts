import { NextResponse } from "next/server"
import { getSlideshow, updateSlideshow, deleteSlideshow } from "@/lib/slideshow-service"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const slideshow = await getSlideshow(id)

    if (!slideshow) {
      return NextResponse.json({ success: false, message: "Слайд не найден" }, { status: 404 })
    }

    return NextResponse.json({ success: true, slideshow })
  } catch (error) {
    console.error(`Ошибка при получении слайда с ID ${params.id}:`, error)
    return NextResponse.json(
      { success: false, message: "Ошибка при получении слайда", error: error.message },
      { status: 500 },
    )
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const data = await request.json()

    // Обновляем слайд
    const slideshow = await updateSlideshow(id, {
      image_url: data.image_url,
      description: data.description,
      link: data.link,
      slide_order: data.slide_order,
      active: data.active,
    })

    if (!slideshow) {
      return NextResponse.json({ success: false, message: "Слайд не найден" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      message: "Слайд успешно обновлен",
      slideshow,
    })
  } catch (error) {
    console.error(`Ошибка при обновлении слайда с ID ${params.id}:`, error)
    return NextResponse.json(
      { success: false, message: "Ошибка при обновлении слайда", error: error.message },
      { status: 500 },
    )
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const success = await deleteSlideshow(id)

    if (!success) {
      return NextResponse.json({ success: false, message: "Не удалось удалить слайд" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Слайд успешно удален",
    })
  } catch (error) {
    console.error(`Ошибка при удалении слайда с ID ${params.id}:`, error)
    return NextResponse.json(
      { success: false, message: "Ошибка при удалении слайда", error: error.message },
      { status: 500 },
    )
  }
}
