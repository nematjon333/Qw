import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET() {
  try {
    // Проверяем существование таблицы categories
    const { data: checkData, error: checkError } = await supabase.from("categories").select("count(*)")

    // Если таблица не существует, создаем ее
    if (checkError && checkError.code === "42P01") {
      // Создаем таблицу categories
      const createTableSQL = `
        CREATE TABLE IF NOT EXISTS categories (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          slug TEXT NOT NULL UNIQUE,
          description TEXT,
          image_url TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
      `

      const { error: createError } = await supabase.rpc("exec_sql", { sql: createTableSQL })

      if (createError) {
        console.error("Ошибка при создании таблицы categories:", createError)
        return NextResponse.json(
          {
            success: false,
            message: "Не удалось создать таблицу categories",
            error: createError,
          },
          { status: 500 },
        )
      }

      // Вставляем категории по умолчанию
      return insertDefaultCategories()
    }

    // Проверяем, есть ли записи в таблице
    const { data: categoriesData, error: countError } = await supabase.from("categories").select("id")

    if (countError) {
      console.error("Ошибка при проверке количества категорий:", countError)
      return NextResponse.json(
        {
          success: false,
          message: "Ошибка при проверке количества категорий",
          error: countError,
        },
        { status: 500 },
      )
    }

    // Если таблица пуста, вставляем категории по умолчанию
    if (!categoriesData || categoriesData.length === 0) {
      return insertDefaultCategories()
    }

    return NextResponse.json({
      success: true,
      message: "Таблица категорий уже существует и содержит данные",
      count: categoriesData.length,
    })
  } catch (error) {
    console.error("Ошибка при настройке таблицы категорий:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при настройке таблицы категорий",
        error,
      },
      { status: 500 },
    )
  }
}

// Функция для вставки категорий по умолчанию
async function insertDefaultCategories() {
  try {
    // Сначала проверяем, какие категории уже существуют
    const { data: existingCategories, error: fetchError } = await supabase.from("categories").select("id")

    if (fetchError) {
      console.error("Ошибка при получении существующих категорий:", fetchError)
      return NextResponse.json(
        {
          success: false,
          message: "Ошибка при получении существующих категорий",
          error: fetchError,
        },
        { status: 500 },
      )
    }

    // Создаем список ID существующих категорий
    const existingIds = existingCategories ? existingCategories.map((cat) => cat.id) : []

    // Категории по умолчанию
    const defaultCategories = [
      {
        id: "fruits",
        name: "Фрукты",
        slug: "fruits",
        description: "Свежие и сочные фрукты со всего мира",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1744616841857-Yzrf1A9DeHtUGKyDRYNSg5HwtOPHSy.jpeg",
      },
      {
        id: "vegetables",
        name: "Овощи",
        slug: "vegetables",
        description: "Свежие овощи, выращенные с заботой",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1744616854012-qCqkqYJdIyZ2l5Z9kb4l011mdHgw90.jpeg",
      },
      {
        id: "berries",
        name: "Ягоды",
        slug: "berries",
        description: "Сочные и спелые ягоды",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1746285872188-EgKSmT271SdtPRrNohjabRZQgenG9c.jpeg",
      },
      {
        id: "dried-fruits",
        name: "Сухофрукты и орехи",
        slug: "dried-fruits",
        description: "Натуральные сухофрукты и орехи без добавок",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1746285856008-GBYeKnbhXfpTel3L5WmyLqA0rQQMGd.jpeg",
      },
      {
        id: "greens",
        name: "Зелень и травы",
        slug: "greens",
        description: "Свежая зелень и травы",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1745644538436-NwbuYGlsf1rD8vDtblw1LNv5g9nbTG.jpeg",
      },
      {
        id: "beverages",
        name: "Свежевыжатые соки и напитки",
        slug: "beverages",
        description: "Освежающие и полезные напитки",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1746285840236-bXLMCAMApG9CnQnYtTneRTCbMChq1x.jpeg",
      },
      {
        id: "sets",
        name: "Готовые наборы",
        slug: "sets",
        description: "Фруктовые или овощные боксы, подарочные корзины",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1746285818181-p5B8LCapGT9qnXGSyJh8hACnEN4HwD.jpeg",
      },
      {
        id: "exotic",
        name: "Экзотические продукты",
        slug: "exotic",
        description: "Манго, авокадо, питахайя и прочие редкие продукты",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1746285803266-kdoFvcpbGUGHoi3QYmlX3wpLHYXDDL.jpeg",
      },
      {
        id: "promotions",
        name: "Акции и новинки",
        slug: "promotions",
        description: "Временные предложения, сезонные товары",
        image_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1746285792020-bHwP8xyA2lBczysfdMLcOAToYo2jAo.jpeg",
      },
      {
        id: "bread",
        name: "Лепёшки и хлеб",
        slug: "bread",
        description: "Домашние лепёшки, лаваш, хлеб и булочки",
        image_url: "/placeholder.svg?height=400&width=600&text=Хлеб",
      },
    ]

    // Фильтруем категории, чтобы не вставлять уже существующие
    const categoriesToInsert = defaultCategories.filter((cat) => !existingIds.includes(cat.id))

    if (categoriesToInsert.length === 0) {
      return NextResponse.json({
        success: true,
        message: "Все категории уже существуют",
      })
    }

    // Вставляем отфильтрованные категории
    const { error: insertError } = await supabase.from("categories").insert(categoriesToInsert)

    if (insertError) {
      console.error("Ошибка при вставке категорий:", insertError)
      return NextResponse.json(
        {
          success: false,
          message: "Ошибка при вставке категорий по умолчанию",
          error: insertError,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Категории успешно добавлены",
      inserted: categoriesToInsert.length,
    })
  } catch (error) {
    console.error("Ошибка при вставке категорий по умолчанию:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при вставке категорий по умолчанию",
        error,
      },
      { status: 500 },
    )
  }
}
