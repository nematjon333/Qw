import { type NextRequest, NextResponse } from "next/server"
import nodemailer from "nodemailer"

export async function POST(request: NextRequest) {
  try {
    const { to, subject, html, service } = await request.json()

    // Проверка наличия необходимых переменных окружения
    const requiredVars = ["EMAIL_HOST", "EMAIL_PORT", "EMAIL_USER", "EMAIL_PASSWORD", "EMAIL_SERVICE"]
    const missingVars = requiredVars.filter((varName) => !process.env[varName])

    if (missingVars.length > 0) {
      console.error(`Отсутствуют необходимые переменные окружения для отправки email: ${missingVars.join(", ")}`)
      return NextResponse.json(
        {
          success: false,
          message: "Email не настроен, проверьте конфигурацию сервера",
        },
        { status: 500 },
      )
    }

    // Создаем транспорт для отправки email
    const transporter = nodemailer.createTransport({
      service: process.env.EMAIL_SERVICE || service || undefined, // Используем EMAIL_SERVICE
      host: process.env.EMAIL_HOST,
      port: Number.parseInt(process.env.EMAIL_PORT || "587"),
      secure: process.env.EMAIL_SECURE === "true",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
      },
    })

    // Отправляем email
    const info = await transporter.sendMail({
      from: `"Olucha Fresh" <${process.env.EMAIL_USER}>`,
      to,
      subject,
      html,
    })

    return NextResponse.json({
      success: true,
      message: "Email успешно отправлен",
      messageId: info.messageId,
    })
  } catch (error) {
    console.error("Ошибка при отправке email:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Ошибка при отправке email",
        error: error.message,
      },
      { status: 500 },
    )
  }
}
