import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET() {
  try {
    // Create the exec_sql function if it doesn't exist
    const createFunctionSql = `
      CREATE OR REPLACE FUNCTION exec_sql(sql text) RETURNS void AS $$
      BEGIN
        EXECUTE sql;
      END;
      $$ LANGUAGE plpgsql SECURITY DEFINER;
    `

    const { error } = await supabase.rpc("exec_sql", { sql: createFunctionSql })

    if (error) {
      // If we get an error that the function doesn't exist, we need to create it directly
      console.log("Creating function directly since it doesn't exist yet", error)
      const { error: directError } = await supabase.from("_exec_sql_direct").select("*").limit(1)

      if (directError) {
        return NextResponse.json(
          {
            success: false,
            message: "Could not create SQL execution function. Please contact support.",
            error: directError,
          },
          { status: 500 },
        )
      }
    }

    return NextResponse.json({ success: true, message: "SQL execution function ready" })
  } catch (error) {
    console.error("Error setting up SQL function:", error)
    return NextResponse.json({ success: false, message: "Error setting up SQL function", error }, { status: 500 })
  }
}
