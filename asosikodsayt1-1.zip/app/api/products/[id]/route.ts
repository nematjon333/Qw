import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Special case for "new" - return empty product template
    if (params.id === "new") {
      return NextResponse.json({
        success: true,
        product: {
          id: "new",
          name: "",
          price: 0,
          description: "",
          category: "fruits",
          unit: "кг",
          discount: 0,
          origin: "Россия",
          weight: 0,
          volume: 0,
          images: [],
          active: true,
          on_homepage: false,
          seo_title: "",
          seo_description: "",
          min_quantity: 1,
          max_quantity: 10,
          step: 1,
          stock_quantity: 100,
        },
      })
    }

    const { data, error } = await supabase.from("products").select("*").eq("id", params.id).single()

    if (error) {
      console.error("Error fetching product:", error)
      return NextResponse.json(
        { success: false, message: "Ошибка при получении товара", error: error.message },
        { status: 500 },
      )
    }

    if (!data) {
      return NextResponse.json({ success: false, message: "Товар не найден" }, { status: 404 })
    }

    return NextResponse.json({ success: true, product: data })
  } catch (error) {
    console.error("Exception fetching product:", error)
    return NextResponse.json(
      { success: false, message: "Ошибка при получении товара", error: error.message },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()

    // Validate required fields
    if (!body.name || body.price === undefined) {
      return NextResponse.json({ success: false, message: "Название и цена товара обязательны" }, { status: 400 })
    }

    // Update product
    const { data, error } = await supabase
      .from("products")
      .update({
        name: body.name,
        price: body.price,
        description: body.description,
        category: body.category,
        unit: body.unit,
        discount: body.discount,
        origin: body.origin,
        weight: body.weight,
        volume: body.volume,
        images: body.images,
        active: body.active,
        on_homepage: body.on_homepage,
        seo_title: body.seo_title,
        seo_description: body.seo_description,
        min_quantity: body.min_quantity,
        max_quantity: body.max_quantity,
        step: body.step,
        stock_quantity: body.stock_quantity,
        updated_at: new Date().toISOString(),
      })
      .eq("id", params.id)
      .select()

    if (error) {
      console.error("Error updating product:", error)
      return NextResponse.json(
        { success: false, message: "Ошибка при обновлении товара", error: error.message },
        { status: 500 },
      )
    }

    return NextResponse.json({ success: true, product: data[0] })
  } catch (error) {
    console.error("Exception updating product:", error)
    return NextResponse.json(
      { success: false, message: "Ошибка при обновлении товара", error: error.message },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { error } = await supabase.from("products").delete().eq("id", params.id)

    if (error) {
      console.error("Error deleting product:", error)
      return NextResponse.json(
        { success: false, message: "Ошибка при удалении товара", error: error.message },
        { status: 500 },
      )
    }

    return NextResponse.json({ success: true, message: "Товар успешно удален" })
  } catch (error) {
    console.error("Exception deleting product:", error)
    return NextResponse.json(
      { success: false, message: "Ошибка при удалении товара", error: error.message },
      { status: 500 },
    )
  }
}
