import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const featured = searchParams.get("featured") === "true"
    const limit = Number.parseInt(searchParams.get("limit") || "100")

    let query = supabase
      .from("products")
      .select("*")
      .eq("active", true)
      .order("created_at", { ascending: false })
      .limit(limit)

    if (category && category !== "all") {
      query = query.eq("category", category)
    }

    if (featured) {
      query = query.eq("on_homepage", true)
    }

    const { data, error } = await query

    if (error) {
      throw error
    }

    return NextResponse.json({ success: true, products: data })
  } catch (error) {
    console.error("Error fetching products:", error)
    return NextResponse.json(
      { success: false, message: "Failed to fetch products", error: error.message },
      { status: 500 },
    )
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.name || data.price === undefined) {
      return NextResponse.json({ success: false, message: "Missing required fields: name, price" }, { status: 400 })
    }

    const { data: product, error } = await supabase
      .from("products")
      .insert([
        {
          name: data.name,
          price: data.price,
          description: data.description || null,
          category: data.category || "fruits",
          unit: data.unit || "кг",
          discount: data.discount || null,
          images: data.images || [],
          origin: data.origin || null,
          weight: data.weight || null,
          volume: data.volume || null,
          min_quantity: data.min_quantity || 0.1,
          max_quantity: data.max_quantity || 10,
          step: data.step || 0.1,
          active: data.active !== undefined ? data.active : true,
          on_homepage: data.on_homepage || false,
          seo_title: data.seo_title || null,
          seo_description: data.seo_description || null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()

    if (error) {
      throw error
    }

    return NextResponse.json({ success: true, product: product[0] })
  } catch (error) {
    console.error("Error creating product:", error)
    return NextResponse.json(
      { success: false, message: "Failed to create product", error: error.message },
      { status: 500 },
    )
  }
}
