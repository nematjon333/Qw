import { type NextRequest, NextResponse } from "next/server"
import { isSlugUnique } from "@/lib/product-service"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const slug = searchParams.get("slug")
    const id = searchParams.get("id") || undefined

    if (!slug) {
      return NextResponse.json({ error: "Slug parameter is required" }, { status: 400 })
    }

    const exists = !(await isSlugUnique(slug, id))

    return NextResponse.json({ exists })
  } catch (error) {
    console.error("Error checking slug uniqueness:", error)
    return NextResponse.json({ error: "Failed to check slug uniqueness" }, { status: 500 })
  }
}
