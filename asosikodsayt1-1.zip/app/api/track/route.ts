import { NextResponse } from "next/server"
import { getOrderByNumber, getOrdersByPhone } from "@/lib/order-service"

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const { orderNumber, phone } = data

    if (!orderNumber && !phone) {
      return NextResponse.json(
        { success: false, message: "Необходимо указать номер заказа или телефон" },
        { status: 400 },
      )
    }

    let orders = []

    if (orderNumber) {
      // Поиск по номеру заказа
      const order = await getOrderByNumber(orderNumber)
      if (order) {
        orders = [order]
      }
    } else if (phone) {
      // Поиск по номеру телефона
      orders = await getOrdersByPhone(phone)
    }

    if (orders.length === 0) {
      return NextResponse.json(
        { success: false, message: "Заказы не найдены. Пожалуйста, проверьте введенные данные." },
        { status: 404 },
      )
    }

    return NextResponse.json({
      success: true,
      orders,
    })
  } catch (error) {
    console.error("Ошибка при отслеживании заказа:", error)
    return NextResponse.json({ success: false, message: "Произошла ошибка при отслеживании заказа" }, { status: 500 })
  }
}
