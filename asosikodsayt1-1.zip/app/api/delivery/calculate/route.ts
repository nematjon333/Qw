import { NextResponse } from "next/server"

// Функция для расчета расстояния между двумя точками (в метрах)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000 // Радиус Земли в метрах
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLon = ((lon2 - lon1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const distance = R * c
  return Math.round(distance)
}

// Координаты магазина
const storeCoordinates = {
  lat: 55.17227,
  lon: 61.431893,
  address: "г. Челябинск, ул. Артиллерийская 116/1",
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const { address, coordinates } = data

    if (!coordinates || !coordinates.length || coordinates.length !== 2) {
      return NextResponse.json({ success: false, error: "Неверные координаты" }, { status: 400 })
    }

    const [latitude, longitude] = coordinates

    // Расчёт расстояния от магазина до точки доставки
    const distance = calculateDistance(storeCoordinates.lat, storeCoordinates.lon, latitude, longitude)

    // Проверка на доступность доставки (в пределах 10 км)
    if (distance > 10000) {
      return NextResponse.json({
        success: false,
        error: "Адрес находится вне зоны доставки (более 10 км от магазина)",
        distance: distance,
        store: {
          name: "Olucha-fresh",
          address: storeCoordinates.address,
          coordinates: [storeCoordinates.lat, storeCoordinates.lon],
        },
      })
    }

    // Формирование вариантов доставки
    const deliveryOptions = [
      {
        id: "standard",
        type: "standard",
        title: "Стандартная доставка",
        description: "Доставка в течение 1-2 часов",
        estimatedDeliveryTime: "1-2 часа",
        deliveryTime: "1-2 часа",
        price: calculateDeliveryPrice(distance),
        minOrderAmount: calculateMinOrderAmount(distance),
        distance: distance,
      },
      {
        id: "express",
        type: "express",
        title: "Срочная доставка",
        description: "Доставка в течение 1 часа",
        estimatedDeliveryTime: "30-60 минут",
        deliveryTime: "30-60 минут",
        price: Math.round(calculateDeliveryPrice(distance) * 1.5),
        minOrderAmount: calculateMinOrderAmount(distance),
        distance: distance,
      },
      {
        id: "within_60_min",
        type: "within_60_min",
        title: "Ускоренная доставка",
        description: "Доставка в течение 60 минут",
        estimatedDeliveryTime: "45-60 минут",
        deliveryTime: "45-60 минут",
        price: Math.round(calculateDeliveryPrice(distance) * 1.2),
        minOrderAmount: calculateMinOrderAmount(distance),
        distance: distance,
      },
    ]

    return NextResponse.json({
      success: true,
      distance: distance,
      store: {
        name: "Olucha-fresh",
        address: storeCoordinates.address,
        coordinates: [storeCoordinates.lat, storeCoordinates.lon],
      },
      options: deliveryOptions,
    })
  } catch (error) {
    console.error("Error in delivery calculation:", error)
    return NextResponse.json({ success: false, error: "Ошибка при расчете стоимости доставки" }, { status: 500 })
  }
}

// Функция расчета стоимости доставки в зависимости от расстояния
function calculateDeliveryPrice(distance: number): number {
  if (distance <= 500) return 0 // До 500м - бесплатно
  if (distance <= 1000) return 50 // До 1км - 50 руб
  if (distance <= 2000) return 100 // До 2км - 100 руб
  if (distance <= 4000) return 150 // До 4км - 150 руб
  if (distance <= 6000) return 200 // До 6км - 200 руб
  if (distance <= 8000) return 250 // До 8км - 250 руб
  if (distance <= 10000) return 300 // До 10км - 300 руб
  return 400 // За пределами зоны (на всякий случай)
}

// Функция расчета минимальной суммы заказа для бесплатной доставки
function calculateMinOrderAmount(distance: number): number {
  if (distance <= 500) return 0 // До 500м - всегда бесплатно
  if (distance <= 1000) return 500 // До 1км - от 500 руб
  if (distance <= 2000) return 800 // До 2км - от 800 руб
  if (distance <= 4000) return 1000 // До 4км - от 1000 руб
  if (distance <= 6000) return 1200 // До 6км - от 1200 руб
  if (distance <= 8000) return 1500 // До 8км - от 1500 руб
  if (distance <= 10000) return 2000 // До 10км - от 2000 руб
  return 3000 // За пределами зоны (на всякий случай)
}

export async function GET() {
  // Проверка API
  return NextResponse.json({
    success: true,
    message: "API расчета доставки работает",
    storeLocation: {
      name: "Olucha-fresh",
      address: storeCoordinates.address,
      coordinates: [storeCoordinates.lat, storeCoordinates.lon],
    },
  })
}
