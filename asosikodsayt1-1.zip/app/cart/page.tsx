"use client"

import Link from "next/link"
import { ShoppingCart, Trash2, Truck, ArrowLeft, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { useCart } from "@/context/cart-context"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { QuantitySelector } from "@/components/quantity-selector"
import { PromoCodeInput } from "@/components/promo-code-input"
import { Badge } from "@/components/ui/badge"

export default function CartPage() {
  const {
    items,
    removeItem,
    updateQuantity,
    subtotal,
    deliveryFee,
    total,
    promoCode,
    promoDiscount,
    applyPromoCode,
    removePromoCode,
  } = useCart()

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-8">
          <div className="mb-6 flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link href="/">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад
              </Link>
            </Button>
            <h1 className="text-3xl font-bold">Корзина</h1>
          </div>

          {items.length > 0 ? (
            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <div className="rounded-lg border">
                  {items.map((item, index) => {
                    const discountedPrice = item.discount ? item.price - (item.price * item.discount) / 100 : item.price

                    return (
                      <div key={item.id}>
                        <div className="flex items-center gap-4 p-4">
                          <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-md">
                            <img
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <Link href={`/product/${item.id}`} className="font-medium hover:text-green-600">
                              {item.name}
                            </Link>
                            <div className="mt-1 flex items-baseline gap-2">
                              <span className="font-medium">
                                {discountedPrice.toFixed(0)} ₽/{item.unit}
                              </span>
                              {item.discount && (
                                <span className="text-sm text-gray-500 line-through">{item.price.toFixed(0)} ₽</span>
                              )}
                            </div>
                          </div>
                          <div>
                            <QuantitySelector
                              initialValue={item.quantity}
                              min={0.1}
                              max={10}
                              step={0.1}
                              unit={item.unit}
                              onChange={(value) => updateQuantity(item.id, value)}
                            />
                          </div>
                          <div className="text-right">
                            <div className="font-medium">{(discountedPrice * item.quantity).toFixed(0)} ₽</div>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-gray-500"
                              onClick={() => removeItem(item.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        {index < items.length - 1 && <Separator />}
                      </div>
                    )
                  })}
                </div>
              </div>

              <div>
                <div className="rounded-lg border p-6 sticky top-20">
                  <h2 className="mb-4 text-lg font-semibold">Сумма заказа</h2>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Товары ({items.length})</span>
                      <span>{subtotal.toFixed(0)} ₽</span>
                    </div>

                    {promoCode && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 flex items-center">
                          Промокод:
                          <Badge variant="outline" className="ml-2 font-normal">
                            {promoCode}
                            <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={removePromoCode}>
                              <X className="h-3 w-3" />
                            </Button>
                          </Badge>
                        </span>
                        <span className="text-green-600">-{promoDiscount.toFixed(0)} ₽</span>
                      </div>
                    )}

                    <div className="flex justify-between">
                      <span className="text-gray-600">Доставка</span>
                      <span>{deliveryFee} ₽</span>
                    </div>
                    <Separator className="my-4" />
                    <div className="flex justify-between text-lg font-semibold">
                      <span>Итого</span>
                      <span>{total.toFixed(0)} ₽</span>
                    </div>
                  </div>

                  <Button className="mt-6 w-full gap-2 bg-green-600 hover:bg-green-700" asChild>
                    <Link href="/checkout">Оформить заказ</Link>
                  </Button>

                  <div className="mt-4 rounded-lg bg-green-50 p-3 flex items-center gap-2">
                    <Truck className="h-5 w-5 text-green-600" />
                    <p className="text-sm">Доставка по Челябинску</p>
                  </div>
                </div>

                <div className="mt-6 rounded-lg border p-6">
                  <PromoCodeInput subtotal={subtotal} onApply={applyPromoCode} />
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <ShoppingCart className="mb-4 h-16 w-16 text-gray-300" />
              <h2 className="mb-2 text-xl font-semibold">Ваша корзина пуста</h2>
              <p className="mb-6 text-gray-600">Добавьте товары в корзину, чтобы оформить заказ</p>
              <Button asChild className="bg-green-600 hover:bg-green-700">
                <Link href="/catalog">Перейти в каталог</Link>
              </Button>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
