"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ArrowLeft, Search } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"

import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Input } from "@/components/ui/input"
import { supabase } from "@/lib/supabase-client"

// Define product type
interface Product {
  id: string
  name: string
  price: number
  description?: string
  category: string
  unit: string
  discount?: number
  images?: string[]
  stock_quantity?: number
  min_quantity?: number
  max_quantity?: number
  step?: number
  active?: boolean
}

const categories = [
  { id: "all", name: "Все категории" },
  { id: "fruits", name: "Фрукты" },
  { id: "vegetables", name: "Овощи" },
  { id: "berries", name: "Ягоды" },
  { id: "greens", name: "Зелень" },
  { id: "dried-fruits", name: "Сухофрукты и орехи" },
  { id: "beverages", name: "Свежевыжатые соки и напитки" },
  { id: "bread", name: "Лепёшки и хлеб" },
  { id: "sets", name: "Готовые наборы" },
  { id: "exotic", name: "Экзотические продукты" },
  { id: "promotions", name: "Акции и новинки" },
]

export default function CatalogPage() {
  const searchParams = useSearchParams()
  const categoryParam = searchParams.get("category")

  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState(categoryParam || "all")
  const [sortOrder, setSortOrder] = useState("name-asc")
  const [searchQuery, setSearchQuery] = useState("")
  const [error, setError] = useState<string | null>(null)

  // Загрузка товаров при монтировании компонента
  useEffect(() => {
    async function fetchProducts() {
      try {
        setLoading(true)
        setError(null)

        let query = supabase.from("products").select("*").eq("active", true)

        if (selectedCategory !== "all") {
          query = query.eq("category", selectedCategory)
        }

        // Apply sorting
        switch (sortOrder) {
          case "price-asc":
            query = query.order("price", { ascending: true })
            break
          case "price-desc":
            query = query.order("price", { ascending: false })
            break
          case "discount":
            query = query.order("discount", { ascending: false, nullsLast: true })
            break
          case "name-asc":
            query = query.order("name", { ascending: true })
            break
          default: // popular or any other
            query = query.order("name", { ascending: true })
        }

        const { data, error } = await query

        if (error) {
          console.error("Ошибка при получении товаров:", error)
          setError("Не удалось загрузить товары. Пожалуйста, попробуйте позже.")
          setProducts([])
        } else {
          setProducts(data || [])
        }
      } catch (error) {
        console.error("Ошибка при получении товаров:", error)
        setError("Произошла ошибка при загрузке товаров.")
        setProducts([])
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [selectedCategory, sortOrder])

  // Filter products by search query
  const filteredProducts = searchQuery
    ? products.filter(
        (product) =>
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase())),
      )
    : products

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category)
  }

  const handleSortChange = (sort: string) => {
    setSortOrder(sort)
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 bg-gray-50 dark:bg-gray-900">
        <div className="container py-8">
          <div className="mb-4 flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link href="/">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад
              </Link>
            </Button>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              <Link href="/" className="hover:text-green-600 dark:hover:text-green-400">
                Главная
              </Link>
              {" > "}
              <span>Каталог</span>
            </div>
          </div>

          <h1 className="mb-6 text-3xl font-bold dark:text-white">Каталог товаров</h1>

          <div className="mb-6 rounded-xl bg-white p-4 shadow-sm dark:bg-gray-800 dark:shadow-gray-700/10">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-2">
                <Select value={selectedCategory} onValueChange={handleCategoryChange}>
                  <SelectTrigger className="w-[180px] dark:bg-gray-700 dark:border-gray-600">
                    <SelectValue placeholder="Категория" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Поиск товаров..."
                    value={searchQuery}
                    onChange={handleSearch}
                    className="pl-10 dark:bg-gray-700 dark:border-gray-600"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500 dark:text-gray-400">Сортировать:</span>
                <Select value={sortOrder} onValueChange={handleSortChange}>
                  <SelectTrigger className="w-[180px] dark:bg-gray-700 dark:border-gray-600">
                    <SelectValue placeholder="Сортировка" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name-asc">По алфавиту</SelectItem>
                    <SelectItem value="price-asc">Сначала дешевле</SelectItem>
                    <SelectItem value="price-desc">Сначала дороже</SelectItem>
                    <SelectItem value="discount">По скидке</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {error && (
            <div className="mb-6 rounded-lg bg-red-50 p-4 text-red-600 dark:bg-red-900/20 dark:text-red-400">
              <p>{error}</p>
            </div>
          )}

          {loading ? (
            <div className="flex justify-center py-12">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-current border-t-transparent text-green-600 dark:text-green-400"></div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {filteredProducts.length > 0 ? (
                filteredProducts.map((product) => (
                  <div key={product.id}>
                    <ProductCard
                      id={product.id}
                      name={product.name}
                      price={product.price}
                      image={product.images?.[0] || "/placeholder.svg?height=200&width=200"}
                      unit={product.unit || "шт"}
                      discount={product.discount}
                      step={product.step || 1}
                      minQuantity={product.min_quantity || 1}
                      maxQuantity={product.max_quantity || 10}
                      stockQuantity={product.stock_quantity}
                    />
                  </div>
                ))
              ) : (
                <div className="col-span-full py-12 text-center">
                  <p className="text-gray-500 dark:text-gray-400">Товары не найдены</p>
                  <p className="mt-2 text-sm text-gray-400 dark:text-gray-500">
                    Попробуйте изменить параметры фильтрации или добавьте новые товары в панели управления
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
