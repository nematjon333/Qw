"use client"

import Link from "next/link"
import { Heart, ShoppingCart, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useFavorites } from "@/context/favorites-context"
import { useCart } from "@/context/cart-context"
import { ProductCard } from "@/components/product-card"

export default function FavoritesPage() {
  const { items, clearItems } = useFavorites()
  const { addItem } = useCart()

  const handleAddAllToCart = () => {
    items.forEach((item) => {
      addItem({
        ...item,
        quantity: 1,
      })
    })
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-8">
          <div className="mb-6 flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link href="/">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад
              </Link>
            </Button>
            <h1 className="text-3xl font-bold">Избранное</h1>
          </div>

          {items.length > 0 ? (
            <>
              <div className="flex justify-between items-center mb-6">
                <p className="text-gray-600">Товаров в избранном: {items.length}</p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={clearItems}>
                    Очистить список
                  </Button>
                  <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={handleAddAllToCart}>
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Добавить все в корзину
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                {items.map((item) => (
                  <ProductCard
                    key={item.id}
                    id={item.id}
                    name={item.name}
                    price={item.price}
                    image={item.image}
                    unit={item.unit}
                    discount={item.discount}
                  />
                ))}
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Heart className="mb-4 h-16 w-16 text-gray-300" />
              <h2 className="mb-2 text-xl font-semibold">В избранном пока ничего нет</h2>
              <p className="mb-6 text-gray-600">
                Добавляйте товары в избранное, чтобы быстро находить их в следующий раз
              </p>
              <Button asChild className="bg-green-600 hover:bg-green-700">
                <Link href="/catalog">Перейти в каталог</Link>
              </Button>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}
