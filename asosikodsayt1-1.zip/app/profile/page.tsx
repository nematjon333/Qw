"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Loader2, User, Phone, Lock, Mail, LogOut, MapPin, ShoppingBag, Heart } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { formatPhoneNumber } from "@/lib/utils"

export default function ProfilePage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userData, setUserData] = useState<any>(null)
  const [activeTab, setActiveTab] = useState("initial")

  // Состояние для форм
  const [initialForm, setInitialForm] = useState({
    name: "",
    phone: "",
  })

  const [loginForm, setLoginForm] = useState({
    phone: "",
    password: "",
  })

  const [registerForm, setRegisterForm] = useState({
    name: "",
    phone: "",
    password: "",
    confirmPassword: "",
  })

  // Исправим функцию проверки аутентификации
  useEffect(() => {
    const checkAuth = async () => {
      try {
        setIsLoading(true)
        const response = await fetch("/api/users/check")

        // Проверяем статус ответа перед попыткой парсинга JSON
        if (!response.ok) {
          console.error("Ошибка при проверке аутентификации:", response.status, response.statusText)
          setIsAuthenticated(false)
          setUserData(null)
          return
        }

        // Проверяем, что ответ в формате JSON
        const contentType = response.headers.get("content-type")
        if (!contentType || !contentType.includes("application/json")) {
          console.error("Ответ не в формате JSON:", await response.text())
          setIsAuthenticated(false)
          setUserData(null)
          return
        }

        const data = await response.json()

        if (data.success && data.user) {
          setIsAuthenticated(true)
          setUserData(data.user)
        } else {
          setIsAuthenticated(false)
          setUserData(null)
        }
      } catch (error) {
        console.error("Ошибка при проверке аутентификации:", error)
        setIsAuthenticated(false)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  // Обработчик изменения номера телефона
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>, formType: string) => {
    const value = e.target.value
    const formattedPhone = formatPhoneNumber(value)

    if (formType === "initial") {
      setInitialForm({ ...initialForm, phone: formattedPhone })
    } else if (formType === "login") {
      setLoginForm({ ...loginForm, phone: formattedPhone })
    } else if (formType === "register") {
      setRegisterForm({ ...registerForm, phone: formattedPhone })
    }
  }

  // Исправим функцию handleInitialSubmit
  const handleInitialSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Проверяем, существует ли пользователь с таким телефоном
      const response = await fetch(`/api/users/check`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ phone: initialForm.phone }),
      })

      // Проверяем статус ответа перед попыткой парсинга JSON
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      // Проверяем, что ответ в формате JSON
      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        const text = await response.text()
        console.error("Ответ не в формате JSON:", text)
        throw new Error("Ответ сервера не в формате JSON")
      }

      const data = await response.json()

      if (data.exists) {
        // Пользователь существует, переходим к форме входа
        setLoginForm({
          ...loginForm,
          phone: initialForm.phone,
        })
        setActiveTab("login")
        toast({
          title: "Пользователь найден",
          description: "Пожалуйста, введите пароль для входа",
        })
      } else {
        // Пользователь не существует, переходим к форме регистрации
        setRegisterForm({
          ...registerForm,
          name: initialForm.name,
          phone: initialForm.phone,
        })
        setActiveTab("register")
        toast({
          title: "Новый пользователь",
          description: "Пожалуйста, заполните данные для регистрации",
        })
      }
    } catch (error) {
      console.error("Ошибка при проверке пользователя:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось проверить данные пользователя",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Обработчик входа
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch("/api/users/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          phone: loginForm.phone,
          password: loginForm.password,
        }),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Успешный вход",
          description: "Вы успешно вошли в свой аккаунт",
        })
        setIsAuthenticated(true)
        setUserData(data.user)
      } else {
        toast({
          title: "Ошибка входа",
          description: data.message || "Неверный телефон или пароль",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Ошибка при входе:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось выполнить вход",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Обработчик регистрации
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()

    // Проверка паролей
    if (registerForm.password !== registerForm.confirmPassword) {
      toast({
        title: "Ошибка",
        description: "Пароли не совпадают",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/users/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: registerForm.name,
          phone: registerForm.phone,
          password: registerForm.password,
        }),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Успешная регистрация",
          description: "Вы успешно зарегистрировались",
        })
        setIsAuthenticated(true)
        setUserData(data.user)
      } else {
        toast({
          title: "Ошибка регистрации",
          description: data.message || "Не удалось зарегистрироваться",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Ошибка при регистрации:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось выполнить регистрацию",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Обработчик выхода
  const handleLogout = async () => {
    setIsLoading(true)

    try {
      const response = await fetch("/api/users/logout", {
        method: "POST",
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Выход выполнен",
          description: "Вы успешно вышли из аккаунта",
        })
        setIsAuthenticated(false)
        setUserData(null)
      } else {
        toast({
          title: "Ошибка",
          description: "Не удалось выйти из аккаунта",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Ошибка при выходе:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось выполнить выход",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Если пользователь аутентифицирован, показываем профиль
  if (isAuthenticated && userData) {
    return (
      <div className="container max-w-4xl py-8">
        <Card className="w-full">
          <CardHeader>
            <CardTitle className="text-2xl">Личный кабинет</CardTitle>
            <CardDescription>Управляйте своим профилем и заказами</CardDescription>
          </CardHeader>

          <CardContent>
            <div className="grid gap-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <div className="bg-green-100 dark:bg-green-900/30 rounded-full p-6 text-green-600 dark:text-green-400">
                  <User className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-xl font-medium">{userData.name}</h3>
                  <p className="text-gray-500 dark:text-gray-400 flex items-center gap-1">
                    <Phone className="h-4 w-4" /> {userData.phone}
                  </p>
                  {userData.email && (
                    <p className="text-gray-500 dark:text-gray-400 flex items-center gap-1">
                      <Mail className="h-4 w-4" /> {userData.email}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <Button
                  variant="outline"
                  className="flex items-center gap-2 justify-start h-auto py-4"
                  onClick={() => router.push("/orders")}
                >
                  <ShoppingBag className="h-5 w-5 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium">Мои заказы</div>
                    <div className="text-sm text-gray-500">История заказов</div>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="flex items-center gap-2 justify-start h-auto py-4"
                  onClick={() => router.push("/favorites")}
                >
                  <Heart className="h-5 w-5 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium">Избранное</div>
                    <div className="text-sm text-gray-500">Сохраненные товары</div>
                  </div>
                </Button>

                <Button
                  variant="outline"
                  className="flex items-center gap-2 justify-start h-auto py-4"
                  onClick={() => router.push("/addresses")}
                >
                  <MapPin className="h-5 w-5 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium">Адреса доставки</div>
                    <div className="text-sm text-gray-500">Управление адресами</div>
                  </div>
                </Button>
              </div>
            </div>
          </CardContent>

          <CardFooter className="flex justify-end">
            <Button
              variant="outline"
              className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
              onClick={handleLogout}
              disabled={isLoading}
            >
              {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <LogOut className="h-4 w-4 mr-2" />}
              Выйти из аккаунта
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  // Если пользователь не аутентифицирован, показываем форму входа/регистрации
  return (
    <div className="container max-w-md py-8">
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-2xl">Личный кабинет</CardTitle>
          <CardDescription>Войдите или зарегистрируйтесь для доступа к личному кабинету</CardDescription>
        </CardHeader>

        <CardContent>
          {activeTab === "initial" ? (
            <form onSubmit={handleInitialSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Ваше имя</Label>
                <Input
                  id="name"
                  placeholder="Введите ваше имя"
                  value={initialForm.name}
                  onChange={(e) => setInitialForm({ ...initialForm, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Номер телефона</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+7 (___) ___-__-__"
                  value={initialForm.phone}
                  onChange={(e) => handlePhoneChange(e, "initial")}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                Продолжить
              </Button>
            </form>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Вход</TabsTrigger>
                <TabsTrigger value="register">Регистрация</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-phone">Номер телефона</Label>
                    <Input
                      id="login-phone"
                      type="tel"
                      value={loginForm.phone}
                      onChange={(e) => handlePhoneChange(e, "login")}
                      required
                      disabled
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="login-password">Пароль</Label>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="Введите пароль"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Lock className="h-4 w-4 mr-2" />}
                    Войти
                  </Button>

                  <div className="text-center">
                    <Button variant="link" className="text-sm text-gray-500" onClick={() => setActiveTab("initial")}>
                      Вернуться назад
                    </Button>
                  </div>
                </form>
              </TabsContent>

              <TabsContent value="register">
                <form onSubmit={handleRegister} className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="register-name">Ваше имя</Label>
                    <Input
                      id="register-name"
                      placeholder="Введите ваше имя"
                      value={registerForm.name}
                      onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-phone">Номер телефона</Label>
                    <Input
                      id="register-phone"
                      type="tel"
                      value={registerForm.phone}
                      onChange={(e) => handlePhoneChange(e, "register")}
                      required
                      disabled
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-password">Пароль</Label>
                    <Input
                      id="register-password"
                      type="password"
                      placeholder="Придумайте пароль"
                      value={registerForm.password}
                      onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="register-confirm-password">Подтверждение пароля</Label>
                    <Input
                      id="register-confirm-password"
                      type="password"
                      placeholder="Повторите пароль"
                      value={registerForm.confirmPassword}
                      onChange={(e) => setRegisterForm({ ...registerForm, confirmPassword: e.target.value })}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <User className="h-4 w-4 mr-2" />}
                    Зарегистрироваться
                  </Button>

                  <div className="text-center">
                    <Button variant="link" className="text-sm text-gray-500" onClick={() => setActiveTab("initial")}>
                      Вернуться назад
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
