"use client"

import Link from "next/link"
import { Truck, ArrowLeft, Plus, Minus } from "lucide-react"
import { useState, useEffect } from "react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { ProductCard } from "@/components/product-card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useCart } from "@/context/cart-context"
import { toast } from "@/components/ui/use-toast"
import { ProductImageGallery } from "@/components/product-image-gallery"
import { ecommerceEvents } from "@/lib/analytics"

// Sample related products data
const relatedProductsData = [
  {
    id: "1",
    name: "Яблоки Голден",
    price: 159,
    image: "/placeholder.svg?height=400&width=400",
    unit: "кг",
    discount: 15,
  },
  {
    id: "2",
    name: "Бананы",
    price: 129,
    image: "/placeholder.svg?height=400&width=400",
    unit: "кг",
  },
  {
    id: "3",
    name: "Апельсины",
    price: 189,
    image: "/placeholder.svg?height=400&width=400",
    unit: "кг",
    discount: 10,
  },
  {
    id: "9",
    name: "Груши",
    price: 229,
    image: "/placeholder.svg?height=400&width=400",
    unit: "кг",
  },
]

// This is a mock function to get related products
function getRelatedProducts(ids: string[]) {
  return relatedProductsData.filter((product) => ids?.includes(product.id))
}

export function ProductInfo({ product }: { product: any }) {
  const [quantity, setQuantity] = useState(product.min_quantity || 1)
  const { addItem, items, updateQuantity } = useCart()
  const relatedProducts = product.related ? getRelatedProducts(product.related) : []

  const discountedPrice = product.discount ? product.price - (product.price * product.discount) / 100 : null

  // Check if product is in stock
  const isInStock = (product.stock_quantity || 0) > 0

  // Check if the product is already in cart
  const cartItem = items.find((item) => item.id === product.id)
  const isInCart = Boolean(cartItem)

  useEffect(() => {
    // Отслеживаем просмотр товара
    ecommerceEvents.viewItem({
      id: product.id,
      name: product.name,
      price: product.price,
      category: product.category,
    })
  }, [product])

  const handleAddToCart = () => {
    if (!isInStock) {
      toast({
        title: "Товар недоступен",
        description: "К сожалению, данный товар отсутствует в наличии",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image || product.images?.[0] || "/placeholder.svg?height=400&width=400",
      unit: product.unit,
      discount: product.discount,
      quantity: quantity,
    })

    toast({
      title: "Товар добавлен в корзину",
      description: `${product.name} (${quantity} ${product.unit})`,
      variant: "success",
      duration: 3000,
    })
  }

  const handleQuantityChange = (newQuantity: number) => {
    setQuantity(newQuantity)
  }

  const handleIncreaseQuantity = () => {
    if (!isInStock) {
      toast({
        title: "Товар недоступен",
        description: "К сожалению, данный товар отсутствует в наличии",
        variant: "destructive",
        duration: 3000,
      })
      return
    }

    if (!isInCart) {
      // If product is not in cart, add it
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image || product.images?.[0] || "/placeholder.svg?height=400&width=400",
        unit: product.unit,
        discount: product.discount,
        quantity: product.min_quantity || 1,
      })
    } else {
      // If product is already in cart, increase quantity
      const step = product.step || 1
      const maxQuantity = product.max_quantity || 10
      const newQuantity = Math.min(cartItem.quantity + step, maxQuantity)
      updateQuantity(product.id, newQuantity)
    }

    toast({
      title: "Товар добавлен в корзину",
      description: `${product.name}`,
      variant: "success",
      duration: 3000,
    })
  }

  // Подготавливаем массив изображений для галереи
  const productImages =
    product.images && product.images.length > 0
      ? product.images
      : product.image
        ? [product.image]
        : ["/placeholder.svg?height=400&width=400"]

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <div className="container py-8">
          <div className="mb-4 flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link href="/catalog">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад в каталог
              </Link>
            </Button>
            <div className="text-sm text-gray-500">
              <Link href="/" className="hover:text-green-600">
                Главная
              </Link>
              {" > "}
              <Link href="/catalog" className="hover:text-green-600">
                Каталог
              </Link>
              {" > "}
              <span>{product.name}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <ProductImageGallery images={productImages} alt={product.name} />

            <div>
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>

              <div className="flex items-baseline gap-2 mb-4">
                {discountedPrice ? (
                  <>
                    <span className="text-2xl font-bold">
                      {discountedPrice.toFixed(0)} ₽/{product.unit}
                    </span>
                    <span className="text-lg text-gray-500 line-through">{product.price.toFixed(0)} ₽</span>
                    <span className="ml-2 rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-600 dark:bg-red-900/30 dark:text-red-400">
                      -{product.discount}%
                    </span>
                  </>
                ) : (
                  <span className="text-2xl font-bold">
                    {product.price.toFixed(0)} ₽/{product.unit}
                  </span>
                )}
              </div>

              {/* Stock status */}
              {!isInStock && (
                <div className="mb-4 p-2 bg-red-50 text-red-600 rounded-md font-medium">Нет в наличии</div>
              )}

              <p className="text-gray-600 mb-6 dark:text-gray-300">{product.description}</p>

              <div className="mb-6 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500 dark:text-gray-400">Происхождение:</span>
                  <span>{product.origin}</span>
                </div>
                {product.weight && (
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Вес:</span>
                    <span>
                      {product.weight} {product.unit}
                    </span>
                  </div>
                )}
                {product.volume && (
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Объем:</span>
                    <span>
                      {product.volume} {product.unit}
                    </span>
                  </div>
                )}
                {product.category && (
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Категория:</span>
                    <span>{product.category}</span>
                  </div>
                )}
                {product.stock_quantity !== undefined && (
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Наличие:</span>
                    <span>{isInStock ? `${product.stock_quantity} ${product.unit}` : "Нет в наличии"}</span>
                  </div>
                )}
                {product.min_quantity && (
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Мин. количество:</span>
                    <span>
                      {product.min_quantity} {product.unit}
                    </span>
                  </div>
                )}
                {product.max_quantity && (
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">Макс. количество:</span>
                    <span>
                      {product.max_quantity} {product.unit}
                    </span>
                  </div>
                )}
              </div>

              <Separator className="my-6 dark:border-gray-700" />

              <div className="flex items-center gap-4 mb-6">
                {!isInStock ? (
                  <Button className="w-full gap-2 bg-gray-300 hover:bg-gray-400 cursor-not-allowed" disabled>
                    Нет в наличии
                  </Button>
                ) : !isInCart ? (
                  <Button
                    className="w-full h-12 rounded-full bg-green-600 hover:bg-green-700"
                    onClick={handleIncreaseQuantity}
                  >
                    <Plus className="h-5 w-5" />
                  </Button>
                ) : (
                  <div className="flex items-center justify-between w-full rounded-full overflow-hidden border border-gray-200">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-12 w-12 rounded-l-full"
                      onClick={() => {
                        const step = product.step || 1
                        const minQuantity = product.min_quantity || 1
                        if (cartItem.quantity <= minQuantity) {
                          // Remove from cart
                          updateQuantity(product.id, 0)
                        } else {
                          // Decrease quantity
                          updateQuantity(product.id, cartItem.quantity - step)
                        }
                      }}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="flex-1 text-center font-medium">
                      {cartItem?.quantity.toFixed(product.step && product.step < 1 ? 1 : 0)} {product.unit}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-12 w-12 rounded-r-full"
                      onClick={() => {
                        const step = product.step || 1
                        const maxQuantity = product.max_quantity || 10
                        updateQuantity(product.id, Math.min(cartItem.quantity + step, maxQuantity))
                      }}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>

              <div className="rounded-lg bg-green-50 p-4 flex items-center gap-3 dark:bg-green-900/20">
                <Truck className="h-5 w-5 text-green-600 dark:text-green-400" />
                <div>
                  <p className="font-medium">Быстрая доставка по Челябинску</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">По всему Челябинску</p>
                </div>
              </div>
            </div>
          </div>

          {relatedProducts.length > 0 && (
            <section className="mt-12">
              <h2 className="text-2xl font-bold mb-6">Похожие товары</h2>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                {relatedProducts.map((product) => (
                  <ProductCard key={product.id} {...product} />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}

import { notFound } from "next/navigation"
import { getProductById } from "@/lib/product-service"

export default async function ProductDetailPage({ params }: { params: { id: string } }) {
  try {
    const product = await getProductById(params.id)

    if (!product) {
      return notFound()
    }

    return <ProductInfo product={product} />
  } catch (error) {
    console.error("Ошибка при загрузке товара:", error)
    return notFound()
  }
}
