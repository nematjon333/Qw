"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useCart } from "@/context/cart-context"
import { useFavorites } from "@/context/favorites-context"
import { Heart, Share2, ArrowLeft, ShoppingCart, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ProductImageGallery } from "@/components/product-image-gallery"
import { QuantitySelector } from "@/components/quantity-selector"
import { toast } from "@/hooks/use-toast"
import type { Product } from "@/lib/product-service"

interface ProductInfoProps {
  product: Product
}

export function ProductInfo({ product }: ProductInfoProps) {
  const router = useRouter()
  const { addItem, isInCart, updateQuantity, getItemQuantity } = useCart()
  const { addToFavorites, removeFromFavorites, isFavorite } = useFavorites()
  const [quantity, setQuantity] = useState(product.min_quantity || 1)
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [isFavoriteState, setIsFavoriteState] = useState(false)

  // Проверяем, есть ли товар в избранном
  useEffect(() => {
    setIsFavoriteState(isFavorite(product.id))
  }, [isFavorite, product.id])

  // Устанавливаем начальное количество из корзины, если товар уже там есть
  useEffect(() => {
    if (isInCart(product.id)) {
      setQuantity(getItemQuantity(product.id))
    } else {
      setQuantity(product.min_quantity || 1)
    }
  }, [isInCart, getItemQuantity, product.id, product.min_quantity])

  // Функция для добавления товара в корзину
  const handleAddToCart = () => {
    setIsAddingToCart(true)

    // Если товар уже в корзине, обновляем количество
    if (isInCart(product.id)) {
      updateQuantity(product.id, quantity)
      toast({
        title: "Количество обновлено",
        description: `${product.name} теперь в корзине: ${quantity} ${product.unit}`,
      })
    } else {
      // Иначе добавляем новый товар
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        discount: product.discount,
        image: product.images && product.images.length > 0 ? product.images[0] : "/placeholder.svg",
        quantity: quantity,
        unit: product.unit,
      })
      toast({
        title: "Товар добавлен в корзину",
        description: `${product.name} (${quantity} ${product.unit})`,
      })
    }

    setTimeout(() => {
      setIsAddingToCart(false)
    }, 500)
  }

  // Функция для переключения избранного
  const toggleFavorite = () => {
    if (isFavoriteState) {
      removeFromFavorites(product.id)
      setIsFavoriteState(false)
      toast({
        title: "Удалено из избранного",
        description: product.name,
      })
    } else {
      addToFavorites({
        id: product.id,
        name: product.name,
        price: product.price,
        discount: product.discount,
        image: product.images && product.images.length > 0 ? product.images[0] : "/placeholder.svg",
        unit: product.unit,
      })
      setIsFavoriteState(true)
      toast({
        title: "Добавлено в избранное",
        description: product.name,
      })
    }
  }

  // Функция для поделиться товаром
  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: product.name,
          text: product.description,
          url: window.location.href,
        })
      } else {
        // Если Web Share API не поддерживается, копируем ссылку в буфер обмена
        await navigator.clipboard.writeText(window.location.href)
        toast({
          title: "Ссылка скопирована",
          description: "Теперь вы можете поделиться ею с друзьями",
        })
      }
    } catch (error) {
      console.error("Ошибка при попытке поделиться:", error)
    }
  }

  // Рассчитываем цену с учетом скидки
  const finalPrice = product.discount ? Math.round(product.price * (1 - product.discount / 100)) : product.price

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Кнопка назад */}
      <Button
        variant="ghost"
        className="mb-4 flex items-center text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100"
        onClick={() => router.back()}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Назад
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Галерея изображений */}
        <div>
          <ProductImageGallery images={product.images || []} alt={product.name} productName={product.name} />
        </div>

        {/* Информация о товаре */}
        <div className="space-y-6">
          <h1 className="text-3xl font-bold">{product.name}</h1>

          {/* Цена и скидка */}
          <div className="flex items-center space-x-4">
            <span className="text-2xl font-bold">
              {finalPrice} ₽/{product.unit}
            </span>
            {product.discount && (
              <div className="flex items-center space-x-2">
                <span className="text-lg text-gray-500 line-through">{product.price} ₽</span>
                <span className="px-2 py-1 bg-red-100 text-red-800 text-sm font-medium rounded dark:bg-red-900 dark:text-red-200">
                  -{product.discount}%
                </span>
              </div>
            )}
          </div>

          {/* Происхождение */}
          {product.origin && (
            <div>
              <span className="text-sm text-gray-500 dark:text-gray-400">Происхождение: </span>
              <span className="text-sm font-medium">{product.origin}</span>
            </div>
          )}

          {/* Описание */}
          <div className="prose dark:prose-invert max-w-none">
            <p>{product.description}</p>
          </div>

          {/* Выбор количества */}
          <div className="space-y-2">
            <label htmlFor="quantity" className="block text-sm font-medium">
              Количество ({product.unit})
            </label>
            <QuantitySelector
              id="quantity"
              value={quantity}
              onChange={setQuantity}
              min={product.min_quantity || 0.1}
              max={product.max_quantity || 100}
              step={product.step || 0.1}
              unit={product.unit}
            />
          </div>

          {/* Кнопки действий */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button className="flex-1" size="lg" onClick={handleAddToCart} disabled={isAddingToCart}>
              {isInCart(product.id) ? (
                <>
                  <Check className="mr-2 h-5 w-5" />
                  Обновить в корзине
                </>
              ) : (
                <>
                  <ShoppingCart className="mr-2 h-5 w-5" />В корзину
                </>
              )}
            </Button>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-12 w-12"
                onClick={toggleFavorite}
                aria-label={isFavoriteState ? "Удалить из избранного" : "Добавить в избранное"}
              >
                <Heart className={`h-5 w-5 ${isFavoriteState ? "fill-red-500 text-red-500" : ""}`} />
              </Button>
              <Button variant="outline" size="icon" className="h-12 w-12" onClick={handleShare} aria-label="Поделиться">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Дополнительная информация */}
          <div className="border-t pt-4 mt-6 space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500 dark:text-gray-400">Категория: </span>
                <span className="font-medium">{getCategoryName(product.category)}</span>
              </div>
              {product.weight && (
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Вес: </span>
                  <span className="font-medium">{product.weight} кг</span>
                </div>
              )}
              {product.volume && (
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Объем: </span>
                  <span className="font-medium">{product.volume} л</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Структурированные данные для SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org/",
            "@type": "Product",
            name: product.name,
            image: product.images && product.images.length > 0 ? product.images : ["/placeholder.svg"],
            description: product.description,
            sku: product.id,
            brand: {
              "@type": "Brand",
              name: "OLUCHA",
            },
            offers: {
              "@type": "Offer",
              url: typeof window !== "undefined" ? window.location.href : "",
              priceCurrency: "RUB",
              price: finalPrice,
              priceValidUntil: new Date(new Date().setFullYear(new Date().getFullYear() + 1))
                .toISOString()
                .split("T")[0],
              availability: "https://schema.org/InStock",
              seller: {
                "@type": "Organization",
                name: "OLUCHA",
              },
            },
          }),
        }}
      />
    </div>
  )
}

// Вспомогательная функция для получения названия категории на русском
function getCategoryName(categorySlug: string): string {
  const categories: Record<string, string> = {
    fruits: "Фрукты",
    vegetables: "Овощи",
    berries: "Ягоды",
    "dried-fruits": "Сухофрукты",
    greens: "Зелень",
    beverages: "Напитки",
    bread: "Хлебобулочные изделия",
    sets: "Наборы",
    exotic: "Экзотические продукты",
    promotions: "Акции",
  }

  return categories[categorySlug] || "Другое"
}
