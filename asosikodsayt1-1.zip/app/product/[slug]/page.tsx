import { notFound } from "next/navigation"
import { getProductById, getProductBySlug } from "@/lib/product-service"
import type { Metadata, ResolvingMetadata } from "next"
import { ProductInfo } from "./ProductDetailPageClient"
import { generateProductSeoData } from "@/lib/slug-utils"

type Props = {
  params: { slug: string }
  searchParams: { [key: string]: string | string[] | undefined }
}

export async function generateMetadata({ params }: Props, parent: ResolvingMetadata): Promise<Metadata> {
  try {
    // Пытаемся получить товар по slug
    const product = await getProductBySlug(params.slug)

    if (!product) {
      // Если не нашли по slug, пробуем по ID (для обратной совместимости)
      const productById = await getProductById(params.slug)

      if (!productById) {
        return {
          title: "Товар не найден | OLUCHA",
          description: "Товар не найден в нашем каталоге",
        }
      }

      // Используем данные товара, найденного по ID
      const seoData =
        productById.seo_title && productById.seo_description
          ? {
              seoTitle: productById.seo_title,
              seoDescription: productById.seo_description,
            }
          : generateProductSeoData(productById.name, productById.category)

      const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://olucha.ru"
      const productUrl = `${baseUrl}/product/${params.slug}`
      const imageUrl =
        productById.images && productById.images.length > 0
          ? productById.images[0]
          : `${baseUrl}/placeholder.svg?height=600&width=600`

      return {
        title: seoData.seoTitle,
        description: seoData.seoDescription,
        openGraph: {
          title: seoData.seoTitle,
          description: seoData.seoDescription,
          images: [{ url: imageUrl, alt: `${productById.name} - купить в Челябинске с доставкой` }],
          url: productUrl,
          type: "product",
          locale: "ru_RU",
          siteName: "OLUCHA - доставка свежих продуктов в Челябинске",
        },
        twitter: {
          card: "summary_large_image",
          title: seoData.seoTitle,
          description: seoData.seoDescription,
          images: [imageUrl],
        },
        alternates: {
          canonical: productUrl,
        },
        robots: {
          index: true,
          follow: true,
        },
        keywords: `купить ${productById.name}, ${productById.name} Челябинск, доставка ${productById.name}, свежие продукты Челябинск`,
      }
    }

    // Используем данные товара, найденного по slug
    const seoData =
      product.seo_title && product.seo_description
        ? {
            seoTitle: product.seo_title,
            seoDescription: product.seo_description,
          }
        : generateProductSeoData(product.name, product.category)

    const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://olucha.ru"
    const productUrl = `${baseUrl}/product/${params.slug}`
    const imageUrl =
      product.images && product.images.length > 0
        ? product.images[0]
        : `${baseUrl}/placeholder.svg?height=600&width=600`

    return {
      title: seoData.seoTitle,
      description: seoData.seoDescription,
      openGraph: {
        title: seoData.seoTitle,
        description: seoData.seoDescription,
        images: [{ url: imageUrl, alt: `${product.name} - купить в Челябинске с доставкой` }],
        url: productUrl,
        type: "product",
        locale: "ru_RU",
        siteName: "OLUCHA - доставка свежих продуктов в Челябинске",
      },
      twitter: {
        card: "summary_large_image",
        title: seoData.seoTitle,
        description: seoData.seoDescription,
        images: [imageUrl],
      },
      alternates: {
        canonical: productUrl,
      },
      robots: {
        index: true,
        follow: true,
      },
      keywords: `купить ${product.name}, ${product.name} Челябинск, доставка ${product.name}, свежие продукты Челябинск`,
    }
  } catch (error) {
    console.error("Ошибка при генерации метаданных товара:", error)
    return {
      title: "Ошибка загрузки товара | OLUCHA",
      description: "Произошла ошибка при загрузке информации о товаре",
    }
  }
}

export default async function ProductDetailPage({ params }: { params: { slug: string } }) {
  try {
    // Пытаемся получить товар по slug
    let product = await getProductBySlug(params.slug)

    // Если не нашли по slug, пробуем по ID (для обратной совместимости)
    if (!product) {
      product = await getProductById(params.slug)
    }

    if (!product) {
      return notFound()
    }

    return <ProductInfo product={product} />
  } catch (error) {
    console.error("Ошибка при загрузке товара:", error)
    return notFound()
  }
}
