"use client"

import { useEffect, useState } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { supabase } from "@/lib/supabase-client"
import { toast } from "@/components/ui/use-toast"

export default function AdminDashboardPage() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true)

        const { data, error } = await supabase
          .from("orders")
          .select("*, order_items(*)")
          .order("created_at", { ascending: false })

        if (error) throw error

        if (!data || data.length === 0) {
          setOrders([])
          setLoading(false)
          return
        }

        // Transform the data to match the expected format
        const transformedOrders = data.map((order) => ({
          id: order.id,
          order_number: order.id.slice(0, 8).toUpperCase(),
          status: order.status || "new",
          created_at: order.created_at,
          customer_name: order.customer_name,
          customer_phone: order.customer_phone,
          customer_address: order.delivery_address,
          customer_email: order.customer_email,
          entrance: order.entrance,
          floor: order.floor,
          delivery_type: order.delivery_type || "door",
          payment_method: order.payment_method || "cash",
          comment: order.notes,
          items: Array.isArray(order.order_items)
            ? order.order_items.map((item) => ({
                product_name: item.product_name,
                quantity: Number.parseFloat(item.quantity || 0),
                price: Number.parseFloat(item.unit_price || 0),
                unit: item.unit || "кг",
              }))
            : [],
          subtotal: Number.parseFloat(order.total_amount || 0) - Number.parseFloat(order.delivery_fee || 0),
          delivery_fee: Number.parseFloat(order.delivery_fee || 0),
          total: Number.parseFloat(order.total_amount || 0),
        }))

        setOrders(transformedOrders)
      } catch (error) {
        console.error("Error fetching orders:", error)
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить заказы",
          variant: "destructive",
        })
        setOrders([])
      } finally {
        setLoading(false)
      }
    }

    fetchOrders()
  }, [])

  const handleStatusChange = async (orderId, status) => {
    try {
      const { error } = await supabase.from("orders").update({ status }).eq("id", orderId)

      if (error) throw error

      // Update the local state
      setOrders(orders.map((order) => (order.id === orderId ? { ...order, status } : order)))

      toast({
        title: "Статус обновлен",
        description: `Статус заказа изменен на "${getStatusText(status)}"`,
        variant: "success",
      })

      return true
    } catch (error) {
      console.error("Error updating order status:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус заказа",
        variant: "destructive",
      })
      return false
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800"
      case "processing":
        return "bg-yellow-100 text-yellow-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status) => {
    switch (status) {
      case "new":
        return "Новый"
      case "processing":
        return "В обработке"
      case "delivered":
        return "Доставлен"
      case "cancelled":
        return "Отменен"
      default:
        return "Неизвестно"
    }
  }

  const filterOrdersByStatus = (status) => {
    if (status === "all") return orders
    return orders.filter((order) => order.status === status)
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center p-8">
          <p>Загрузка заказов...</p>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Заказы</h1>
          <p className="text-gray-500">Управление заказами клиентов</p>
        </div>

        <Tabs defaultValue="all">
          <TabsList>
            <TabsTrigger value="all">Все</TabsTrigger>
            <TabsTrigger value="new">Новые</TabsTrigger>
            <TabsTrigger value="processing">В обработке</TabsTrigger>
            <TabsTrigger value="delivered">Доставленные</TabsTrigger>
            <TabsTrigger value="cancelled">Отмененные</TabsTrigger>
          </TabsList>

          {["all", "new", "processing", "delivered", "cancelled"].map((status) => (
            <TabsContent key={status} value={status} className="space-y-4">
              {filterOrdersByStatus(status).length === 0 ? (
                <p className="py-4 text-center text-gray-500">Нет заказов с таким статусом</p>
              ) : (
                filterOrdersByStatus(status).map((order) => (
                  <Card key={order.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle>Заказ #{order.order_number || order.id.slice(0, 8)}</CardTitle>
                          <CardDescription>{new Date(order.created_at).toLocaleString("ru-RU")}</CardDescription>
                        </div>
                        <div className={`rounded-full px-3 py-1 text-xs font-medium ${getStatusColor(order.status)}`}>
                          {getStatusText(order.status)}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div>
                          <h3 className="mb-2 font-semibold">Информация о клиенте</h3>
                          <p>
                            <span className="text-gray-500">Имя:</span> {order.customer_name}
                          </p>
                          <p>
                            <span className="text-gray-500">Телефон:</span> {order.customer_phone}
                          </p>
                          <p>
                            <span className="text-gray-500">Адрес:</span> {order.customer_address}
                          </p>
                          {order.entrance && (
                            <p>
                              <span className="text-gray-500">Подъезд:</span> {order.entrance}
                            </p>
                          )}
                          {order.floor && (
                            <p>
                              <span className="text-gray-500">Этаж:</span> {order.floor}
                            </p>
                          )}
                          <p>
                            <span className="text-gray-500">Тип доставки:</span>
                            {order.delivery_type === "door" ? "До двери" : "До подъезда"}
                          </p>
                          <p>
                            <span className="text-gray-500">Способ оплаты:</span>
                            {order.payment_method === "cash" ? "Наличными" : "Онлайн"}
                          </p>
                          {order.comment && (
                            <p>
                              <span className="text-gray-500">Комментарий:</span> {order.comment}
                            </p>
                          )}
                        </div>
                        <div>
                          <h3 className="mb-2 font-semibold">Товары</h3>
                          <ul className="space-y-2">
                            {order.items.map((item, index) => (
                              <li key={index} className="flex justify-between">
                                <span>
                                  {item.product_name} x {item.quantity} {item.unit}
                                </span>
                                <span className="font-medium">{(item.price * item.quantity).toFixed(0)} ₽</span>
                              </li>
                            ))}
                          </ul>
                          <div className="mt-4 space-y-1 border-t pt-2">
                            <div className="flex justify-between">
                              <span className="text-gray-500">Подытог:</span>
                              <span>{order.subtotal.toFixed(0)} ₽</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-500">Доставка:</span>
                              <span>{order.delivery_fee.toFixed(0)} ₽</span>
                            </div>
                            <div className="flex justify-between font-medium">
                              <span>Итого:</span>
                              <span>{order.total.toFixed(0)} ₽</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 flex items-center justify-end gap-2">
                        <Select
                          defaultValue={order.status}
                          onValueChange={(value) => handleStatusChange(order.id, value)}
                        >
                          <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder="Статус заказа" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="new">Новый</SelectItem>
                            <SelectItem value="processing">В обработке</SelectItem>
                            <SelectItem value="delivered">Доставлен</SelectItem>
                            <SelectItem value="cancelled">Отменен</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </AdminLayout>
  )
}
