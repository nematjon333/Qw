"use client"

import { useEffect, useState } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, TrendingUp, Package, Truck, Calendar } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

// Типы для аналитики
interface OrderAnalytics {
  totalOrders: number
  totalRevenue: number
  averageOrderValue: number
  deliveryZoneStats: {
    [zoneId: string]: {
      orders: number
      revenue: number
      averageValue: number
    }
  }
  timeStats: {
    [hour: string]: number
  }
  dayStats: {
    [day: string]: number
  }
  monthStats: {
    [month: string]: number
  }
}

interface DeliveryZone {
  id: string
  name: string
  color: string
  type: string
  coordinates?: [number, number][]
  center?: { lat: number; lng: number }
  radius?: number
  base_fee: number
  min_order_amount: number
  free_delivery_threshold: number | null
  per_km_fee: number
  active: boolean
}

export default function AnalyticsPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [analytics, setAnalytics] = useState<OrderAnalytics | null>(null)
  const [zones, setZones] = useState<DeliveryZone[]>([])
  const [period, setPeriod] = useState("month")

  // Загрузка данных
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        setError(null)

        // Загружаем зоны доставки
        const zonesResponse = await fetch("/api/delivery-zones")

        if (!zonesResponse.ok) {
          throw new Error("Ошибка при загрузке зон доставки")
        }

        const zonesData = await zonesResponse.json()
        setZones(zonesData.zones || [])

        // Загружаем аналитику
        try {
          const analyticsResponse = await fetch(`/api/analytics?period=${period}`)

          if (analyticsResponse.ok) {
            const analyticsData = await analyticsResponse.json()
            setAnalytics(analyticsData)
          } else {
            // Если API возвращает ошибку, используем моковые данные
            throw new Error("API аналитики недоступен")
          }
        } catch (analyticsError) {
          console.warn("Используем моковые данные для аналитики:", analyticsError)

          // Моковые данные для демонстрации
          const mockAnalytics: OrderAnalytics = {
            totalOrders: 156,
            totalRevenue: 187450,
            averageOrderValue: 1201.6,
            deliveryZoneStats: {
              "1": { orders: 78, revenue: 93725, averageValue: 1201.6 },
              "2": { orders: 45, revenue: 56250, averageValue: 1250 },
              "3": { orders: 33, revenue: 37475, averageValue: 1135.6 },
            },
            timeStats: {
              "10": 12,
              "11": 15,
              "12": 18,
              "13": 22,
              "14": 19,
              "15": 17,
              "16": 14,
              "17": 13,
              "18": 16,
              "19": 10,
              "20": 8,
              "21": 2,
            },
            dayStats: {
              Пн: 25,
              Вт: 18,
              Ср: 22,
              Чт: 20,
              Пт: 28,
              Сб: 30,
              Вс: 13,
            },
            monthStats: {
              Янв: 120,
              Фев: 135,
              Мар: 145,
              Апр: 130,
              Май: 150,
              Июн: 165,
              Июл: 180,
              Авг: 170,
              Сен: 155,
              Окт: 140,
              Ноя: 160,
              Дек: 175,
            },
          }
          setAnalytics(mockAnalytics)
        }
      } catch (error) {
        console.error("Ошибка при загрузке данных:", error)
        setError("Не удалось загрузить данные. Пожалуйста, попробуйте позже.")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [period])

  // Функция для форматирования суммы
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("ru-RU", {
      style: "currency",
      currency: "RUB",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  // Получение названия зоны по ID
  const getZoneName = (zoneId: string) => {
    const zone = zones.find((z) => z.id === zoneId)
    return zone ? zone.name : "Неизвестная зона"
  }

  // Получение цвета зоны по ID
  const getZoneColor = (zoneId: string) => {
    const zone = zones.find((z) => z.id === zoneId)
    if (!zone) return "#6b7280"

    switch (zone.color) {
      case "green":
        return "#22c55e"
      case "yellow":
        return "#eab308"
      case "red":
        return "#ef4444"
      default:
        return "#6b7280"
    }
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-green-600 mr-2" />
          <p>Загрузка аналитики...</p>
        </div>
      </AdminLayout>
    )
  }

  if (error) {
    return (
      <AdminLayout>
        <div className="rounded-lg bg-red-50 p-4 text-red-600 dark:bg-red-900/30 dark:text-red-400">
          <p className="font-medium">{error}</p>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Аналитика продаж</h1>
            <p className="text-gray-500 dark:text-gray-400">Статистика заказов и доставок</p>
          </div>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Выберите период" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Неделя</SelectItem>
              <SelectItem value="month">Месяц</SelectItem>
              <SelectItem value="quarter">Квартал</SelectItem>
              <SelectItem value="year">Год</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {analytics && (
          <>
            {/* Общая статистика */}
            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Всего заказов</CardTitle>
                  <Package className="h-4 w-4 text-gray-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics.totalOrders}</div>
                  <p className="text-xs text-gray-500">За выбранный период</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Общая выручка</CardTitle>
                  <TrendingUp className="h-4 w-4 text-gray-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(analytics.totalRevenue)}</div>
                  <p className="text-xs text-gray-500">За выбранный период</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Средний чек</CardTitle>
                  <Truck className="h-4 w-4 text-gray-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(analytics.averageOrderValue)}</div>
                  <p className="text-xs text-gray-500">За выбранный период</p>
                </CardContent>
              </Card>
            </div>

            {/* Вкладки с детальной статистикой */}
            <Tabs defaultValue="zones">
              <TabsList>
                <TabsTrigger value="zones">По зонам доставки</TabsTrigger>
                <TabsTrigger value="time">По времени</TabsTrigger>
                <TabsTrigger value="map">Карта доставок</TabsTrigger>
              </TabsList>

              {/* Статистика по зонам */}
              <TabsContent value="zones" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Статистика по зонам доставки</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-8">
                      {Object.entries(analytics.deliveryZoneStats).map(([zoneId, stats]) => (
                        <div key={zoneId} className="space-y-2">
                          <div className="flex items-center">
                            <div
                              className="h-4 w-4 rounded-full mr-2"
                              style={{ backgroundColor: getZoneColor(zoneId) }}
                            />
                            <h3 className="font-medium">{getZoneName(zoneId)}</h3>
                          </div>
                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <p className="text-sm text-gray-500">Заказов</p>
                              <p className="text-lg font-semibold">{stats.orders}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Выручка</p>
                              <p className="text-lg font-semibold">{formatCurrency(stats.revenue)}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-500">Средний чек</p>
                              <p className="text-lg font-semibold">{formatCurrency(stats.averageValue)}</p>
                            </div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                            <div
                              className="bg-green-600 h-2.5 rounded-full"
                              style={{ width: `${(stats.orders / analytics.totalOrders) * 100}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Статистика по времени */}
              <TabsContent value="time" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Статистика по времени</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium mb-2 flex items-center">
                          <Calendar className="h-4 w-4 mr-2" />
                          По часам
                        </h3>
                        <div className="flex items-end h-40 space-x-2">
                          {Object.entries(analytics.timeStats).map(([hour, count]) => (
                            <div key={hour} className="flex flex-col items-center flex-1">
                              <div
                                className="w-full bg-green-600 rounded-t"
                                style={{
                                  height: `${(count / Math.max(...Object.values(analytics.timeStats))) * 100}%`,
                                  minHeight: "4px",
                                }}
                              />
                              <span className="text-xs mt-1">{hour}:00</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="font-medium mb-2 flex items-center">
                          <Calendar className="h-4 w-4 mr-2" />
                          По дням недели
                        </h3>
                        <div className="flex items-end h-40 space-x-2">
                          {Object.entries(analytics.dayStats).map(([day, count]) => (
                            <div key={day} className="flex flex-col items-center flex-1">
                              <div
                                className="w-full bg-blue-600 rounded-t"
                                style={{
                                  height: `${(count / Math.max(...Object.values(analytics.dayStats))) * 100}%`,
                                  minHeight: "4px",
                                }}
                              />
                              <span className="text-xs mt-1">{day}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Карта доставок */}
              <TabsContent value="map">
                <Card>
                  <CardHeader>
                    <CardTitle>Карта доставок</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {zones.length > 0 ? (
                      <>
                        <div className="h-[400px] bg-gray-100 rounded-md flex items-center justify-center">
                          <p className="text-gray-500">Карта зон доставки</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                          {zones.map((zone) => (
                            <div key={zone.id} className="flex items-center space-x-2">
                              <div
                                className="h-3 w-3 rounded-full"
                                style={{ backgroundColor: getZoneColor(zone.id) }}
                              />
                              <span className="text-sm">{zone.name}</span>
                              <span className="text-xs text-gray-500">
                                {analytics.deliveryZoneStats[zone.id]?.orders || 0} заказов
                              </span>
                            </div>
                          ))}
                        </div>
                      </>
                    ) : (
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          Зоны доставки не настроены. Пожалуйста, добавьте зоны доставки в разделе "Зоны доставки".
                        </AlertDescription>
                      </Alert>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </AdminLayout>
  )
}
