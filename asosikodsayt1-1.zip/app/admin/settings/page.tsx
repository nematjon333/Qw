"use client"

import { useEffect, useState } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getSiteSettings, updateSiteSetting } from "@/lib/auth-service"

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const data = await getSiteSettings()
        setSettings(data)
      } catch (error) {
        console.error("Error fetching settings:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchSettings()
  }, [])

  const handleUpdateSetting = async (id, value) => {
    try {
      const updatedSetting = await updateSiteSetting(id, value)
      if (updatedSetting) {
        setSettings(settings.map((setting) => (setting.id === id ? updatedSetting : setting)))
      }
    } catch (error) {
      console.error("Error updating setting:", error)
    }
  }

  const getSettingsBySection = (section) => {
    return settings.filter((setting) => setting.section === section)
  }

  const getSettingValue = (section, key) => {
    const setting = settings.find((s) => s.section === section && s.key === key)
    return setting ? setting.value : ""
  }

  const getSettingId = (section, key) => {
    const setting = settings.find((s) => s.section === section && s.key === key)
    return setting ? setting.id : ""
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center p-8">
          <p>Загрузка настроек...</p>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Настройки интерфейса</h1>
          <p className="text-gray-500">Управление текстами и настройками сайта</p>
        </div>

        <Tabs defaultValue="home">
          <TabsList>
            <TabsTrigger value="home">Главная страница</TabsTrigger>
            <TabsTrigger value="delivery">Доставка</TabsTrigger>
            <TabsTrigger value="contacts">Контакты</TabsTrigger>
            <TabsTrigger value="seo">SEO</TabsTrigger>
          </TabsList>

          <TabsContent value="home" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Баннер</CardTitle>
                <CardDescription>Настройка текста в главном баннере</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="banner-title">Заголовок</Label>
                  <Input
                    id="banner-title"
                    defaultValue={getSettingValue("home", "banner_title")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("home", "banner_title"), e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="banner-subtitle">Подзаголовок</Label>
                  <Input
                    id="banner-subtitle"
                    defaultValue={getSettingValue("home", "banner_subtitle")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("home", "banner_subtitle"), e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Разделы</CardTitle>
                <CardDescription>Заголовки разделов на главной странице</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="categories-title">Заголовок раздела категорий</Label>
                  <Input
                    id="categories-title"
                    defaultValue={getSettingValue("home", "categories_title")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("home", "categories_title"), e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="featured-title">Заголовок раздела популярных товаров</Label>
                  <Input
                    id="featured-title"
                    defaultValue={getSettingValue("home", "featured_title")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("home", "featured_title"), e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="delivery-title">Заголовок раздела доставки</Label>
                  <Input
                    id="delivery-title"
                    defaultValue={getSettingValue("home", "delivery_title")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("home", "delivery_title"), e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="delivery" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Информация о доставке</CardTitle>
                <CardDescription>Настройка текстов на странице доставки</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="delivery-description">Описание доставки</Label>
                  <Textarea
                    id="delivery-description"
                    defaultValue={getSettingValue("delivery", "description")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("delivery", "description"), e.target.value)}
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="delivery-min-free">Минимальная сумма для бесплатной доставки (₽)</Label>
                  <Input
                    id="delivery-min-free"
                    type="number"
                    defaultValue={getSettingValue("delivery", "min_free_delivery")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("delivery", "min_free_delivery"), e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contacts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Контактная информация</CardTitle>
                <CardDescription>Настройка контактных данных</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="contact-address">Адрес</Label>
                  <Input
                    id="contact-address"
                    defaultValue={getSettingValue("contacts", "address")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("contacts", "address"), e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact-phone">Телефон</Label>
                  <Input
                    id="contact-phone"
                    defaultValue={getSettingValue("contacts", "phone")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("contacts", "phone"), e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact-email">Email</Label>
                  <Input
                    id="contact-email"
                    defaultValue={getSettingValue("contacts", "email")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("contacts", "email"), e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact-hours">Часы работы</Label>
                  <Input
                    id="contact-hours"
                    defaultValue={getSettingValue("contacts", "hours")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("contacts", "hours"), e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="seo" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>SEO настройки</CardTitle>
                <CardDescription>Настройка мета-тегов для поисковой оптимизации</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="seo-title">Заголовок сайта (title)</Label>
                  <Input
                    id="seo-title"
                    defaultValue={getSettingValue("seo", "title")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("seo", "title"), e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seo-description">Описание сайта (description)</Label>
                  <Textarea
                    id="seo-description"
                    defaultValue={getSettingValue("seo", "description")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("seo", "description"), e.target.value)}
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seo-keywords">Ключевые слова (keywords)</Label>
                  <Input
                    id="seo-keywords"
                    defaultValue={getSettingValue("seo", "keywords")}
                    onBlur={(e) => handleUpdateSetting(getSettingId("seo", "keywords"), e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  )
}
