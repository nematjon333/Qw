"use client"

import { useState, useEffect } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Loader2, AlertTriangle, Send } from "lucide-react"
import { ImageUpload } from "@/components/admin/image-upload"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

export default function TestPage() {
  const [orderApiStatus, setOrderApiStatus] = useState<any>(null)
  const [uploadApiStatus, setUploadApiStatus] = useState<any>(null)
  const [emailApiStatus, setEmailApiStatus] = useState<any>(null)
  const [telegramApiStatus, setTelegramApiStatus] = useState<any>(null)
  const [isTestingOrderApi, setIsTestingOrderApi] = useState(false)
  const [isTestingUploadApi, setIsTestingUploadApi] = useState(false)
  const [isTestingEmailApi, setIsTestingEmailApi] = useState(false)
  const [isTestingTelegramApi, setIsTestingTelegramApi] = useState(false)
  const [isSendingTestMessage, setIsSendingTestMessage] = useState(false)
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null)
  const [blobTokenConfigured, setBlobTokenConfigured] = useState(false)
  const [emailConfigured, setEmailConfigured] = useState(false)
  const [telegramConfigured, setTelegramConfigured] = useState(false)
  const [testMessage, setTestMessage] = useState("Это тестовое сообщение от Olucha-Fresh")

  const testOrderApi = async () => {
    setIsTestingOrderApi(true)
    try {
      const response = await fetch("/api/order", {
        method: "GET",
      })

      const data = await response.json()
      setOrderApiStatus(data)
    } catch (error) {
      setOrderApiStatus({
        success: false,
        message: "Ошибка при тестировании API заказов",
        error: error.message,
      })
    } finally {
      setIsTestingOrderApi(false)
    }
  }

  const testUploadApi = async () => {
    setIsTestingUploadApi(true)
    try {
      const response = await fetch("/api/upload", {
        method: "GET",
      })

      const data = await response.json()
      setUploadApiStatus(data)

      // Проверяем, настроен ли BLOB_READ_WRITE_TOKEN
      if (data.status && data.status.includes("BLOB_READ_WRITE_TOKEN найден")) {
        setBlobTokenConfigured(true)
      }
    } catch (error) {
      setUploadApiStatus({
        success: false,
        message: "Ошибка при тестировании API загрузки",
        error: error.message,
      })
    } finally {
      setIsTestingUploadApi(false)
    }
  }

  const testEmailApi = async () => {
    setIsTestingEmailApi(true)
    try {
      const response = await fetch("/api/email", {
        method: "GET",
      })

      const data = await response.json()
      setEmailApiStatus(data)

      // Проверяем, настроены ли EMAIL_* переменные
      if (data.config && data.config.host !== "не настроен" && data.config.user === "настроен") {
        setEmailConfigured(true)
      }
    } catch (error) {
      setEmailApiStatus({
        success: false,
        message: "Ошибка при тестировании API email",
        error: error.message,
      })
    } finally {
      setIsTestingEmailApi(false)
    }
  }

  const testTelegramApi = async () => {
    setIsTestingTelegramApi(true)
    try {
      const response = await fetch("/api/telegram/test", {
        method: "GET",
      })

      const data = await response.json()
      setTelegramApiStatus(data)

      // Проверяем, настроены ли TELEGRAM_* переменные
      if (data.config && data.config.botToken === "настроен" && data.config.adminId !== "не настроен") {
        setTelegramConfigured(true)
      }
    } catch (error) {
      setTelegramApiStatus({
        success: false,
        message: "Ошибка при тестировании API Telegram",
        error: error.message,
      })
    } finally {
      setIsTestingTelegramApi(false)
    }
  }

  const sendTestMessage = async () => {
    if (!testMessage.trim()) {
      toast({
        title: "Ошибка",
        description: "Введите текст сообщения",
        variant: "destructive",
      })
      return
    }

    setIsSendingTestMessage(true)
    try {
      const response = await fetch("/api/telegram/test", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: testMessage }),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Успешно",
          description: "Тестовое сообщение отправлено",
          variant: "success",
        })
      } else {
        toast({
          title: "Ошибка",
          description: data.message || "Не удалось отправить тестовое сообщение",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось отправить тестовое сообщение",
        variant: "destructive",
      })
    } finally {
      setIsSendingTestMessage(false)
    }
  }

  const handleImageUpload = (imageUrl: string) => {
    setUploadedImageUrl(imageUrl)
  }

  useEffect(() => {
    testOrderApi()
    testUploadApi()
    testEmailApi()
    testTelegramApi()
  }, [])

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Диагностика системы</h1>
          <p className="text-gray-500">Проверка работоспособности основных компонентов</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Тест API заказов */}
          <Card>
            <CardHeader>
              <CardTitle>Проверка API заказов</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isTestingOrderApi ? (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-8 w-8 animate-spin text-green-600" />
                </div>
              ) : orderApiStatus ? (
                <div>
                  <div className={`p-4 rounded-md ${orderApiStatus.success ? "bg-green-50" : "bg-red-50"}`}>
                    <p className={`font-medium ${orderApiStatus.success ? "text-green-600" : "text-red-600"}`}>
                      {orderApiStatus.success ? "API заказов работает" : "Проблема с API заказов"}
                    </p>
                    <p className="text-sm mt-1">{orderApiStatus.message}</p>
                    {orderApiStatus.error && (
                      <p className="text-sm text-red-600 mt-1">Ошибка: {orderApiStatus.error}</p>
                    )}
                  </div>

                  {orderApiStatus.note && (
                    <div className="mt-4 p-4 bg-yellow-50 rounded-md">
                      <p className="text-sm text-yellow-800">{orderApiStatus.note}</p>
                    </div>
                  )}
                </div>
              ) : (
                <p>Нет данных о состоянии API заказов</p>
              )}

              <Button onClick={testOrderApi} disabled={isTestingOrderApi}>
                {isTestingOrderApi ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Проверка...
                  </span>
                ) : (
                  "Проверить API заказов"
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Тест API загрузки */}
          <Card>
            <CardHeader>
              <CardTitle>Проверка API загрузки изображений</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isTestingUploadApi ? (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-8 w-8 animate-spin text-green-600" />
                </div>
              ) : uploadApiStatus ? (
                <div>
                  <div className={`p-4 rounded-md ${uploadApiStatus.success ? "bg-green-50" : "bg-red-50"}`}>
                    <p className={`font-medium ${uploadApiStatus.success ? "text-green-600" : "text-red-600"}`}>
                      {uploadApiStatus.success ? "API загрузки работает" : "Проблема с API загрузки"}
                    </p>
                    <p className="text-sm mt-1">{uploadApiStatus.message}</p>
                    {uploadApiStatus.status && <p className="text-sm mt-1">Статус: {uploadApiStatus.status}</p>}
                    {uploadApiStatus.error && (
                      <p className="text-sm text-red-600 mt-1">Ошибка: {uploadApiStatus.error}</p>
                    )}
                  </div>

                  {uploadApiStatus.note && (
                    <div className="mt-4 p-4 bg-yellow-50 rounded-md">
                      <p className="text-sm text-yellow-800">{uploadApiStatus.note}</p>
                    </div>
                  )}
                </div>
              ) : (
                <p>Нет данных о состоянии API загрузки</p>
              )}

              <Button onClick={testUploadApi} disabled={isTestingUploadApi}>
                {isTestingUploadApi ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Проверка...
                  </span>
                ) : (
                  "Проверить API загрузки"
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Тест API Email */}
        <Card>
          <CardHeader>
            <CardTitle>Проверка API Email</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isTestingEmailApi ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-8 w-8 animate-spin text-green-600" />
              </div>
            ) : emailApiStatus ? (
              <div>
                <div className={`p-4 rounded-md ${emailApiStatus.success ? "bg-green-50" : "bg-red-50"}`}>
                  <p className={`font-medium ${emailApiStatus.success ? "text-green-600" : "text-red-600"}`}>
                    {emailApiStatus.success ? "API Email настроен" : "Проблема с API Email"}
                  </p>
                  <p className="text-sm mt-1">{emailApiStatus.message}</p>
                  {emailApiStatus.error && <p className="text-sm text-red-600 mt-1">Ошибка: {emailApiStatus.error}</p>}
                </div>

                {emailApiStatus.note && (
                  <div className="mt-4 p-4 bg-yellow-50 rounded-md">
                    <p className="text-sm text-yellow-800">{emailApiStatus.note}</p>
                  </div>
                )}

                {emailApiStatus.config && (
                  <div className="mt-4">
                    <Separator className="my-4" />
                    <h3 className="font-medium mb-2">Конфигурация Email:</h3>
                    <ul className="text-sm space-y-1">
                      <li>
                        <strong>Хост:</strong> {emailApiStatus.config.host || "не настроен"}
                      </li>
                      <li>
                        <strong>Порт:</strong> {emailApiStatus.config.port || "не настроен"}
                      </li>
                      <li>
                        <strong>Защищенное соединение:</strong> {emailApiStatus.config.secure ? "Да" : "Нет"}
                      </li>
                      <li>
                        <strong>Пользователь:</strong> {emailApiStatus.config.user}
                      </li>
                      <li>
                        <strong>Пароль:</strong> {emailApiStatus.config.password}
                      </li>
                      <li>
                        <strong>Email администратора:</strong> {emailApiStatus.config.adminEmail || "не настроен"}
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <p>Нет данных о состоянии API Email</p>
            )}

            <Button onClick={testEmailApi} disabled={isTestingEmailApi}>
              {isTestingEmailApi ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Проверка...
                </span>
              ) : (
                "Проверить API Email"
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Тест API Telegram */}
        <Card>
          <CardHeader>
            <CardTitle>Проверка API Telegram</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isTestingTelegramApi ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-8 w-8 animate-spin text-green-600" />
              </div>
            ) : telegramApiStatus ? (
              <div>
                <div className={`p-4 rounded-md ${telegramApiStatus.success ? "bg-green-50" : "bg-red-50"}`}>
                  <p className={`font-medium ${telegramApiStatus.success ? "text-green-600" : "text-red-600"}`}>
                    {telegramApiStatus.success ? "API Telegram настроен" : "Проблема с API Telegram"}
                  </p>
                  <p className="text-sm mt-1">{telegramApiStatus.message}</p>
                  {telegramApiStatus.error && (
                    <p className="text-sm text-red-600 mt-1">Ошибка: {telegramApiStatus.error}</p>
                  )}
                </div>

                {telegramApiStatus.botInfo && (
                  <div className="mt-4 p-4 bg-green-50 rounded-md">
                    <h3 className="font-medium mb-2">Информация о боте:</h3>
                    <ul className="text-sm space-y-1">
                      <li>
                        <strong>Имя:</strong> {telegramApiStatus.botInfo.first_name}
                      </li>
                      <li>
                        <strong>Имя пользователя:</strong> @{telegramApiStatus.botInfo.username}
                      </li>
                      <li>
                        <strong>ID:</strong> {telegramApiStatus.botInfo.id}
                      </li>
                    </ul>
                  </div>
                )}

                {telegramApiStatus.config && (
                  <div className="mt-4">
                    <Separator className="my-4" />
                    <h3 className="font-medium mb-2">Конфигурация Telegram:</h3>
                    <ul className="text-sm space-y-1">
                      <li>
                        <strong>Токен бота:</strong> {telegramApiStatus.config.botToken}
                      </li>
                      <li>
                        <strong>ID администратора:</strong> {telegramApiStatus.config.adminId}
                      </li>
                      <li>
                        <strong>Имя пользователя бота:</strong> {telegramApiStatus.config.botUsername}
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <p>Нет данных о состоянии API Telegram</p>
            )}

            <Button onClick={testTelegramApi} disabled={isTestingTelegramApi}>
              {isTestingTelegramApi ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Проверка...
                </span>
              ) : (
                "Проверить API Telegram"
              )}
            </Button>

            <Separator className="my-4" />

            <div className="space-y-4">
              <h3 className="font-medium">Отправить тестовое сообщение</h3>
              <Textarea
                value={testMessage}
                onChange={(e) => setTestMessage(e.target.value)}
                placeholder="Введите текст сообщения"
                rows={3}
              />
              <Button
                onClick={sendTestMessage}
                disabled={isSendingTestMessage || !telegramConfigured}
                className="flex items-center gap-2"
              >
                {isSendingTestMessage ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Отправка...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    Отправить тестовое сообщение
                  </>
                )}
              </Button>
              {!telegramConfigured && (
                <p className="text-sm text-yellow-600">
                  Для отправки тестового сообщения необходимо настроить Telegram API
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Тест загрузки изображений */}
        <Card>
          <CardHeader>
            <CardTitle>Тест загрузки изображений</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium mb-4">Загрузите тестовое изображение:</h3>
                <ImageUpload onImageUpload={handleImageUpload} />
              </div>

              <div>
                <h3 className="font-medium mb-4">Результат загрузки:</h3>
                {uploadedImageUrl ? (
                  <div className="space-y-4">
                    <div className="rounded-md overflow-hidden border">
                      <img
                        src={uploadedImageUrl || "/placeholder.svg"}
                        alt="Загруженное изображение"
                        className="w-full h-48 object-cover"
                        onError={(e) => {
                          console.error("Ошибка загрузки изображения:", uploadedImageUrl)
                          e.currentTarget.src = "/placeholder.svg?height=400&width=400"
                        }}
                      />
                    </div>
                    <div className="p-4 bg-gray-50 rounded-md">
                      <p className="text-sm break-all">{uploadedImageUrl}</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-48 border rounded-md bg-gray-50">
                    <p className="text-gray-500">Изображение не загружено</p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Информация о режиме работы */}
        {(!blobTokenConfigured || !emailConfigured || !telegramConfigured) && (
          <div className="p-4 bg-blue-50 rounded-md">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-medium text-blue-800">Информация о режиме работы</h3>
                <p className="text-sm text-blue-700 mt-1">
                  {!blobTokenConfigured && !emailConfigured && !telegramConfigured
                    ? "Приложение работает в резервном режиме без настроенных переменных окружения."
                    : "Некоторые функции приложения работают в резервном режиме."}{" "}
                  Для полноценной работы необходимо настроить:
                </p>
                <ul className="text-sm text-blue-700 mt-2 list-disc list-inside">
                  {!blobTokenConfigured && (
                    <li>
                      <strong>BLOB_READ_WRITE_TOKEN</strong> - для загрузки файлов через Vercel Blob
                    </li>
                  )}
                  {!emailConfigured && (
                    <li>
                      <strong>EMAIL_*</strong> - для отправки email-уведомлений
                    </li>
                  )}
                  {!telegramConfigured && (
                    <li>
                      <strong>TELEGRAM_*</strong> - для отправки уведомлений через Telegram
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  )
}
