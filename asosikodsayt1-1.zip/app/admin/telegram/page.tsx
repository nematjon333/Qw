import { TelegramCheck } from "@/components/admin/telegram-check"

export default function TelegramCheckPage() {
  return (
    <div className="container mx-auto py-6 space-y-6">
      <h1 className="text-2xl font-bold">Настройка Telegram уведомлений</h1>
      <p className="text-gray-600">
        На этой странице вы можете проверить настройки и работу Telegram бота для уведомлений о заказах.
      </p>

      <TelegramCheck />

      <div className="mt-8 p-4 bg-gray-50 rounded-lg border">
        <h2 className="text-lg font-medium mb-2">Как получить ID администратора?</h2>
        <ol className="list-decimal pl-5 space-y-2">
          <li>Откройте Telegram и найдите бота @userinfobot</li>
          <li>Отправьте боту любое сообщение</li>
          <li>
            Бот ответит вам вашим ID, который нужно скопировать и добавить в переменную окружения TELEGRAM_ADMIN_ID
          </li>
        </ol>
      </div>
    </div>
  )
}
