"use client"

import { Separator } from "@/components/ui/separator"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Plus, Loader2, Wand2, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { ImageUpload } from "@/components/admin/image-upload"
import { toast } from "@/components/ui/use-toast"
import { QuantitySelector } from "@/components/quantity-selector"
import { countHomepageProducts } from "@/lib/product-service"
import { generateSlug, ensureUniqueSlug } from "@/lib/slug-utils"

export default function NewProductPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [images, setImages] = useState<string[]>([])
  const [homepageProductsCount, setHomepageProductsCount] = useState(0)
  const [product, setProduct] = useState({
    name: "",
    price: "",
    description: "",
    category: "fruits",
    unit: "кг",
    discount: "",
    origin: "Россия",
    weight: "",
    volume: "",
    minQuantity: 1,
    maxQuantity: 10,
    step: 1,
    stockQuantity: 100,
    seo_title: "",
    seo_description: "",
    active: true,
    on_homepage: false,
    slug: "",
  })
  const [formErrors, setFormErrors] = useState({
    name: false,
    price: false,
    images: false,
  })
  const [debugInfo, setDebugInfo] = useState<string | null>(null)
  const [videoUrl, setVideoUrl] = useState<string>("")

  // Загружаем количество товаров на главной странице
  useEffect(() => {
    async function loadHomepageProductsCount() {
      try {
        const count = await countHomepageProducts()
        setHomepageProductsCount(count)
      } catch (error) {
        console.error("Ошибка при подсчете товаров на главной:", error)
      }
    }

    loadHomepageProductsCount()
  }, [])

  const handleChange = (e) => {
    const { name, value, type } = e.target

    // Для числовых полей разрешаем пустую строку и проверяем валидность
    if (type === "number") {
      // Разрешаем пустую строку или валидное число
      if (value === "" || !isNaN(Number.parseFloat(value))) {
        setProduct((prev) => ({
          ...prev,
          [name]: value,
        }))

        // Сбрасываем ошибку для поля при изменении
        if (name === "price" && formErrors.price) {
          setFormErrors((prev) => ({ ...prev, price: false }))
        }
      }
    } else {
      setProduct((prev) => ({
        ...prev,
        [name]: value,
      }))

      // Сбрасываем ошибку для поля при изменении
      if (name === "name" && formErrors.name) {
        setFormErrors((prev) => ({ ...prev, name: false }))
      }

      // Автоматически генерируем slug при изменении названия
      if (name === "name" && value) {
        const newSlug = generateSlug(value)
        setProduct((prev) => ({
          ...prev,
          slug: newSlug,
        }))
      }
    }
  }

  const handleSwitchChange = (name, checked) => {
    if (name === "on_homepage" && checked && homepageProductsCount >= 7) {
      toast({
        title: "Ограничение",
        description: "На главной странице уже отображается максимальное количество товаров (7)",
        variant: "destructive",
      })
      return
    }

    setProduct((prev) => ({
      ...prev,
      [name]: checked,
    }))
  }

  const handleAddImage = () => {
    if (images.length >= 5) {
      toast({
        title: "Ограничение",
        description: "Максимальное количество изображений - 5",
        variant: "destructive",
      })
      return
    }

    setImages((prev) => [...prev, ""])

    // Сбрасываем ошибку для изображений при добавлении
    if (formErrors.images) {
      setFormErrors((prev) => ({ ...prev, images: false }))
    }
  }

  const handleRemoveImage = (index) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  const handleImageUpload = (index, imageUrl) => {
    const newImages = [...images]
    newImages[index] = imageUrl
    setImages(newImages)

    // Сбрасываем ошибку для изображений при загрузке
    if (formErrors.images) {
      setFormErrors((prev) => ({ ...prev, images: false }))
    }
  }

  const handleQuantityChange = (field, value) => {
    setProduct((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const validateForm = () => {
    const errors = {
      name: !product.name.trim(),
      price: product.price === "",
      images: images.length === 0,
    }

    setFormErrors(errors)

    return !Object.values(errors).some(Boolean)
  }

  const handleGenerateDescription = async () => {
    if (!product.name || !product.category) {
      toast({
        title: "Ошибка",
        description: "Для генерации описания необходимо указать название и категорию товара",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      const response = await fetch("/api/generate-description", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: product.name,
          category: product.category,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Ошибка при генерации описания")
      }

      if (data.success) {
        setProduct((prev) => ({
          ...prev,
          description: data.description,
          seo_title: data.seoTitle,
          seo_description: data.seoDescription,
        }))

        toast({
          title: "Описание сгенерировано",
          description: "Описание и SEO-теги успешно сгенерированы",
          variant: "success",
        })

        // Также генерируем slug, если его еще нет
        if (!product.slug) {
          const newSlug = generateSlug(product.name)
          setProduct((prev) => ({
            ...prev,
            slug: newSlug,
          }))
        }
      } else {
        throw new Error(data.message || "Ошибка при генерации описания")
      }
    } catch (error) {
      console.error("Ошибка при генерации описания:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось сгенерировать описание",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setDebugInfo(null)

    if (!validateForm()) {
      // Показываем сообщение об ошибке
      let errorMessage = "Пожалуйста, исправьте следующие ошибки:"
      if (formErrors.name) errorMessage += "\n- Введите название товара"
      if (formErrors.price) errorMessage += "\n- Введите цену товара"
      if (formErrors.images) errorMessage += "\n- Добавьте хотя бы одно изображение"

      toast({
        title: "Ошибка валидации",
        description: errorMessage,
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Генерируем slug, если его еще нет
      let slug = product.slug
      if (!slug) {
        slug = generateSlug(product.name)
        slug = await ensureUniqueSlug(slug)
      }

      // Подготовка данных для отправки
      const productData = {
        ...product,
        price: product.price === "" ? 0 : Number.parseFloat(product.price),
        discount: product.discount === "" ? 0 : Number.parseFloat(product.discount),
        weight: product.weight === "" ? null : Number.parseFloat(product.weight),
        volume: product.volume === "" ? null : Number.parseFloat(product.volume),
        min_quantity: Number.parseFloat(product.minQuantity.toString()),
        max_quantity: Number.parseFloat(product.maxQuantity.toString()),
        step: Number.parseFloat(product.step.toString()),
        stock_quantity: Number.parseInt(product.stockQuantity.toString()),
        images,
        video_url: videoUrl || null,
        slug,
      }

      // Для отладки
      setDebugInfo(JSON.stringify(productData, null, 2))

      // Отправка данных на сервер
      const response = await fetch("/api/products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(productData),
      })

      const data = await response.json()

      if (!response.ok && !data.success) {
        throw new Error(data.message || "Ошибка при создании товара")
      }

      toast({
        title: "Товар создан",
        description: `Товар "${product.name}" успешно создан`,
        variant: "success",
      })

      // Перенаправление на страницу товаров
      router.push("/admin/products")
    } catch (error) {
      console.error("Ошибка при сохранении товара:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать товар",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/products">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад к списку
              </Link>
            </Button>
            <h1 className="text-3xl font-bold">Новый товар</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => router.push("/admin/products")} disabled={isSubmitting}>
              Отмена
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Сохранение...
                </span>
              ) : (
                "Сохранить товар"
              )}
            </Button>
          </div>
        </div>

        {debugInfo && (
          <Card className="bg-gray-100">
            <CardHeader>
              <CardTitle>Отладочная информация</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="whitespace-pre-wrap text-xs">{debugInfo}</pre>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Основная информация</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className={formErrors.name ? "text-red-500" : ""}>
                    Название товара <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    value={product.name}
                    onChange={handleChange}
                    placeholder="Например: Яблоки Голден"
                    className={formErrors.name ? "border-red-500" : ""}
                    required
                  />
                  {formErrors.name && <p className="text-xs text-red-500">Пожалуйста, введите название товара</p>}
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="price" className={formErrors.price ? "text-red-500" : ""}>
                      Цена (₽) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="price"
                      name="price"
                      type="number"
                      value={product.price}
                      onChange={handleChange}
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      className={formErrors.price ? "border-red-500" : ""}
                      required
                    />
                    {formErrors.price && <p className="text-xs text-red-500">Пожалуйста, введите цену товара</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount">Скидка (%)</Label>
                    <Input
                      id="discount"
                      name="discount"
                      type="number"
                      value={product.discount}
                      onChange={handleChange}
                      min="0"
                      max="100"
                      step="0.1"
                      placeholder="0"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="description">Описание</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleGenerateDescription}
                      disabled={isGenerating}
                      className="flex items-center gap-1"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="h-3 w-3 animate-spin" />
                          Генерация...
                        </>
                      ) : (
                        <>
                          <Wand2 className="h-3 w-3" />
                          Сгенерировать
                        </>
                      )}
                    </Button>
                  </div>
                  <Textarea
                    id="description"
                    name="description"
                    value={product.description}
                    onChange={handleChange}
                    rows={4}
                    placeholder="Подробное описание товара"
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="category">Категория</Label>
                    <Select
                      value={product.category}
                      onValueChange={(value) => setProduct((prev) => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите категорию" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fruits">Фрукты</SelectItem>
                        <SelectItem value="vegetables">Овощи</SelectItem>
                        <SelectItem value="berries">Ягоды</SelectItem>
                        <SelectItem value="dried-fruits">Сухофрукты и орехи</SelectItem>
                        <SelectItem value="greens">Зелень и травы</SelectItem>
                        <SelectItem value="beverages">Свежевыжатые соки и напитки</SelectItem>
                        <SelectItem value="bread">Лепёшки и хлеб</SelectItem>
                        <SelectItem value="sets">Готовые наборы</SelectItem>
                        <SelectItem value="exotic">Экзотические продукты</SelectItem>
                        <SelectItem value="promotions">Акции и новинки</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">Единица измерения</Label>
                    <Select
                      value={product.unit}
                      onValueChange={(value) => setProduct((prev) => ({ ...prev, unit: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите единицу" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="кг">кг</SelectItem>
                        <SelectItem value="г">г</SelectItem>
                        <SelectItem value="л">л</SelectItem>
                        <SelectItem value="мл">мл</SelectItem>
                        <SelectItem value="шт">шт</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="stockQuantity">Количество в наличии ({product.unit})</Label>
                  <Input
                    id="stockQuantity"
                    name="stockQuantity"
                    type="number"
                    value={product.stockQuantity}
                    onChange={handleChange}
                    min="0"
                    step="1"
                    placeholder="100"
                  />
                  <p className="text-xs text-gray-500">
                    Если количество равно 0, товар будет помечен как "Нет в наличии"
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Настройки количества</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="minQuantity">Минимальное количество</Label>
                    <Input
                      id="minQuantity"
                      name="minQuantity"
                      type="number"
                      value={product.minQuantity}
                      onChange={handleChange}
                      min="0.1"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxQuantity">Максимальное количество</Label>
                    <Input
                      id="maxQuantity"
                      name="maxQuantity"
                      type="number"
                      value={product.maxQuantity}
                      onChange={handleChange}
                      min="0.1"
                      step="0.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="step">Шаг изменения</Label>
                    <Input
                      id="step"
                      name="step"
                      type="number"
                      value={product.step}
                      onChange={handleChange}
                      min="0.1"
                      step="0.1"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Предпросмотр селектора количества</Label>
                  <div className="p-4 border rounded-md">
                    <QuantitySelector
                      initialValue={Number.parseFloat(product.minQuantity.toString())}
                      min={Number.parseFloat(product.minQuantity.toString())}
                      max={Number.parseFloat(product.maxQuantity.toString())}
                      step={Number.parseFloat(product.step.toString())}
                      unit={product.unit}
                      onChange={(value) => console.log("Выбрано:", value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Дополнительная информация</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="origin">Происхождение</Label>
                  <Input
                    id="origin"
                    name="origin"
                    value={product.origin}
                    onChange={handleChange}
                    placeholder="Например: Краснодарский край"
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="weight">Вес ({product.unit})</Label>
                    <Input
                      id="weight"
                      name="weight"
                      type="number"
                      value={product.weight}
                      onChange={handleChange}
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="volume">Объем ({product.unit})</Label>
                    <Input
                      id="volume"
                      name="volume"
                      type="number"
                      value={product.volume}
                      onChange={handleChange}
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>SEO</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="slug">URL товара (slug)</Label>
                  <div className="flex">
                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                      /product/
                    </span>
                    <Input
                      id="slug"
                      name="slug"
                      value={product.slug}
                      onChange={handleChange}
                      placeholder="автоматически из названия"
                      className="rounded-l-none"
                    />
                  </div>
                  <p className="text-xs text-gray-500">
                    SEO-оптимизированный URL. Если оставить пустым, будет сгенерирован автоматически из названия товара.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seo_title">SEO заголовок</Label>
                  <Input
                    id="seo_title"
                    name="seo_title"
                    value={product.seo_title}
                    onChange={handleChange}
                    placeholder="Оставьте пустым, чтобы использовать название товара"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seo_description">SEO описание</Label>
                  <Textarea
                    id="seo_description"
                    name="seo_description"
                    value={product.seo_description}
                    onChange={handleChange}
                    rows={3}
                    placeholder="Оставьте пустым, чтобы использовать описание товара"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Видео товара</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="video_url">URL видео</Label>
                  <Input
                    id="video_url"
                    name="video_url"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    placeholder="Введите URL видео (до 10 секунд)"
                  />
                  <p className="text-xs text-gray-500">
                    Поддерживаются ссылки на видео в формате MP4. Рекомендуемая длительность - до 10 секунд.
                  </p>
                </div>

                {videoUrl && (
                  <div className="mt-4">
                    <Label>Предпросмотр видео</Label>
                    <div className="mt-2 rounded-md overflow-hidden">
                      <video
                        src={videoUrl}
                        controls
                        className="w-full max-h-[300px]"
                        onError={() => {
                          toast({
                            title: "Ошибка",
                            description: "Не удалось загрузить видео. Проверьте URL.",
                            variant: "destructive",
                          })
                        }}
                      >
                        Ваш браузер не поддерживает видео.
                      </video>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Настройки отображения</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={product.active}
                    onCheckedChange={(checked) => handleSwitchChange("active", checked)}
                  />
                  <Label htmlFor="active">Активен</Label>
                </div>
                <p className="text-sm text-gray-500">Неактивные товары не отображаются на сайте</p>

                <Separator className="my-2" />

                <div className="flex items-center space-x-2">
                  <Switch
                    id="on_homepage"
                    checked={product.on_homepage}
                    onCheckedChange={(checked) => handleSwitchChange("on_homepage", checked)}
                    disabled={homepageProductsCount >= 7 && !product.on_homepage}
                  />
                  <Label htmlFor="on_homepage">В главном экране</Label>
                </div>
                <div className="text-sm text-gray-500">
                  <p>Товар будет отображаться на главной странице</p>
                  <p className="mt-1">Текущее количество: {homepageProductsCount}/7</p>
                  {homepageProductsCount >= 7 && !product.on_homepage && (
                    <div className="mt-2 flex items-start gap-2 text-amber-600">
                      <AlertTriangle className="h-4 w-4 mt-0.5" />
                      <p>Достигнут лимит товаров на главной странице (7)</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Изображения (до 5)</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleAddImage}
                  className="h-8 gap-1"
                  disabled={images.length >= 5}
                >
                  <Plus className="h-4 w-4" />
                  Добавить
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {images.length === 0 ? (
                    <div className={formErrors.images ? "border-red-500 rounded-md" : ""}>
                      <ImageUpload onImageUpload={(url) => setImages([url])} />
                      {formErrors.images && (
                        <p className="text-xs text-red-500 mt-1">Пожалуйста, добавьте хотя бы одно изображение</p>
                      )}
                    </div>
                  ) : (
                    images.map((image, index) => (
                      <div key={index} className="relative rounded-md border p-4">
                        <ImageUpload
                          currentImage={image}
                          onImageUpload={(url) => handleImageUpload(index, url)}
                          onRemove={() => handleRemoveImage(index)}
                        />
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
              <CardFooter className="text-sm text-gray-500">
                Рекомендуемый размер изображения: 800x800 пикселей
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
