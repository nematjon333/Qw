"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Plus, Pencil } from "lucide-react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Product } from "@/lib/blob-storage"

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        // Принудительно запрашиваем свежие данные с сервера
        const response = await fetch("/api/products?t=" + new Date().getTime())
        const data = await response.json()

        if (data.success && Array.isArray(data.products)) {
          setProducts(data.products)
          setFilteredProducts(data.products)
        } else {
          console.error("Неверный формат данных:", data)
          setProducts([])
          setFilteredProducts([])
        }
      } catch (error) {
        console.error("Ошибка при получении продуктов:", error)
        setProducts([])
        setFilteredProducts([])
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  useEffect(() => {
    let filtered = [...products]

    // Фильтрация по поисковому запросу
    if (searchQuery) {
      filtered = filtered.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Фильтрация по категории
    if (categoryFilter !== "all") {
      filtered = filtered.filter((product) => product.category === categoryFilter)
    }

    setFilteredProducts(filtered)
  }, [searchQuery, categoryFilter, products])

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center p-8">
          <p>Загрузка товаров...</p>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <h1 className="text-3xl font-bold">Товары</h1>
            <p className="text-gray-500">Управление товарами в каталоге</p>
          </div>
          <Button asChild className="bg-green-600 hover:bg-green-700">
            <Link href="/admin/products/new">
              <Plus className="mr-2 h-4 w-4" />
              Добавить товар
            </Link>
          </Button>
        </div>

        <div className="flex flex-col gap-4 sm:flex-row">
          <Input
            placeholder="Поиск товаров..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="sm:max-w-xs"
          />
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="sm:w-[180px]">
              <SelectValue placeholder="Категория" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all" />
            </SelectContent>
            <SelectContent>
              <SelectItem value="all">Все категории</SelectItem>
              <SelectItem value="fruits">Фрукты</SelectItem>
              <SelectItem value="vegetables">Овощи</SelectItem>
              <SelectItem value="dried-fruits">Сухофрукты</SelectItem>
              <SelectItem value="beverages">Напитки</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredProducts.length === 0 ? (
            <p className="col-span-full py-4 text-center text-gray-500">Товары не найдены</p>
          ) : (
            filteredProducts.map((product) => (
              <Card key={product.id} className="overflow-hidden">
                <div className="aspect-square overflow-hidden">
                  <img
                    src={product.images?.[0] || "/placeholder.svg"}
                    alt={product.name}
                    className="h-full w-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = "/placeholder.svg?height=400&width=400"
                    }}
                  />
                </div>
                <CardHeader className="p-4 pb-0">
                  <CardTitle className="line-clamp-2 text-base">{product.name}</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        {product.price.toFixed(0)} ₽/{product.unit}
                      </p>
                      <p className="text-sm text-gray-500">
                        {product.category === "fruits" && "Фрукты"}
                        {product.category === "vegetables" && "Овощи"}
                        {product.category === "dried-fruits" && "Сухофрукты"}
                        {product.category === "beverages" && "Напитки"}
                      </p>
                    </div>
                    {product.discount && (
                      <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-600">
                        -{product.discount}%
                      </span>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end gap-2 p-4 pt-0">
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/admin/products/${product.id}`}>
                      <Pencil className="mr-2 h-4 w-4" />
                      Изменить
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))
          )}
        </div>
      </div>
    </AdminLayout>
  )
}
