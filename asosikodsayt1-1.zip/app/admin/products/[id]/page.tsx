"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Plus, AlertTriangle, Trash2, Wand2, Loader2 } from "lucide-react"
import Link from "next/link"
import { ImageUpload } from "@/components/admin/image-upload"
import { toast } from "@/components/ui/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { countHomepageProducts } from "@/lib/product-service"
import { generateProductSeoData, generateSlug, ensureUniqueSlug } from "@/lib/slug-utils"

export default function EditProductPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isSeoGenerating, setIsSeoGenerating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [homepageProductsCount, setHomepageProductsCount] = useState(0)
  const [product, setProduct] = useState({
    id: "",
    name: "",
    price: "",
    description: "",
    category: "fruits",
    unit: "кг",
    discount: "",
    origin: "Россия",
    weight: "",
    volume: "",
    images: [] as string[],
    active: true,
    on_homepage: false,
    seo_title: "",
    seo_description: "",
    min_quantity: "",
    max_quantity: "",
    step: "",
    stock_quantity: "",
    slug: "",
  })

  // Загрузка данных товара и количества товаров на главной странице
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      try {
        // Загружаем количество товаров на главной странице
        const count = await countHomepageProducts()
        setHomepageProductsCount(count)

        // Если это новый товар, не нужно загружать данные с сервера
        if (params.id === "new") {
          setProduct({
            id: "",
            name: "",
            price: "",
            description: "",
            category: "fruits",
            unit: "кг",
            discount: "",
            origin: "Россия",
            weight: "",
            volume: "",
            images: [],
            active: true,
            on_homepage: false,
            seo_title: "",
            seo_description: "",
            min_quantity: "1",
            max_quantity: "10",
            step: "1",
            stock_quantity: "100",
            slug: "",
          })
          setIsLoading(false)
          return
        }

        // Загружаем данные товара
        console.log(`Загрузка товара с ID: ${params.id}`)
        const response = await fetch(`/api/products/${params.id}`)

        if (!response.ok) {
          throw new Error(`Ошибка HTTP: ${response.status}`)
        }

        const data = await response.json()
        console.log("Полученные данные товара:", data)

        if (data.success && data.product) {
          // Преобразуем числовые значения в строки для полей формы
          setProduct({
            id: data.product.id,
            name: data.product.name,
            price: data.product.price?.toString() || "",
            description: data.product.description || "",
            category: data.product.category || "fruits",
            unit: data.product.unit || "кг",
            discount: data.product.discount?.toString() || "",
            origin: data.product.origin || "Россия",
            weight: data.product.weight?.toString() || "",
            volume: data.product.volume?.toString() || "",
            images: data.product.images || [],
            active: data.product.active !== false,
            on_homepage: data.product.on_homepage === true,
            seo_title: data.product.seo_title || "",
            seo_description: data.product.seo_description || "",
            min_quantity: data.product.min_quantity?.toString() || "1",
            max_quantity: data.product.max_quantity?.toString() || "10",
            step: data.product.step?.toString() || "1",
            stock_quantity: data.product.stock_quantity?.toString() || "100",
            slug: data.product.slug || "",
          })
          setError(null)
        } else {
          setError(data.message || "Товар не найден")
        }
      } catch (err: any) {
        console.error("Ошибка при загрузке товара:", err)
        setError(`Ошибка при загрузке товара: ${err.message}`)
      } finally {
        setIsLoading(false)
      }
    }

    if (params.id) {
      fetchData()
    }
  }, [params.id])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement

    // Для числовых полей разрешаем пустую строку и проверяем валидность
    if (type === "number") {
      // Разрешаем пустую строку или валидное число
      if (value === "" || !isNaN(Number.parseFloat(value))) {
        setProduct((prev) => ({
          ...prev,
          [name]: value,
        }))
      }
    } else {
      setProduct((prev) => ({
        ...prev,
        [name]: value,
      }))
    }
  }

  const handleSwitchChange = (name, checked) => {
    if (name === "on_homepage" && checked && homepageProductsCount >= 7 && !product.on_homepage) {
      toast({
        title: "Ограничение",
        description: "На главной странице уже отображается максимальное количество товаров (7)",
        variant: "destructive",
      })
      return
    }

    setProduct((prev) => ({
      ...prev,
      [name]: checked,
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setProduct((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleAddImage = () => {
    if (product.images.length >= 5) {
      toast({
        title: "Ограничение",
        description: "Максимальное количество изображений - 5",
        variant: "destructive",
      })
      return
    }

    setProduct((prev) => ({
      ...prev,
      images: [...prev.images, ""],
    }))
  }

  const handleRemoveImage = (index: number) => {
    setProduct((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }))
  }

  const handleImageUpload = (index: number, imageUrl: string) => {
    const newImages = [...product.images]
    newImages[index] = imageUrl
    setProduct((prev) => ({
      ...prev,
      images: newImages,
    }))
  }

  const handleGenerateSeo = async () => {
    if (!product.name || !product.category) {
      toast({
        title: "Ошибка",
        description: "Для генерации SEO данных необходимо указать название и категорию товара",
        variant: "destructive",
      })
      return
    }

    setIsSeoGenerating(true)

    try {
      // Генерируем SEO данные
      const seoData = generateProductSeoData(product.name, product.category)

      // Генерируем slug
      let slug = product.slug
      if (!slug) {
        slug = generateSlug(product.name)
        if (params.id !== "new") {
          slug = await ensureUniqueSlug(slug, product.id)
        } else {
          slug = await ensureUniqueSlug(slug)
        }
      }

      setProduct((prev) => ({
        ...prev,
        seo_title: seoData.seoTitle,
        seo_description: seoData.seoDescription,
        slug,
      }))

      toast({
        title: "SEO данные сгенерированы",
        description: "Заголовок, описание и URL успешно сгенерированы",
        variant: "success",
      })
    } catch (error) {
      console.error("Ошибка при генерации SEO данных:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось сгенерировать SEO данные",
        variant: "destructive",
      })
    } finally {
      setIsSeoGenerating(false)
    }
  }

  const validateForm = () => {
    if (!product.name.trim()) {
      toast({
        title: "Ошибка",
        description: "Введите название товара",
        variant: "destructive",
      })
      return false
    }

    if (product.price === "") {
      toast({
        title: "Ошибка",
        description: "Введите цену товара",
        variant: "destructive",
      })
      return false
    }

    if (product.images.length === 0) {
      toast({
        title: "Ошибка",
        description: "Добавьте хотя бы одно изображение",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    try {
      // Преобразуем строковые значения в числовые для отправки на сервер
      const productData = {
        id: product.id,
        name: product.name,
        price: product.price === "" ? 0 : Number.parseFloat(product.price),
        description: product.description,
        category: product.category,
        unit: product.unit,
        discount: product.discount === "" ? null : Number.parseFloat(product.discount),
        origin: product.origin,
        weight: product.weight === "" ? null : Number.parseFloat(product.weight),
        volume: product.volume === "" ? null : Number.parseFloat(product.volume),
        images: product.images,
        active: product.active,
        on_homepage: product.on_homepage,
        seo_title: product.seo_title,
        seo_description: product.seo_description,
        min_quantity: product.min_quantity === "" ? 1 : Number.parseFloat(product.min_quantity),
        max_quantity: product.max_quantity === "" ? 10 : Number.parseFloat(product.max_quantity),
        step: product.step === "" ? 1 : Number.parseFloat(product.step),
        stock_quantity: product.stock_quantity === "" ? 0 : Number.parseInt(product.stock_quantity),
        slug: product.slug || (await ensureUniqueSlug(generateSlug(product.name), product.id)),
      }

      console.log("Отправка данных для обновления товара:", productData)

      // Determine if this is a new product or an update
      const isNewProduct = params.id === "new"
      const method = isNewProduct ? "POST" : "PUT"
      const endpoint = isNewProduct ? "/api/products" : `/api/products/${params.id}`

      // Отправляем запрос на создание или обновление товара
      const response = await fetch(endpoint, {
        method: method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(productData),
      })

      const data = await response.json()
      console.log("Ответ сервера:", data)

      if (!response.ok) {
        throw new Error(data.message || `Ошибка при ${isNewProduct ? "создании" : "обновлении"} товара`)
      }

      toast({
        title: isNewProduct ? "Товар создан" : "Товар обновлен",
        description: `Товар "${product.name}" успешно ${isNewProduct ? "создан" : "обновлен"}`,
        variant: "success",
      })

      // Перенаправление на страницу товаров
      router.push("/admin/products")
    } catch (error: any) {
      console.error(`Ошибка при ${params.id === "new" ? "создании" : "обновлении"} товара:`, error)
      toast({
        title: "Ошибка",
        description: error.message || `Не удалось ${params.id === "new" ? "создать" : "обновить"} товар`,
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm(`Вы уверены, что хотите удалить товар "${product.name}"?`)) {
      return
    }

    setIsDeleting(true)

    try {
      const response = await fetch(`/api/products/${params.id}`, {
        method: "DELETE",
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Ошибка при удалении товара")
      }

      toast({
        title: "Товар удален",
        description: `Товар "${product.name}" успешно удален`,
        variant: "success",
      })

      // Перенаправление на страницу товаров
      router.push("/admin/products")
    } catch (error: any) {
      console.error("Ошибка при удалении товара:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить товар",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center p-8">
          <p>Загрузка товара...</p>
        </div>
      </AdminLayout>
    )
  }

  if (error) {
    return (
      <AdminLayout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/admin/products">
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Назад к списку
                </Link>
              </Button>
              <h1 className="text-3xl font-bold">Редактирование товара</h1>
            </div>
          </div>

          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Ошибка</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>

          <div className="flex justify-center">
            <Button asChild>
              <Link href="/admin/products">Вернуться к списку товаров</Link>
            </Button>
          </div>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/products">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад к списку
              </Link>
            </Button>
            <h1 className="text-3xl font-bold">Редактирование товара</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={isSubmitting || isDeleting || params.id === "new"}
              className="flex items-center gap-1"
            >
              <Trash2 className="h-4 w-4" />
              {isDeleting ? "Удаление..." : "Удалить"}
            </Button>
            <Button
              variant="outline"
              onClick={() => router.push("/admin/products")}
              disabled={isSubmitting || isDeleting}
            >
              Отмена
            </Button>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={handleSubmit}
              disabled={isSubmitting || isDeleting}
            >
              {isSubmitting ? "Сохранение..." : "Сохранить изменения"}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Основная информация</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Название товара</Label>
                  <Input
                    id="name"
                    name="name"
                    value={product.name}
                    onChange={handleChange}
                    placeholder="Например: Яблоки Голден"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="price">Цена (₽)</Label>
                    <Input
                      id="price"
                      name="price"
                      type="number"
                      value={product.price}
                      onChange={handleChange}
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount">Скидка (%)</Label>
                    <Input
                      id="discount"
                      name="discount"
                      type="number"
                      value={product.discount}
                      onChange={handleChange}
                      min="0"
                      max="100"
                      step="0.1"
                      placeholder="0"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Описание</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={product.description}
                    onChange={handleChange}
                    rows={4}
                    placeholder="Подробное описание товара"
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="category">Категория</Label>
                    <Select value={product.category} onValueChange={(value) => handleSelectChange("category", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите категорию" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fruits">Фрукты</SelectItem>
                        <SelectItem value="vegetables">Овощи</SelectItem>
                        <SelectItem value="berries">Ягоды</SelectItem>
                        <SelectItem value="dried-fruits">Сухофрукты и орехи</SelectItem>
                        <SelectItem value="greens">Зелень и травы</SelectItem>
                        <SelectItem value="beverages">Свежевыжатые соки и напитки</SelectItem>
                        <SelectItem value="sets">Готовые наборы</SelectItem>
                        <SelectItem value="exotic">Экзотические продукты</SelectItem>
                        <SelectItem value="bread">Лепёшки и хлеб</SelectItem>
                        <SelectItem value="promotions">Акции и новинки</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">Единица измерения</Label>
                    <Select value={product.unit} onValueChange={(value) => handleSelectChange("unit", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите единицу" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="кг">кг</SelectItem>
                        <SelectItem value="г">г</SelectItem>
                        <SelectItem value="л">л</SelectItem>
                        <SelectItem value="мл">мл</SelectItem>
                        <SelectItem value="шт">шт</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="stock_quantity">Количество в наличии ({product.unit})</Label>
                  <Input
                    id="stock_quantity"
                    name="stock_quantity"
                    type="number"
                    value={product.stock_quantity}
                    onChange={handleChange}
                    min="0"
                    step="1"
                    placeholder="0"
                  />
                  <p className="text-xs text-gray-500">
                    Если количество равно 0, товар будет помечен как "Нет в наличии"
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Дополнительная информация</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="origin">Происхождение</Label>
                  <Input
                    id="origin"
                    name="origin"
                    value={product.origin}
                    onChange={handleChange}
                    placeholder="Например: Краснодарский край"
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="weight">Вес ({product.unit})</Label>
                    <Input
                      id="weight"
                      name="weight"
                      type="number"
                      value={product.weight}
                      onChange={handleChange}
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="volume">Объем ({product.unit})</Label>
                    <Input
                      id="volume"
                      name="volume"
                      type="number"
                      value={product.volume}
                      onChange={handleChange}
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="min_quantity">Мин. количество</Label>
                    <Input
                      id="min_quantity"
                      name="min_quantity"
                      type="number"
                      value={product.min_quantity}
                      onChange={handleChange}
                      min="0.1"
                      step="0.1"
                      placeholder="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="max_quantity">Макс. количество</Label>
                    <Input
                      id="max_quantity"
                      name="max_quantity"
                      type="number"
                      value={product.max_quantity}
                      onChange={handleChange}
                      min="0.1"
                      step="0.1"
                      placeholder="10"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="step">Шаг</Label>
                    <Input
                      id="step"
                      name="step"
                      type="number"
                      value={product.step}
                      onChange={handleChange}
                      min="0.1"
                      step="0.1"
                      placeholder="1"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>SEO</CardTitle>
                <Button
                  variant="outline"
                  onClick={handleGenerateSeo}
                  disabled={isSeoGenerating}
                  className="flex items-center gap-1"
                >
                  {isSeoGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Генерация...
                    </>
                  ) : (
                    <>
                      <Wand2 className="h-4 w-4" />
                      Сгенерировать SEO
                    </>
                  )}
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="slug">URL товара (slug)</Label>
                  <div className="flex">
                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                      /product/
                    </span>
                    <Input
                      id="slug"
                      name="slug"
                      value={product.slug}
                      onChange={handleChange}
                      placeholder="автоматически из названия"
                      className="rounded-l-none"
                    />
                  </div>
                  <p className="text-xs text-gray-500">
                    SEO-оптимизированный URL. Если оставить пустым, будет сгенерирован автоматически из названия товара.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="seo_title">SEO заголовок</Label>
                  <Input
                    id="seo_title"
                    name="seo_title"
                    value={product.seo_title}
                    onChange={handleChange}
                    placeholder="Оставьте пустым, чтобы использовать название товара"
                  />
                  <p className="text-xs text-gray-500">Заголовок страницы товара для поисковых систем (title тег)</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="seo_description">SEO описание</Label>
                  <Textarea
                    id="seo_description"
                    name="seo_description"
                    value={product.seo_description}
                    onChange={handleChange}
                    rows={3}
                    placeholder="Оставьте пустым, чтобы использовать описание товара"
                  />
                  <p className="text-xs text-gray-500">
                    Мета-описание товара для поисковых систем (meta description тег)
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Настройки отображения</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="active"
                    checked={product.active}
                    onCheckedChange={(checked) => handleSwitchChange("active", checked)}
                  />
                  <Label htmlFor="active">Активен</Label>
                </div>
                <p className="text-sm text-gray-500">Неактивные товары не отображаются на сайте</p>

                <Separator className="my-2" />

                <div className="flex items-center space-x-2">
                  <Switch
                    id="on_homepage"
                    checked={product.on_homepage}
                    onCheckedChange={(checked) => handleSwitchChange("on_homepage", checked)}
                    disabled={homepageProductsCount >= 7 && !product.on_homepage}
                  />
                  <Label htmlFor="on_homepage">В главном экране</Label>
                </div>
                <div className="text-sm text-gray-500">
                  <p>Товар будет отображаться на главной странице</p>
                  <p className="mt-1">Текущее количество: {homepageProductsCount}/7</p>
                  {homepageProductsCount >= 7 && !product.on_homepage && (
                    <div className="mt-2 flex items-start gap-2 text-amber-600">
                      <AlertTriangle className="h-4 w-4 mt-0.5" />
                      <p>Достигнут лимит товаров на главной странице (7)</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Изображения</CardTitle>
                <Button variant="outline" size="sm" onClick={handleAddImage} className="h-8 gap-1">
                  <Plus className="h-4 w-4" />
                  Добавить
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {product.images.length === 0 && (
                    <ImageUpload onImageUpload={(url) => setProduct((prev) => ({ ...prev, images: [url] }))} />
                  )}

                  {product.images.map((image, index) => (
                    <div key={index} className="relative rounded-md border p-4">
                      <ImageUpload
                        currentImage={image}
                        onImageUpload={(url) => handleImageUpload(index, url)}
                        onRemove={() => handleRemoveImage(index)}
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="text-sm text-gray-500">
                Рекомендуемый размер изображения: 800x800 пикселей (максимум 5 изображений)
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
