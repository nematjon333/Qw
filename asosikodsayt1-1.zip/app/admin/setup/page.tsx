"use client"

import { useState, useEffect } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"
import { SetupDatabaseButton } from "@/components/admin/setup-database-button"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function AdminSetupPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [databaseStatus, setDatabaseStatus] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    checkDatabaseStatus()
  }, [])

  const checkDatabaseStatus = async () => {
    setIsLoading(true)
    setError(null)
    try {
      console.log("Проверка статуса базы данных...")
      const response = await fetch("/api/setup-database/status")

      if (!response.ok) {
        throw new Error(`Ошибка HTTP: ${response.status}`)
      }

      const data = await response.json()
      console.log("Статус базы данных:", data)
      setDatabaseStatus(data)
    } catch (error) {
      console.error("Ошибка при проверке статуса базы данных:", error)
      setError(error.message || "Не удалось проверить статус базы данных")
      toast({
        title: "Ошибка",
        description: "Не удалось проверить статус базы данных",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Настройка системы</h1>
          <p className="text-gray-500">Инициализация и настройка базы данных</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Настройка базы данных</CardTitle>
            <CardDescription>Создание необходимых таблиц в базе данных для работы системы</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertTitle>Ошибка</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <p>
              Нажмите кнопку ниже, чтобы создать все необходимые таблицы в базе данных. Это действие безопасно и не
              затронет существующие данные.
            </p>

            <div className="flex justify-center">
              <SetupDatabaseButton />
            </div>

            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-green-600" />
                <span className="ml-2">Проверка статуса базы данных...</span>
              </div>
            ) : databaseStatus && databaseStatus.tables ? (
              <div className="mt-6">
                <h3 className="text-lg font-medium mb-2">Статус таблиц:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {Object.entries(databaseStatus.tables).map(([table, exists]) => (
                    <div key={table} className="flex items-center">
                      {exists ? (
                        <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500 mr-2" />
                      )}
                      <span>{table}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            <div className="mt-4">
              <p className="font-medium">Что будет создано:</p>
              <ul className="list-disc pl-5 mt-2 space-y-1">
                <li>Таблица заказов (orders)</li>
                <li>Таблица товаров в заказах (order_items)</li>
                <li>Таблица клиентов (customers)</li>
                <li>Таблица промокодов (promo_codes)</li>
                <li>Таблица зон доставки (delivery_zones)</li>
                <li>Таблица товаров (products)</li>
                <li>Таблица настроек сайта (site_settings)</li>
              </ul>
            </div>

            <div className="mt-4 pt-4 border-t">
              <Button onClick={checkDatabaseStatus} variant="outline">
                Обновить статус
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  )
}
