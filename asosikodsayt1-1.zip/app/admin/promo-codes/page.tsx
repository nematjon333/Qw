"use client"

import { useEffect, useState } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"
import { Pencil, Trash2, Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { supabase } from "@/lib/supabase-client"

export default function AdminPromoCodesPage() {
  const [promoCodes, setPromoCodes] = useState([])
  const [loading, setLoading] = useState(true)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  useEffect(() => {
    fetchPromoCodes()
  }, [])

  const fetchPromoCodes = async () => {
    try {
      const { data, error } = await supabase.from("promo_codes").select("*").order("created_at", { ascending: false })

      if (error) throw error

      // Transform data to match expected format
      const transformedCodes = data.map((code) => ({
        id: code.id,
        code: code.code,
        discount_percent: code.discount_percent || code.discount_value,
        min_order_amount: code.min_order_amount,
        max_discount_amount: code.max_discount_amount,
        usage_limit: code.usage_limit,
        usage_count: code.usage_count || 0,
        active: code.active !== false, // Используем поле active вместо is_active
        expires_at: code.expires_at,
      }))

      setPromoCodes(transformedCodes)
    } catch (error) {
      console.error("Ошибка при получении промокодов:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить промокоды",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleToggleActive = async (id: string, checked: boolean) => {
    try {
      const promoCode = promoCodes.find((p) => p.id === id)
      if (!promoCode) return

      // Используем поле active вместо is_active
      const { error } = await supabase.from("promo_codes").update({ active: checked }).eq("id", id)

      if (error) throw error

      // Update local state
      setPromoCodes(promoCodes.map((p) => (p.id === id ? { ...p, active: checked } : p)))

      toast({
        title: "Промокод обновлен",
        description: `Промокод ${promoCode.code} ${checked ? "активирован" : "деактивирован"}`,
        variant: "success",
      })
    } catch (error) {
      console.error("Ошибка при обновлении промокода:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить промокод",
        variant: "destructive",
      })
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Вы уверены, что хотите удалить этот промокод?")) {
      return
    }

    setDeletingId(id)

    try {
      const { error } = await supabase.from("promo_codes").delete().eq("id", id)

      if (error) throw error

      // Update local state
      setPromoCodes(promoCodes.filter((p) => p.id !== id))

      toast({
        title: "Промокод удален",
        description: "Промокод успешно удален",
        variant: "success",
      })
    } catch (error) {
      console.error("Ошибка при удалении промокода:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить промокод",
        variant: "destructive",
      })
    } finally {
      setDeletingId(null)
    }
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center p-8">
          <p>Загрузка промокодов...</p>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Промокоды</h1>
            <p className="text-gray-500">Управление промокодами для скидок</p>
          </div>
          <Button asChild className="bg-green-600 hover:bg-green-700">
            <Link href="/admin/promo-codes/new">Создать промокод</Link>
          </Button>
        </div>

        <h2 className="text-xl font-semibold">Существующие промокоды</h2>

        {promoCodes.length === 0 ? (
          <p className="py-4 text-center text-gray-500">Нет созданных промокодов</p>
        ) : (
          <div className="space-y-4">
            {promoCodes.map((promoCode) => (
              <Card key={promoCode.id}>
                <CardContent className="p-6">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-semibold">{promoCode.code}</h3>
                      <p className="text-sm text-gray-500">
                        Скидка: {promoCode.discount_percent}%
                        {promoCode.min_order_amount && ` | Мин. заказ: ${promoCode.min_order_amount} ₽`}
                        {promoCode.max_discount_amount && ` | Макс. скидка: ${promoCode.max_discount_amount} ₽`}
                      </p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-sm">
                        <p>
                          Использовано: {promoCode.usage_count}/{promoCode.usage_limit || "∞"}
                        </p>
                        {promoCode.expires_at && (
                          <p>Истекает: {new Date(promoCode.expires_at).toLocaleDateString("ru-RU")}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          id={`active-${promoCode.id}`}
                          checked={promoCode.active}
                          onCheckedChange={(checked) => handleToggleActive(promoCode.id, checked)}
                        />
                        <Label htmlFor={`active-${promoCode.id}`} className="sr-only">
                          Активен
                        </Label>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/admin/promo-codes/${promoCode.id}`}>
                            <Pencil className="h-4 w-4 mr-1" />
                            Изменить
                          </Link>
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDelete(promoCode.id)}
                          disabled={deletingId === promoCode.id}
                        >
                          {deletingId === promoCode.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4 mr-1" />
                          )}
                          Удалить
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AdminLayout>
  )
}
