"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Trash2 } from "lucide-react"
import Link from "next/link"
import { toast } from "@/components/ui/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function EditPromoCodePage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [promoCode, setPromoCode] = useState({
    id: "",
    code: "",
    discount_percent: 10,
    min_order_amount: 1000,
    max_discount_amount: 500,
    usage_limit: 100,
    usage_count: 0,
    active: true,
    expires_at: "",
    created_at: "",
  })

  // Загрузка данных промокода
  useEffect(() => {
    const fetchPromoCode = async () => {
      setIsLoading(true)
      try {
        const response = await fetch(`/api/promo-codes/${params.id}`)

        if (!response.ok) {
          throw new Error(`Ошибка HTTP: ${response.status}`)
        }

        const data = await response.json()

        if (data.success && data.promoCode) {
          // Форматируем дату истечения для поля ввода
          let expiresAt = ""
          if (data.promoCode.expires_at) {
            const date = new Date(data.promoCode.expires_at)
            expiresAt = date.toISOString().split("T")[0]
          }

          setPromoCode({
            ...data.promoCode,
            expires_at: expiresAt,
          })
          setError(null)
        } else {
          setError(data.message || "Промокод не найден")
        }
      } catch (err: any) {
        console.error("Ошибка при загрузке промокода:", err)
        setError(`Ошибка при загрузке промокода: ${err.message}`)
      } finally {
        setIsLoading(false)
      }
    }

    if (params.id) {
      fetchPromoCode()
    }
  }, [params.id])

  const handleInputChange = (e) => {
    const { name, value, type } = e.target
    setPromoCode({
      ...promoCode,
      [name]: type === "number" ? Number(value) : value,
    })
  }

  const handleSwitchChange = (checked) => {
    setPromoCode({
      ...promoCode,
      active: checked,
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!promoCode.code) {
      toast({
        title: "Ошибка",
        description: "Введите код промокода",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const response = await fetch(`/api/promo-codes/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(promoCode),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Ошибка при обновлении промокода")
      }

      toast({
        title: "Промокод обновлен",
        description: `Промокод ${promoCode.code} успешно обновлен`,
        variant: "success",
      })

      // Перенаправление на страницу промокодов
      router.push("/admin/promo-codes")
    } catch (error) {
      console.error("Ошибка при обновлении промокода:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить промокод",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm(`Вы уверены, что хотите удалить промокод "${promoCode.code}"?`)) {
      return
    }

    setIsDeleting(true)

    try {
      const response = await fetch(`/api/promo-codes/${params.id}`, {
        method: "DELETE",
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Ошибка при удалении промокода")
      }

      toast({
        title: "Промокод удален",
        description: `Промокод "${promoCode.code}" успешно удален`,
        variant: "success",
      })

      // Перенаправление на страницу промокодов
      router.push("/admin/promo-codes")
    } catch (error) {
      console.error("Ошибка при удалении промокода:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить промокод",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center p-8">
          <p>Загрузка промокода...</p>
        </div>
      </AdminLayout>
    )
  }

  if (error) {
    return (
      <AdminLayout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/admin/promo-codes">
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Назад к списку
                </Link>
              </Button>
              <h1 className="text-3xl font-bold">Редактирование промокода</h1>
            </div>
          </div>

          <Alert variant="destructive">
            <AlertTitle>Ошибка</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>

          <div className="flex justify-center">
            <Button asChild>
              <Link href="/admin/promo-codes">Вернуться к списку промокодов</Link>
            </Button>
          </div>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/promo-codes">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад к списку
              </Link>
            </Button>
            <h1 className="text-3xl font-bold">Редактирование промокода</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={isSubmitting || isDeleting}
              className="flex items-center gap-1"
            >
              <Trash2 className="h-4 w-4" />
              {isDeleting ? "Удаление..." : "Удалить"}
            </Button>
            <Button
              variant="outline"
              onClick={() => router.push("/admin/promo-codes")}
              disabled={isSubmitting || isDeleting}
            >
              Отмена
            </Button>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={handleSubmit}
              disabled={isSubmitting || isDeleting}
            >
              {isSubmitting ? "Сохранение..." : "Сохранить изменения"}
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Информация о промокоде</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="code">Код</Label>
                  <Input
                    id="code"
                    name="code"
                    value={promoCode.code}
                    onChange={handleInputChange}
                    placeholder="Например, SUMMER2025"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="discount_percent">Процент скидки (%)</Label>
                  <Input
                    id="discount_percent"
                    name="discount_percent"
                    type="number"
                    min="1"
                    max="100"
                    value={promoCode.discount_percent}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="min_order_amount">Минимальная сумма заказа (₽)</Label>
                  <Input
                    id="min_order_amount"
                    name="min_order_amount"
                    type="number"
                    min="0"
                    value={promoCode.min_order_amount}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_discount_amount">Максимальная скидка (₽)</Label>
                  <Input
                    id="max_discount_amount"
                    name="max_discount_amount"
                    type="number"
                    min="0"
                    value={promoCode.max_discount_amount}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="usage_limit">Лимит использований</Label>
                  <Input
                    id="usage_limit"
                    name="usage_limit"
                    type="number"
                    min="1"
                    value={promoCode.usage_limit}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expires_at">Дата истечения</Label>
                  <Input
                    id="expires_at"
                    name="expires_at"
                    type="date"
                    value={promoCode.expires_at}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Использований</Label>
                  <Input value={promoCode.usage_count} disabled className="bg-gray-50" />
                </div>
                <div className="flex items-center space-x-2 pt-8">
                  <Switch id="active" checked={promoCode.active} onCheckedChange={handleSwitchChange} />
                  <Label htmlFor="active">Активен</Label>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  )
}
