"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Loader2 } from "lucide-react"
import Link from "next/link"
import { toast } from "@/components/ui/use-toast"

export default function NewPromoCodePage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [promoCode, setPromoCode] = useState({
    code: "",
    discount_percent: 10,
    min_order_amount: 1000,
    max_discount_amount: 500,
    usage_limit: 100,
    active: true,
    expires_at: "",
  })

  const handleInputChange = (e) => {
    const { name, value, type } = e.target
    setPromoCode({
      ...promoCode,
      [name]: type === "number" ? Number(value) : value,
    })
  }

  const handleSwitchChange = (checked) => {
    setPromoCode({
      ...promoCode,
      active: checked,
    })
  }

  const generateRandomCode = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    let result = ""
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setPromoCode({
      ...promoCode,
      code: result,
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Validate the form
    if (!promoCode.code) {
      toast({
        title: "Ошибка",
        description: "Код промокода обязателен",
        variant: "destructive",
      })
      setIsSubmitting(false)
      return
    }

    try {
      console.log("Отправка данных промокода:", promoCode)

      // Format the data properly
      const formattedPromoCode = {
        ...promoCode,
        discount_percent: Number(promoCode.discount_percent),
        min_order_amount: Number(promoCode.min_order_amount),
        max_discount_amount: Number(promoCode.max_discount_amount),
        usage_limit: Number(promoCode.usage_limit),
      }

      const response = await fetch("/api/promo-codes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formattedPromoCode),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || `Ошибка при создании промокода: ${response.status}`)
      }

      const data = await response.json()
      console.log("Ответ сервера:", data)

      toast({
        title: "Промокод создан",
        description: `Промокод ${promoCode.code} успешно создан`,
        variant: "success",
      })

      // Перенаправление на страницу промокодов
      router.push("/admin/promo-codes")
    } catch (error) {
      console.error("Ошибка при создании промокода:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать промокод",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/promo-codes">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад к списку
              </Link>
            </Button>
            <h1 className="text-3xl font-bold">Новый промокод</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => router.push("/admin/promo-codes")} disabled={isSubmitting}>
              Отмена
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Создание...
                </span>
              ) : (
                "Создать промокод"
              )}
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Информация о промокоде</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="code">Код</Label>
                  <div className="flex gap-2">
                    <Input
                      id="code"
                      name="code"
                      value={promoCode.code}
                      onChange={handleInputChange}
                      placeholder="Например, SUMMER2025"
                      required
                    />
                    <Button type="button" variant="outline" onClick={generateRandomCode}>
                      Сгенерировать
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="discount_percent">Процент скидки (%)</Label>
                  <Input
                    id="discount_percent"
                    name="discount_percent"
                    type="number"
                    min="1"
                    max="100"
                    value={promoCode.discount_percent}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="min_order_amount">Минимальная сумма заказа (₽)</Label>
                  <Input
                    id="min_order_amount"
                    name="min_order_amount"
                    type="number"
                    min="0"
                    value={promoCode.min_order_amount}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_discount_amount">Максимальная скидка (₽)</Label>
                  <Input
                    id="max_discount_amount"
                    name="max_discount_amount"
                    type="number"
                    min="0"
                    value={promoCode.max_discount_amount}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="usage_limit">Лимит использований</Label>
                  <Input
                    id="usage_limit"
                    name="usage_limit"
                    type="number"
                    min="1"
                    value={promoCode.usage_limit}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="expires_at">Дата истечения</Label>
                  <Input
                    id="expires_at"
                    name="expires_at"
                    type="date"
                    value={promoCode.expires_at}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="flex items-center space-x-2 pt-8">
                  <Switch id="active" checked={promoCode.active} onCheckedChange={handleSwitchChange} />
                  <Label htmlFor="active">Активен</Label>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  )
}
