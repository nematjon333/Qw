"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { DeliveryZonesMap } from "@/components/delivery-zones-map"
import type { DeliveryZone } from "@/types/delivery"
import { Loader2 } from "lucide-react"
import { toast } from "sonner"

export default function EditDeliveryZonePage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [zone, setZone] = useState<DeliveryZone | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    async function fetchZone() {
      try {
        const response = await fetch(`/api/delivery-zones/${params.id}`)
        if (!response.ok) {
          throw new Error("Не удалось загрузить данные зоны доставки")
        }
        const data = await response.json()
        setZone(data)
      } catch (error) {
        console.error("Ошибка при загрузке зоны доставки:", error)
        toast.error("Ошибка при загрузке зоны доставки")
      } finally {
        setLoading(false)
      }
    }

    fetchZone()
  }, [params.id])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setZone((prev) => {
      if (!prev) return prev
      return {
        ...prev,
        [name]:
          name === "delivery_fee" ||
          name === "min_order_amount" ||
          name === "free_delivery_threshold" ||
          name === "radius"
            ? Number.parseFloat(value)
            : value,
      }
    })
  }

  const handlePolygonChange = (polygon: [number, number][]) => {
    setZone((prev) => {
      if (!prev) return prev
      return {
        ...prev,
        polygon,
      }
    })
  }

  const handleCenterChange = (lat: number, lng: number) => {
    setZone((prev) => {
      if (!prev) return prev
      return {
        ...prev,
        center_lat: lat,
        center_lng: lng,
      }
    })
  }

  const handleRadiusChange = (radius: number) => {
    setZone((prev) => {
      if (!prev) return prev
      return {
        ...prev,
        radius,
      }
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!zone) return

    setSaving(true)
    try {
      const response = await fetch(`/api/delivery-zones/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(zone),
      })

      if (!response.ok) {
        throw new Error("Не удалось обновить зону доставки")
      }

      toast.success("Зона доставки успешно обновлена")
      router.push("/admin/delivery-zones")
    } catch (error) {
      console.error("Ошибка при обновлении зоны доставки:", error)
      toast.error("Ошибка при обновлении зоны доставки")
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm("Вы уверены, что хотите удалить эту зону доставки?")) {
      return
    }

    setDeleting(true)
    try {
      const response = await fetch(`/api/delivery-zones/${params.id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Не удалось удалить зону доставки")
      }

      toast.success("Зона доставки успешно удалена")
      router.push("/admin/delivery-zones")
    } catch (error) {
      console.error("Ошибка при удалении зоны доставки:", error)
      toast.error("Ошибка при удалении зоны доставки")
    } finally {
      setDeleting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!zone) {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">Зона доставки не найдена</h1>
        <Button onClick={() => router.push("/admin/delivery-zones")}>Вернуться к списку зон</Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Редактирование зоны доставки</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.push("/admin/delivery-zones")}>
            Отмена
          </Button>
          <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
            {deleting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Удалить
          </Button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Основная информация</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Название зоны</Label>
                <Input id="name" name="name" value={zone.name} onChange={handleChange} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="delivery_fee">Стоимость доставки (₽)</Label>
                <Input
                  id="delivery_fee"
                  name="delivery_fee"
                  type="number"
                  min="0"
                  step="1"
                  value={zone.delivery_fee}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="min_order_amount">Минимальная сумма заказа (₽)</Label>
                <Input
                  id="min_order_amount"
                  name="min_order_amount"
                  type="number"
                  min="0"
                  step="1"
                  value={zone.min_order_amount}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="free_delivery_threshold">Бесплатная доставка от (₽)</Label>
                <Input
                  id="free_delivery_threshold"
                  name="free_delivery_threshold"
                  type="number"
                  min="0"
                  step="1"
                  value={zone.free_delivery_threshold}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="estimated_delivery_time">Примерное время доставки</Label>
                <Input
                  id="estimated_delivery_time"
                  name="estimated_delivery_time"
                  value={zone.estimated_delivery_time || ""}
                  onChange={handleChange}
                  placeholder="30-60 минут"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="radius">Радиус зоны (км)</Label>
                <Input
                  id="radius"
                  name="radius"
                  type="number"
                  min="0"
                  step="0.1"
                  value={zone.radius || ""}
                  onChange={handleChange}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="message">Сообщение для клиентов</Label>
              <Textarea
                id="message"
                name="message"
                value={zone.message || ""}
                onChange={handleChange}
                placeholder="Например: Доставка в течение 30-60 минут"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Зона доставки на карте</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[500px] w-full">
              <DeliveryZonesMap
                zones={[zone]}
                editable={true}
                onPolygonChange={handlePolygonChange}
                onCenterChange={handleCenterChange}
                onRadiusChange={handleRadiusChange}
                editingZoneId={Number.parseInt(params.id)}
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Сохранить изменения
          </Button>
        </div>
      </form>
    </div>
  )
}
