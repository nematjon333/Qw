"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"
import { Loader2, Plus, MapPin, AlertTriangle, Zap } from "lucide-react"
import { AdminLayout } from "@/components/admin/admin-layout"
import dynamic from "next/dynamic"
import { STORE_LATITUDE, STORE_LONGITUDE } from "@/lib/dadata-service"
import type { DeliveryZone } from "@/types/delivery"
import { useSWRConfig } from "swr"

// Исправляем импорт карты - используем прямой импорт компонента
const DeliveryZonesMap = dynamic(() => import("@/components/delivery-zones-map"), {
  ssr: false,
  loading: () => (
    <div className="flex h-[400px] items-center justify-center rounded-lg border border-dashed">
      <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
    </div>
  ),
})

export default function DeliveryZonesPage() {
  const [zones, setZones] = useState<DeliveryZone[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const { mutate } = useSWRConfig()

  // Загрузка зон доставки
  useEffect(() => {
    const fetchZones = async () => {
      try {
        setLoading(true)
        const response = await fetch("/api/delivery-zones")

        if (!response.ok) {
          throw new Error(`Ошибка при получении зон доставки: ${response.status}`)
        }

        const data = await response.json()

        if (!data.success) {
          throw new Error(data.message || "Не удалось загрузить зоны доставки")
        }

        // Нормализуем зоны доставки
        const normalizedZones: DeliveryZone[] = data.zones
          .map((zone) => ({
            id: zone.id,
            minDistance: zone.min_m ?? (zone.min_km ? zone.min_km * 1000 : 0),
            maxDistance: zone.max_m ?? (zone.max_km ? zone.max_km * 1000 : 0),
            price: zone.price,
            minOrderAmount: zone.min_order_amount,
            freeDeliveryThreshold: zone.free_delivery_threshold,
            estimatedTime: zone.estimated_time || `${zone.estimated_time || 30} мин`,
            color: zone.color || "green",
            name: zone.name || `Зона ${zone.min_km || 0}-${zone.max_km || 0} км`,
            active: zone.active !== false,
            surge_active: zone.surge_active || false,
            surge_price: zone.surge_price || 0,
            surge_reason: zone.surge_reason || null,
          }))
          .sort((a, b) => a.minDistance - b.minDistance) // Сортируем по возрастанию минимального расстояния

        setZones(normalizedZones)
        setError(null)
      } catch (error) {
        console.error("Ошибка при загрузке зон доставки:", error)
        setError("Не удалось загрузить зоны доставки. Пожалуйста, попробуйте позже.")
      } finally {
        setLoading(false)
      }
    }

    fetchZones()
  }, [])

  // Исправим ошибку при обновлении зоны доставки
  // Найдем функции handleToggleSurge и handleToggleActive и исправим их:

  const handleToggleSurge = async (id: string, currentValue: boolean) => {
    try {
      setIsLoading(true)

      const response = await fetch(`/api/delivery-zones/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ surge_active: !currentValue }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error("Ошибка ответа сервера:", errorText)
        throw new Error(`Ошибка HTTP: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Успешно",
          description: "Статус повышенной стоимости доставки обновлен",
        })
        mutate("/api/delivery-zones")
      } else {
        toast({
          title: "Ошибка",
          description: data.message || "Не удалось обновить статус повышенной стоимости доставки",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Ошибка при обновлении зоны доставки:", error)
      toast({
        title: "Ошибка",
        description: `Ошибка при обновлении зоны доставки: ${error.message}`,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleActive = async (id: string, currentValue: boolean) => {
    try {
      setIsLoading(true)

      const response = await fetch(`/api/delivery-zones/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ active: !currentValue }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error("Ошибка ответа сервера:", errorText)
        throw new Error(`Ошибка HTTP: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Успешно",
          description: "Статус зоны доставки обновлен",
        })
        mutate("/api/delivery-zones")
      } else {
        toast({
          title: "Ошибка",
          description: data.message || "Не удалось обновить статус зоны доставки",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Ошибка при обновлении зоны доставки:", error)
      toast({
        title: "Ошибка",
        description: `Ошибка при обновлении зоны доставки: ${error.message}`,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-3xl font-bold">Зоны доставки</h1>
          <Button asChild>
            <Link href="/admin/delivery-zones/new">
              <Plus className="mr-2 h-4 w-4" />
              Добавить зону
            </Link>
          </Button>
        </div>

        {error && (
          <div className="mb-6 rounded-lg bg-red-50 p-4 text-red-600">
            <div className="flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5" />
              <span>{error}</span>
            </div>
          </div>
        )}

        <div className="grid gap-6 md:grid-cols-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="mr-2 h-5 w-5" />
                Карта зон доставки
              </CardTitle>
            </CardHeader>
            <CardContent>
              <DeliveryZonesMap zones={zones} storeCoordinates={[STORE_LATITUDE, STORE_LONGITUDE]} height={400} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Список зон доставки</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex h-40 items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                </div>
              ) : zones.length === 0 ? (
                <div className="flex h-40 flex-col items-center justify-center text-center">
                  <p className="mb-4 text-gray-500">Зоны доставки не найдены</p>
                  <Button asChild>
                    <Link href="/admin/delivery-zones/new">
                      <Plus className="mr-2 h-4 w-4" />
                      Добавить зону
                    </Link>
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Название</TableHead>
                        <TableHead>Расстояние (км)</TableHead>
                        <TableHead>Стоимость</TableHead>
                        <TableHead>Мин. заказ</TableHead>
                        <TableHead>Бесплатно от</TableHead>
                        <TableHead>Время</TableHead>
                        <TableHead>Активна</TableHead>
                        <TableHead>Повышенная</TableHead>
                        <TableHead>Действия</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {zones.map((zone) => (
                        <TableRow key={zone.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <div
                                className="mr-2 h-3 w-3 rounded-full"
                                style={{
                                  backgroundColor:
                                    zone.color === "green"
                                      ? "#22c55e"
                                      : zone.color === "yellow"
                                        ? "#eab308"
                                        : zone.color === "orange"
                                          ? "#f97316"
                                          : zone.color === "red"
                                            ? "#ef4444"
                                            : zone.color === "purple"
                                              ? "#a855f7"
                                              : zone.color === "blue"
                                                ? "#3b82f6"
                                                : "#6b7280",
                                }}
                              ></div>
                              <span className="font-medium">{zone.name}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {zone.minDistance / 1000} - {zone.maxDistance / 1000}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              {zone.price} ₽
                              {zone.surge_active && (
                                <Badge variant="outline" className="ml-2 bg-amber-50 text-amber-600">
                                  <Zap className="mr-1 h-3 w-3" />+{zone.surge_price} ₽
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{zone.minOrderAmount} ₽</TableCell>
                          <TableCell>{zone.freeDeliveryThreshold ? `${zone.freeDeliveryThreshold} ₽` : "-"}</TableCell>
                          <TableCell>{zone.estimatedTime}</TableCell>
                          <TableCell>
                            <Switch
                              checked={zone.active}
                              onCheckedChange={() => handleToggleActive(zone.id, zone.active)}
                              disabled={isLoading}
                            />
                          </TableCell>
                          <TableCell>
                            <Switch
                              checked={zone.surge_active}
                              onCheckedChange={() => handleToggleSurge(zone.id, zone.surge_active)}
                              disabled={isLoading}
                            />
                          </TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/admin/delivery-zones/${zone.id}`}>Редактировать</Link>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  )
}
