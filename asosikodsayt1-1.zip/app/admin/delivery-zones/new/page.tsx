"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { DeliveryZonesMap } from "@/components/delivery-zones-map"

export default function NewDeliveryZonePage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [zone, setZone] = useState({
    name: "",
    min_distance: 0,
    max_distance: 1000,
    price: 100,
    min_order_amount: 0,
    free_delivery_threshold: null as number | null,
    estimated_time: 30,
    color: "green",
    active: true,
    surge_active: false,
    surge_price: 0,
    surge_reason: "",
  })

  const handleInputChange = (e) => {
    const { name, value, type } = e.target
    setZone({
      ...zone,
      [name]: type === "number" ? (value === "" ? 0 : Number(value)) : value,
    })
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setZone({
      ...zone,
      [name]: checked,
    })
  }

  const handleSelectChange = (name: string, value: string) => {
    setZone({
      ...zone,
      [name]: value,
    })
  }

  const handleFreeDeliveryChange = (e) => {
    const value = e.target.value
    setZone({
      ...zone,
      free_delivery_threshold: value === "" ? null : Number(value),
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Проверка корректности данных
      if (zone.min_distance >= zone.max_distance) {
        throw new Error("Минимальное расстояние должно быть меньше максимального")
      }

      if (
        zone.price < 0 ||
        zone.min_order_amount < 0 ||
        (zone.free_delivery_threshold !== null && zone.free_delivery_threshold < 0)
      ) {
        throw new Error("Стоимость и минимальная сумма заказа не могут быть отрицательными")
      }

      if (zone.estimated_time <= 0) {
        throw new Error("Время доставки должно быть положительным числом")
      }

      // Отправка данных на сервер
      const response = await fetch("/api/delivery-zones", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(zone),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Ошибка при создании зоны доставки")
      }

      toast({
        title: "Зона доставки создана",
        description: `Зона "${zone.name}" успешно создана`,
      })

      // Перенаправление на страницу зон доставки
      router.push("/admin/delivery-zones")
    } catch (error) {
      console.error("Ошибка при создании зоны доставки:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать зону доставки",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/admin/delivery-zones">
                <ArrowLeft className="h-4 w-4 mr-1" />
                Назад к списку
              </Link>
            </Button>
            <h1 className="text-3xl font-bold">Новая зона доставки</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => router.push("/admin/delivery-zones")} disabled={isSubmitting}>
              Отмена
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Создание...
                </span>
              ) : (
                "Создать зону"
              )}
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Основные параметры</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Название зоны</Label>
                  <Input
                    id="name"
                    name="name"
                    value={zone.name}
                    onChange={handleInputChange}
                    placeholder="Например: 0 - 500 м"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="color">Цвет зоны</Label>
                  <Select value={zone.color} onValueChange={(value) => handleSelectChange("color", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Выберите цвет" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="green">Зеленый</SelectItem>
                      <SelectItem value="yellow">Желтый</SelectItem>
                      <SelectItem value="orange">Оранжевый</SelectItem>
                      <SelectItem value="red">Красный</SelectItem>
                      <SelectItem value="purple">Фиолетовый</SelectItem>
                      <SelectItem value="blue">Синий</SelectItem>
                      <SelectItem value="gray">Серый</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="min_distance">Минимальное расстояние (м)</Label>
                  <Input
                    id="min_distance"
                    name="min_distance"
                    type="number"
                    min="0"
                    value={zone.min_distance}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_distance">Максимальное расстояние (м)</Label>
                  <Input
                    id="max_distance"
                    name="max_distance"
                    type="number"
                    min="0"
                    value={zone.max_distance}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="price">Стоимость доставки (₽)</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    min="0"
                    value={zone.price}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="min_order_amount">Минимальная сумма заказа (₽)</Label>
                  <Input
                    id="min_order_amount"
                    name="min_order_amount"
                    type="number"
                    min="0"
                    value={zone.min_order_amount}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="free_delivery_threshold">Бесплатно от (₽)</Label>
                  <Input
                    id="free_delivery_threshold"
                    name="free_delivery_threshold"
                    type="number"
                    min="0"
                    value={zone.free_delivery_threshold === null ? "" : zone.free_delivery_threshold}
                    onChange={handleFreeDeliveryChange}
                    placeholder="Не указано"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="estimated_time">Время доставки (мин)</Label>
                  <Input
                    id="estimated_time"
                    name="estimated_time"
                    type="number"
                    min="1"
                    value={zone.estimated_time}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="flex items-center space-x-2 pt-8">
                  <Switch
                    id="active"
                    checked={zone.active}
                    onCheckedChange={(checked) => handleSwitchChange("active", checked)}
                  />
                  <Label htmlFor="active">Зона активна</Label>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Временная надбавка</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="surge_active"
                  checked={zone.surge_active}
                  onCheckedChange={(checked) => handleSwitchChange("surge_active", checked)}
                />
                <Label htmlFor="surge_active">Активировать надбавку</Label>
              </div>

              {zone.surge_active && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="surge_price">Сумма надбавки (₽)</Label>
                    <Input
                      id="surge_price"
                      name="surge_price"
                      type="number"
                      min="0"
                      value={zone.surge_price}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="surge_reason">Причина надбавки</Label>
                    <Input
                      id="surge_reason"
                      name="surge_reason"
                      value={zone.surge_reason}
                      onChange={handleInputChange}
                      placeholder="Например: плохая погода, пиковая нагрузка"
                    />
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Предпросмотр на карте</CardTitle>
          </CardHeader>
          <CardContent>
            <DeliveryZonesMap
              zones={[
                {
                  ...zone,
                  id: "preview",
                  created_at: new Date().toISOString(),
                  updated_at: null,
                },
              ]}
              height={300}
            />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  )
}
