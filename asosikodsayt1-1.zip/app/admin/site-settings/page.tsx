"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Pencil, Save, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { getAllSiteSettings, updateSetting, type GroupedSettings } from "@/lib/site-settings-service"
import { isAdminAuthenticated } from "@/lib/auth-service"

export default function SiteSettingsPage() {
  const router = useRouter()
  const [settings, setSettings] = useState<GroupedSettings>({})
  const [editMode, setEditMode] = useState<Record<string, boolean>>({})
  const [editValues, setEditValues] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<Record<string, boolean>>({})

  useEffect(() => {
    // Check if admin is authenticated
    if (!isAdminAuthenticated()) {
      router.push("/admin/login")
      return
    }

    // Fetch site settings
    const fetchSettings = async () => {
      try {
        const allSettings = await getAllSiteSettings()
        setSettings(allSettings)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching settings:", error)
        setLoading(false)
      }
    }

    fetchSettings()
  }, [router])

  const handleEdit = (id: string, value: string) => {
    setEditMode((prev) => ({ ...prev, [id]: true }))
    setEditValues((prev) => ({ ...prev, [id]: value }))
  }

  const handleCancel = (id: string) => {
    setEditMode((prev) => ({ ...prev, [id]: false }))
    setEditValues((prev) => ({ ...prev, [id]: "" }))
  }

  const handleSave = async (id: string, section: string, key: string) => {
    try {
      setSaving((prev) => ({ ...prev, [id]: true }))
      const result = await updateSetting(id, editValues[id])

      if (result) {
        // Update local state
        setSettings((prev) => ({
          ...prev,
          [section]: {
            ...prev[section],
            [key]: editValues[id],
          },
        }))
        setEditMode((prev) => ({ ...prev, [id]: false }))
      }
    } catch (error) {
      console.error("Error saving setting:", error)
    } finally {
      setSaving((prev) => ({ ...prev, [id]: false }))
    }
  }

  const renderSettingItem = (section: string, key: string, value: string) => {
    const id = `${section}_${key}`
    const isMultiline = value && value.length > 50

    return (
      <div key={id} className="mb-4 p-4 bg-white rounded-lg shadow-sm">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h4 className="font-medium text-gray-900">{key}</h4>
            <p className="text-sm text-gray-500">{id}</p>
          </div>
          {!editMode[id] ? (
            <Button variant="ghost" size="sm" onClick={() => handleEdit(id, value)}>
              <Pencil className="h-4 w-4 mr-1" /> Изменить
            </Button>
          ) : (
            <div className="flex space-x-2">
              <Button variant="ghost" size="sm" onClick={() => handleCancel(id)} disabled={saving[id]}>
                <X className="h-4 w-4 mr-1" /> Отмена
              </Button>
              <Button variant="default" size="sm" onClick={() => handleSave(id, section, key)} disabled={saving[id]}>
                {saving[id] ? (
                  <span>Сохранение...</span>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-1" /> Сохранить
                  </>
                )}
              </Button>
            </div>
          )}
        </div>

        {editMode[id] ? (
          isMultiline ? (
            <Textarea
              value={editValues[id]}
              onChange={(e) => setEditValues((prev) => ({ ...prev, [id]: e.target.value }))}
              className="w-full"
              rows={4}
            />
          ) : (
            <Input
              value={editValues[id]}
              onChange={(e) => setEditValues((prev) => ({ ...prev, [id]: e.target.value }))}
              className="w-full"
            />
          )
        ) : (
          <div className="text-gray-700 whitespace-pre-wrap">{value}</div>
        )}
      </div>
    )
  }

  const renderSection = (section: string, values: Record<string, string>) => {
    return (
      <TabsContent value={section} className="p-4">
        <div className="mb-6">
          <h3 className="text-lg font-medium">{section.charAt(0).toUpperCase() + section.slice(1)}</h3>
          <Separator className="my-2" />
        </div>
        {Object.entries(values).map(([key, value]) => renderSettingItem(section, key, value))}
      </TabsContent>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto"></div>
          <p className="mt-4">Загрузка настроек...</p>
        </div>
      </div>
    )
  }

  const sections = Object.keys(settings)

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Настройки сайта</CardTitle>
          <CardDescription>Управление настройками и конфигурацией сайта</CardDescription>
        </CardHeader>
        <CardContent>
          {sections.length > 0 ? (
            <Tabs defaultValue={sections[0]}>
              <TabsList className="mb-4">
                {sections.map((section) => (
                  <TabsTrigger key={section} value={section}>
                    {section.charAt(0).toUpperCase() + section.slice(1)}
                  </TabsTrigger>
                ))}
              </TabsList>
              {sections.map((section) => renderSection(section, settings[section]))}
            </Tabs>
          ) : (
            <div className="text-center py-8">
              <p>Настройки не найдены. Добавьте настройки через API или базу данных.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
