"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"
import { ImageUpload } from "@/components/admin/image-upload"
import { ArrowLeft, Loader2 } from "lucide-react"
import Link from "next/link"

export default function NewSlideshowPage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    subtitle: "",
    image_url: "",
    link_url: "",
    button_text: "",
    is_active: true,
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (checked) => {
    setFormData((prev) => ({ ...prev, is_active: checked }))
  }

  const handleImageUploaded = (url) => {
    console.log("Изображение загружено:", url)
    setFormData((prev) => ({ ...prev, image_url: url }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!formData.image_url) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, загрузите изображение для слайда",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const response = await fetch("/api/slideshows", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: formData.title,
          subtitle: formData.subtitle,
          image_url: formData.image_url,
          link_url: formData.link_url,
          button_text: formData.button_text,
          is_active: formData.is_active,
        }),
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: "Успешно",
          description: "Слайд успешно создан",
          variant: "success",
        })
        router.push("/admin/slideshows")
      } else {
        throw new Error(data.message || "Ошибка при создании слайда")
      }
    } catch (error) {
      console.error("Ошибка при создании слайда:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать слайд",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Новый слайд</h1>
            <p className="text-gray-500">Создание нового слайда для главной страницы</p>
          </div>
          <Button variant="outline" asChild>
            <Link href="/admin/slideshows">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Назад
            </Link>
          </Button>
        </div>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle>Информация о слайде</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Заголовок</Label>
                <Input
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="Введите заголовок слайда"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="subtitle">Подзаголовок</Label>
                <Textarea
                  id="subtitle"
                  name="subtitle"
                  value={formData.subtitle}
                  onChange={handleChange}
                  placeholder="Введите подзаголовок слайда"
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label>Изображение</Label>
                <ImageUpload
                  onImageUploaded={handleImageUploaded}
                  initialImage={formData.image_url}
                  folder="slideshows"
                />
                {!formData.image_url && (
                  <p className="text-sm text-red-500">Пожалуйста, загрузите изображение для слайда</p>
                )}
                {formData.image_url && (
                  <p className="text-sm text-green-500">Изображение загружено: {formData.image_url}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="link_url">Ссылка (URL)</Label>
                <Input
                  id="link_url"
                  name="link_url"
                  value={formData.link_url}
                  onChange={handleChange}
                  placeholder="Например: /catalog/fruits"
                />
                <p className="text-xs text-gray-500">
                  Укажите URL, на который будет вести слайд при клике (необязательно)
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="button_text">Текст кнопки</Label>
                <Input
                  id="button_text"
                  name="button_text"
                  value={formData.button_text}
                  onChange={handleChange}
                  placeholder="Например: Смотреть каталог"
                />
                <p className="text-xs text-gray-500">
                  Укажите текст кнопки, если нужно отображать кнопку на слайде (необязательно)
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="is_active" checked={formData.is_active} onCheckedChange={handleSwitchChange} />
                <Label htmlFor="is_active">Активен</Label>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" asChild>
                <Link href="/admin/slideshows">Отмена</Link>
              </Button>
              <Button type="submit" className="bg-green-600 hover:bg-green-700" disabled={isSubmitting}>
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Сохранение...
                  </span>
                ) : (
                  "Создать слайд"
                )}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </div>
    </AdminLayout>
  )
}
