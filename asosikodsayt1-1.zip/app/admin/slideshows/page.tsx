"use client"

import { useState, useEffect } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import Link from "next/link"
import { Plus, Pencil, Trash2, ArrowUp, ArrowDown, Loader2, GripVertical } from "lucide-react"
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd"

type Slideshow = {
  id: string
  image_url: string
  description?: string
  link?: string
  slide_order: number
  active: boolean
  created_at: string
  updated_at?: string
}

export default function AdminSlideshowsPage() {
  const [slideshows, setSlideshows] = useState<Slideshow[]>([])
  const [loading, setLoading] = useState(true)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [reordering, setReordering] = useState(false)

  useEffect(() => {
    fetchSlideshows()
  }, [])

  const fetchSlideshows = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/slideshows")
      const data = await response.json()

      if (data.success) {
        setSlideshows(data.slideshows || [])
      } else {
        console.error("Ошибка при получении слайдов:", data.message)
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить слайды",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Ошибка при получении слайдов:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить слайды",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleToggleActive = async (id: string, checked: boolean) => {
    try {
      const slideshow = slideshows.find((s) => s.id === id)
      if (!slideshow) return

      const response = await fetch(`/api/slideshows/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...slideshow,
          active: checked,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setSlideshows(slideshows.map((s) => (s.id === id ? { ...s, active: checked } : s)))
        toast({
          title: "Слайд обновлен",
          description: `Слайд ${checked ? "активирован" : "деактивирован"}`,
          variant: "success",
        })
      } else {
        throw new Error(data.message || "Ошибка при обновлении слайда")
      }
    } catch (error) {
      console.error("Ошибка при обновлении слайда:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить слайд",
        variant: "destructive",
      })
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Вы уверены, что хотите удалить этот слайд?")) {
      return
    }

    setDeletingId(id)

    try {
      const response = await fetch(`/api/slideshows/${id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || `Ошибка при удалении: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setSlideshows(slideshows.filter((s) => s.id !== id))
        toast({
          title: "Слайд удален",
          description: "Слайд успешно удален",
          variant: "success",
        })
      } else {
        throw new Error(data.message || "Ошибка при удалении слайда")
      }
    } catch (error) {
      console.error("Ошибка при удалении слайда:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить слайд",
        variant: "destructive",
      })
    } finally {
      setDeletingId(null)
    }
  }

  const handleMoveUp = async (index: number) => {
    if (index <= 0) return

    const newSlideshows = [...slideshows]
    const temp = newSlideshows[index]
    newSlideshows[index] = newSlideshows[index - 1]
    newSlideshows[index - 1] = temp

    // Обновляем порядок
    const slideshowIds = newSlideshows.map((s) => s.id)
    await updateOrder(slideshowIds)
  }

  const handleMoveDown = async (index: number) => {
    if (index >= slideshows.length - 1) return

    const newSlideshows = [...slideshows]
    const temp = newSlideshows[index]
    newSlideshows[index] = newSlideshows[index + 1]
    newSlideshows[index + 1] = temp

    // Обновляем порядок
    const slideshowIds = newSlideshows.map((s) => s.id)
    await updateOrder(slideshowIds)
  }

  const updateOrder = async (slideshowIds: string[]) => {
    setReordering(true)

    try {
      const response = await fetch("/api/slideshows/reorder", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ slideshowIds }),
      })

      const data = await response.json()

      if (data.success) {
        // Обновляем порядок в локальном состоянии
        const newSlideshows = slideshowIds.map((id, index) => {
          const slideshow = slideshows.find((s) => s.id === id)
          return { ...slideshow, slide_order: index + 1 }
        })
        setSlideshows(newSlideshows)
        toast({
          title: "Порядок обновлен",
          description: "Порядок слайдов успешно обновлен",
          variant: "success",
        })
      } else {
        throw new Error(data.message || "Ошибка при обновлении порядка")
      }
    } catch (error) {
      console.error("Ошибка при обновлении порядка:", error)
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить порядок",
        variant: "destructive",
      })
      // Восстанавливаем исходный порядок
      fetchSlideshows()
    } finally {
      setReordering(false)
    }
  }

  const handleDragEnd = (result) => {
    if (!result.destination) return

    const sourceIndex = result.source.index
    const destinationIndex = result.destination.index

    if (sourceIndex === destinationIndex) return

    const newSlideshows = [...slideshows]
    const [removed] = newSlideshows.splice(sourceIndex, 1)
    newSlideshows.splice(destinationIndex, 0, removed)

    setSlideshows(newSlideshows)

    // Обновляем порядок на сервере
    const slideshowIds = newSlideshows.map((s) => s.id)
    updateOrder(slideshowIds)
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Слайд-шоу</h1>
            <p className="text-gray-500">Управление слайдами на главной странице</p>
          </div>
          <Button asChild className="bg-green-600 hover:bg-green-700">
            <Link href="/admin/slideshows/new">
              <Plus className="mr-2 h-4 w-4" />
              Добавить слайд
            </Link>
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center py-8">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-current border-t-transparent text-green-600"></div>
          </div>
        ) : slideshows.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-xl font-medium mb-2">Нет слайдов</p>
            <p className="text-gray-500 mb-6">Добавьте слайды для отображения на главной странице</p>
            <Button asChild className="bg-green-600 hover:bg-green-700">
              <Link href="/admin/slideshows/new">
                <Plus className="mr-2 h-4 w-4" />
                Добавить первый слайд
              </Link>
            </Button>
          </div>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="slideshows">
              {(provided) => (
                <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
                  {slideshows.map((slideshow, index) => (
                    <Draggable key={slideshow.id} draggableId={slideshow.id} index={index}>
                      {(provided) => (
                        <Card
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className={reordering ? "opacity-50" : ""}
                        >
                          <CardHeader className="pb-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div {...provided.dragHandleProps} className="cursor-grab">
                                  <GripVertical className="h-5 w-5 text-gray-400" />
                                </div>
                                <CardTitle className="text-lg">Слайд #{index + 1}</CardTitle>
                              </div>
                              <div className="flex items-center gap-2">
                                <Switch
                                  id={`active-${slideshow.id}`}
                                  checked={slideshow.active}
                                  onCheckedChange={(checked) => handleToggleActive(slideshow.id, checked)}
                                  disabled={reordering}
                                />
                                <Label htmlFor={`active-${slideshow.id}`}>Активен</Label>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="pb-2">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div className="aspect-[16/9] rounded-md overflow-hidden">
                                <img
                                  src={slideshow.image_url || "/placeholder.svg?height=400&width=400"}
                                  alt={slideshow.description || `Слайд ${index + 1}`}
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    e.currentTarget.src = "/placeholder.svg?height=400&width=400"
                                  }}
                                />
                              </div>
                              <div className="md:col-span-2 space-y-2">
                                <div>
                                  <p className="font-medium">Описание:</p>
                                  <p className="text-gray-600">
                                    {slideshow.description || <span className="text-gray-400">Нет описания</span>}
                                  </p>
                                </div>
                                <div>
                                  <p className="font-medium">Ссылка:</p>
                                  <p className="text-gray-600">
                                    {slideshow.link ? (
                                      <a
                                        href={slideshow.link}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-blue-600 hover:underline"
                                      >
                                        {slideshow.link}
                                      </a>
                                    ) : (
                                      <span className="text-gray-400">Нет ссылки</span>
                                    )}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                          <CardFooter className="flex justify-between">
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleMoveUp(index)}
                                disabled={index === 0 || reordering}
                              >
                                <ArrowUp className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleMoveDown(index)}
                                disabled={index === slideshows.length - 1 || reordering}
                              >
                                <ArrowDown className="h-4 w-4" />
                              </Button>
                            </div>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" asChild>
                                <Link href={`/admin/slideshows/${slideshow.id}`}>
                                  <Pencil className="h-4 w-4 mr-1" />
                                  Изменить
                                </Link>
                              </Button>
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleDelete(slideshow.id)}
                                disabled={deletingId === slideshow.id || reordering}
                              >
                                {deletingId === slideshow.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Trash2 className="h-4 w-4 mr-1" />
                                )}
                                Удалить
                              </Button>
                            </div>
                          </CardFooter>
                        </Card>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}
      </div>
    </AdminLayout>
  )
}
