import { supabase } from "./supabase-client"

export type OrderItem = {
  product_id?: string
  product_name: string
  price: number
  quantity: number
  unit: string
  discount?: number
}

export type Order = {
  id?: string
  order_number?: string
  customer_name: string
  customer_phone: string
  customer_address: string
  entrance?: string
  floor?: string
  delivery_type: "door" | "entrance"
  payment_method: "cash" | "online"
  comment?: string
  promo_code?: string
  promo_discount?: number
  subtotal: number
  delivery_fee: number
  total: number
  status?: "new" | "processing" | "delivered" | "cancelled"
  items: OrderItem[]
  created_at?: string
  updated_at?: string
}

// Демо-заказы для резервного режима
const demoOrders: Order[] = []

// Проверка наличия таблицы orders
async function checkOrdersTableExists(): Promise<boolean> {
  try {
    // Проверяем, существует ли таблица orders
    const { error } = await supabase.from("orders").select("id").limit(1)

    if (error && error.code === "42P01") {
      console.log("Таблица orders не существует")
      return false
    }

    return true
  } catch (error) {
    console.error("Ошибка при проверке таблицы orders:", error)
    return false
  }
}

// Проверка наличия таблицы order_items
async function checkOrderItemsTableExists(): Promise<boolean> {
  try {
    // Проверяем, существует ли таблица order_items
    const { error } = await supabase.from("order_items").select("id").limit(1)

    if (error && error.code === "42P01") {
      console.log("Таблица order_items не существует")
      return false
    }

    return true
  } catch (error) {
    console.error("Ошибка при проверке таблицы order_items:", error)
    return false
  }
}

// Create a new order
export async function createOrder(order: Order): Promise<Order | null> {
  try {
    // Проверяем наличие таблиц
    const ordersTableExists = await checkOrdersTableExists()
    const orderItemsTableExists = await checkOrderItemsTableExists()

    if (!ordersTableExists || !orderItemsTableExists) {
      console.warn("Таблицы для заказов не существуют, используем демо-режим")

      // Создаем демо-заказ
      const demoOrder: Order = {
        ...order,
        id: crypto.randomUUID(),
        order_number: order.order_number || Math.floor(1000 + Math.random() * 9000).toString(),
        status: order.status || "new",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      demoOrders.push(demoOrder)
      return demoOrder
    }

    const { items, ...orderData } = order

    // Prepare order data for insertion
    const orderInsertData = {
      order_number: orderData.order_number || Math.floor(1000 + Math.random() * 9000).toString(),
      customer_name: orderData.customer_name,
      customer_phone: orderData.customer_phone,
      customer_address: orderData.customer_address,
      entrance: orderData.entrance || null,
      floor: orderData.floor || null,
      delivery_type: orderData.delivery_type || "door",
      payment_method: orderData.payment_method || "cash",
      comment: orderData.comment || null,
      promo_code: orderData.promo_code || null,
      promo_discount: orderData.promo_discount || 0,
      subtotal: orderData.subtotal,
      delivery_fee: orderData.delivery_fee,
      total: orderData.total,
      status: orderData.status || "new",
    }

    console.log("Attempting to insert order with data:", JSON.stringify(orderInsertData, null, 2))

    // Insert the order
    const { data: createdOrder, error: orderError } = await supabase.from("orders").insert([orderInsertData]).select()

    if (orderError) {
      console.error("Error creating order:", orderError)

      // Создаем демо-заказ в случае ошибки
      const demoOrder: Order = {
        ...order,
        id: crypto.randomUUID(),
        order_number: order.order_number || Math.floor(1000 + Math.random() * 9000).toString(),
        status: order.status || "new",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      demoOrders.push(demoOrder)
      return demoOrder
    }

    if (!createdOrder || createdOrder.length === 0) {
      console.error("Failed to create order, no data returned")

      // Создаем демо-заказ в случае ошибки
      const demoOrder: Order = {
        ...order,
        id: crypto.randomUUID(),
        order_number: order.order_number || Math.floor(1000 + Math.random() * 9000).toString(),
        status: order.status || "new",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      demoOrders.push(demoOrder)
      return demoOrder
    }

    const newOrder = createdOrder[0]
    console.log("Order created successfully:", newOrder.id)

    // Insert order items
    if (items && items.length > 0) {
      try {
        const orderItemsToInsert = items.map((item) => ({
          order_id: newOrder.id,
          product_id: item.product_id || null,
          product_name: item.product_name,
          price: item.price,
          quantity: item.quantity,
          unit: item.unit,
          discount: item.discount || null,
        }))

        console.log("Inserting order items:", JSON.stringify(orderItemsToInsert, null, 2))

        const { error: itemsError } = await supabase.from("order_items").insert(orderItemsToInsert)

        if (itemsError) {
          console.error("Error creating order items:", itemsError)
          // We'll continue even if items insertion fails
        }
      } catch (itemsError) {
        console.error("Exception when creating order items:", itemsError)
        // Continue anyway, we at least have the order
      }
    }

    return { ...newOrder, items } as Order
  } catch (error) {
    console.error("Exception when creating order:", error)

    // Создаем демо-заказ в случае ошибки
    const demoOrder: Order = {
      ...order,
      id: crypto.randomUUID(),
      order_number: order.order_number || Math.floor(1000 + Math.random() * 9000).toString(),
      status: order.status || "new",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    demoOrders.push(demoOrder)
    return demoOrder
  }
}

// Get order by order number
export async function getOrderByNumber(orderNumber: string): Promise<Order | null> {
  try {
    // Проверяем наличие таблиц
    const ordersTableExists = await checkOrdersTableExists()
    const orderItemsTableExists = await checkOrderItemsTableExists()

    if (!ordersTableExists || !orderItemsTableExists) {
      console.warn("Таблицы для заказов не существуют, используем демо-режим")
      const order = demoOrders.find((o) => o.order_number === orderNumber)
      return order || null
    }

    const { data: orders, error } = await supabase.from("orders").select("*").eq("order_number", orderNumber).single()

    if (error) {
      console.error("Error fetching order:", error)
      const order = demoOrders.find((o) => o.order_number === orderNumber)
      return order || null
    }

    if (!orders) {
      const order = demoOrders.find((o) => o.order_number === orderNumber)
      return order || null
    }

    const { data: items, error: itemsError } = await supabase.from("order_items").select("*").eq("order_id", orders.id)

    if (itemsError) {
      console.error("Error fetching items for order:", itemsError)
      return { ...orders, items: [] } as Order
    }

    return { ...orders, items } as Order
  } catch (error) {
    console.error("Exception when fetching order:", error)
    const order = demoOrders.find((o) => o.order_number === orderNumber)
    return order || null
  }
}

// Get orders by phone number
export async function getOrdersByPhone(phone: string): Promise<Order[]> {
  try {
    // Проверяем наличие таблиц
    const ordersTableExists = await checkOrdersTableExists()
    const orderItemsTableExists = await checkOrderItemsTableExists()

    if (!ordersTableExists || !orderItemsTableExists) {
      console.warn("Таблицы для заказов не существуют, используем демо-режим")
      return demoOrders.filter((o) => o.customer_phone === phone)
    }

    const { data: orders, error } = await supabase
      .from("orders")
      .select("*")
      .eq("customer_phone", phone)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching orders:", error)
      return demoOrders.filter((o) => o.customer_phone === phone)
    }

    if (!orders || orders.length === 0) {
      return demoOrders.filter((o) => o.customer_phone === phone)
    }

    // Get all order IDs
    const orderIds = orders.map((order) => order.id)

    // Get all order items for these orders
    const { data: allItems, error: itemsError } = await supabase
      .from("order_items")
      .select("*")
      .in("order_id", orderIds)

    if (itemsError) {
      console.error("Error fetching items for orders:", itemsError)
      return orders.map((order) => ({ ...order, items: [] }) as Order)
    }

    // Combine orders with their items
    const completeOrders = orders.map((order) => ({
      ...order,
      items: allItems.filter((item) => item.order_id === order.id) || [],
    }))

    return completeOrders as Order[]
  } catch (error) {
    console.error("Exception when fetching orders:", error)
    return demoOrders.filter((o) => o.customer_phone === phone)
  }
}
