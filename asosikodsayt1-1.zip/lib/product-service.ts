import { supabase } from "./supabase-client"
import { generateSlug } from "./slug-utils"

export type Product = {
  id: string
  name: string
  price: number
  description: string
  category: string
  unit: string
  discount?: number
  images: string[]
  origin: string
  weight?: number
  volume?: number
  min_quantity?: number
  max_quantity?: number
  step?: number
  active?: boolean
  on_homepage?: boolean
  seo_title?: string
  seo_description?: string
  created_at?: string
  updated_at?: string
  slug?: string
}

// Демо-продукты для резервного режима
const demoProducts: Product[] = [
  {
    id: "1",
    name: "Яблоки Голден",
    price: 159,
    description:
      "Сочные и сладкие яблоки сорта Голден. Идеально подходят для употребления в свежем виде, а также для приготовления десертов и выпечки.",
    category: "fruits",
    unit: "кг",
    discount: 15,
    images: ["/placeholder.svg?height=400&width=400"],
    origin: "Краснодарский край",
    weight: 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    min_quantity: 0.1,
    max_quantity: 10,
    step: 0.1,
    active: true,
    on_homepage: true,
    seo_title: "Яблоки Голден - свежие фрукты с доставкой в Челябинске | OLUCHA",
    seo_description:
      "Купить свежие яблоки Голден с доставкой по Челябинску. Высокое качество, доступные цены, быстрая доставка за 60 минут.",
    slug: "yabloki-golden",
  },
  {
    id: "2",
    name: "Бананы",
    price: 129,
    description: "Спелые и сладкие бананы. Богаты калием и другими полезными веществами.",
    category: "fruits",
    unit: "кг",
    images: ["/placeholder.svg?height=400&width=400"],
    origin: "Эквадор",
    weight: 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    min_quantity: 0.1,
    max_quantity: 10,
    step: 0.1,
    active: true,
    on_homepage: true,
    seo_title: "Бананы - свежие фрукты с доставкой в Челябинске | OLUCHA",
    seo_description:
      "Купить свежие бананы с доставкой по Челябинску. Высокое качество, доступные цены, быстрая доставка за 60 минут.",
    slug: "banany",
  },
]

// Функция для подсчета товаров на главной странице
export async function countHomepageProducts(): Promise<number> {
  try {
    // Сначала пытаемся получить продукты из Supabase
    const { data, error } = await supabase.from("products").select("id").eq("active", true).eq("on_homepage", true)

    if (error) {
      console.warn("Ошибка при получении товаров из Supabase:", error)
      // Если не удалось получить из Supabase, считаем локальные данные
      return demoProducts.filter((p) => p.active && p.on_homepage).length
    }

    if (data) {
      return data.length
    }

    // Если в Supabase нет данных, возвращаем количество локальных
    return demoProducts.filter((p) => p.active && p.on_homepage).length
  } catch (error) {
    console.error("Исключение при подсчете товаров на главной:", error)
    // В случае ошибки возвращаем количество локальных данных
    return demoProducts.filter((p) => p.active && p.on_homepage).length
  }
}

// Функции для работы с продуктами
export async function getProducts(): Promise<Product[]> {
  try {
    // Сначала пытаемся получить продукты из Supabase
    const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false })

    if (error) {
      console.warn("Ошибка при получении продуктов из Supabase:", error)
      // Если не удалось получить из Supabase, возвращаем локальные данные
      return demoProducts
    }

    if (data && data.length > 0) {
      // Убедимся, что у всех продуктов есть slug
      const productsWithSlug = data.map((product) => {
        if (!product.slug) {
          product.slug = generateSlug(product.name)
        }
        return product
      })
      return productsWithSlug
    }

    // Если в Supabase нет данных, возвращаем локальные
    return demoProducts
  } catch (error) {
    console.error("Исключение при получении продуктов:", error)
    // В случае ошибки возвращаем локальные данные
    return demoProducts
  }
}

export async function getProductById(id: string): Promise<Product | null> {
  try {
    // Сначала пытаемся получить продукт из Supabase
    const { data, error } = await supabase.from("products").select("*").eq("id", id).single()

    if (error) {
      console.warn(`Ошибка при получении продукта с ID ${id} из Supabase:`, error)
      // Если не удалось получить из Supabase, ищем в локальных данных
      const product = demoProducts.find((p) => p.id === id)
      return product || null
    }

    // Убедимся, что у продукта есть slug
    if (data && !data.slug) {
      data.slug = generateSlug(data.name)
    }

    return data
  } catch (error) {
    console.error(`Исключение при получении продукта с ID ${id}:`, error)
    // В случае ошибки ищем в локальных данных
    const product = demoProducts.find((p) => p.id === id)
    return product || null
  }
}

// Новая функция для получения продукта по slug
export async function getProductBySlug(slug: string): Promise<Product | null> {
  try {
    // Пытаемся получить продукт из Supabase по slug
    const { data, error } = await supabase.from("products").select("*").eq("slug", slug).single()

    if (error) {
      console.warn(`Ошибка при получении продукта со slug ${slug} из Supabase:`, error)
      // Если не удалось получить из Supabase, ищем в локальных данных
      const product = demoProducts.find((p) => p.slug === slug)
      return product || null
    }

    return data
  } catch (error) {
    console.error(`Исключение при получении продукта со slug ${slug}:`, error)
    // В случае ошибки ищем в локальных данных
    const product = demoProducts.find((p) => p.slug === slug)
    return product || null
  }
}

export async function createProduct(product: Omit<Product, "id" | "created_at" | "updated_at">): Promise<Product> {
  try {
    // Проверяем, можно ли добавить товар на главную страницу
    if (product.on_homepage) {
      const homepageCount = await countHomepageProducts()
      if (homepageCount >= 8) {
        console.warn("Превышен лимит товаров на главной странице (8), товар будет создан без флага on_homepage")
        product.on_homepage = false
      }
    }

    // Генерируем уникальный ID для продукта
    const productId = crypto.randomUUID()

    // Генерируем slug, если его нет
    if (!product.slug) {
      product.slug = generateSlug(product.name)
    }

    // Создаем новый продукт с текущей датой
    const newProduct: Product = {
      ...product,
      id: productId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    // Пытаемся сохранить в Supabase
    const { data, error } = await supabase.from("products").insert([newProduct]).select()

    if (error) {
      console.warn("Ошибка при создании продукта в Supabase:", error)
      // Если не удалось сохранить в Supabase, сохраняем локально
      demoProducts.push(newProduct)
      return newProduct
    }

    // Если данные успешно вставлены, возвращаем первый элемент
    if (data && data.length > 0) {
      return data[0]
    }

    // Если нет данных от Supabase, возвращаем локальный объект
    demoProducts.push(newProduct)
    return newProduct
  } catch (error) {
    console.error("Исключение при создании продукта:", error)
    // В случае ошибки сохраняем локально
    const newProduct: Product = {
      ...product,
      id: crypto.randomUUID(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      slug: product.slug || generateSlug(product.name),
    }
    demoProducts.push(newProduct)
    return newProduct
  }
}

export async function updateProduct(id: string, product: Partial<Product>): Promise<Product | null> {
  try {
    // Проверяем, можно ли добавить товар на главную страницу
    if (product.on_homepage) {
      // Получаем текущий продукт
      const currentProduct = await getProductById(id)

      // Если товар раньше не был на главной, проверяем лимит
      if (currentProduct && !currentProduct.on_homepage) {
        const homepageCount = await countHomepageProducts()
        if (homepageCount >= 8) {
          console.warn("Превышен лимит товаров на главной странице (8), товар будет обновлен без флага on_homepage")
          product.on_homepage = false
        }
      }
    }

    // Если изменилось название, обновляем slug (если он не задан явно)
    if (product.name && !product.slug) {
      const currentProduct = await getProductById(id)
      if (currentProduct && currentProduct.name !== product.name) {
        product.slug = generateSlug(product.name)
      }
    }

    // Обновляем дату изменения
    const updateData = {
      ...product,
      updated_at: new Date().toISOString(),
    }

    // Пытаемся обновить в Supabase
    const { data, error } = await supabase.from("products").update(updateData).eq("id", id).select()

    if (error) {
      console.warn(`Ошибка при обновлении продукта с ID ${id} в Supabase:`, error)
      // Если не удалось обновить в Supabase, обновляем локально
      const index = demoProducts.findIndex((p) => p.id === id)
      if (index === -1) return null

      demoProducts[index] = {
        ...demoProducts[index],
        ...updateData,
      }

      return demoProducts[index]
    }

    // Если данные успешно обновлены, возвращаем первый элемент
    if (data && data.length > 0) {
      // Обновляем локальную копию для синхронизации
      const index = demoProducts.findIndex((p) => p.id === id)
      if (index !== -1) {
        demoProducts[index] = data[0]
      }
      return data[0]
    }

    // Если нет данных от Supabase, возвращаем null
    return null
  } catch (error) {
    console.error(`Исключение при обновлении продукта с ID ${id}:`, error)
    // В случае ошибки обновляем локально
    const index = demoProducts.findIndex((p) => p.id === id)
    if (index === -1) return null

    demoProducts[index] = {
      ...demoProducts[index],
      ...product,
      updated_at: new Date().toISOString(),
    }

    return demoProducts[index]
  }
}

export async function deleteProduct(id: string): Promise<boolean> {
  try {
    // Пытаемся удалить из Supabase
    const { error } = await supabase.from("products").delete().eq("id", id)

    if (error) {
      console.warn(`Ошибка при удалении продукта с ID ${id} из Supabase:`, error)
      // Если не удалось удалить из Supabase, удаляем локально
      const initialLength = demoProducts.length
      const newDemoProducts = demoProducts.filter((p) => p.id !== id)
      demoProducts.length = 0
      demoProducts.push(...newDemoProducts)
      return demoProducts.length < initialLength
    }

    // Удаляем также из локального массива для синхронизации
    const initialLength = demoProducts.length
    const newDemoProducts = demoProducts.filter((p) => p.id !== id)
    demoProducts.length = 0
    demoProducts.push(...newDemoProducts)

    return true
  } catch (error) {
    console.error(`Исключение при удалении продукта с ID ${id}:`, error)
    // В случае ошибки удаляем локально
    const initialLength = demoProducts.length
    const newDemoProducts = demoProducts.filter((p) => p.id !== id)
    demoProducts.length = 0
    demoProducts.push(...newDemoProducts)
    return demoProducts.length < initialLength
  }
}

// Функция для проверки уникальности slug
export async function isSlugUnique(slug: string, excludeId?: string): Promise<boolean> {
  try {
    let query = supabase.from("products").select("id").eq("slug", slug)

    if (excludeId) {
      query = query.neq("id", excludeId)
    }

    const { data, error } = await query

    if (error) {
      console.warn(`Ошибка при проверке уникальности slug ${slug}:`, error)
      // Проверяем в локальных данных
      const existingProduct = demoProducts.find((p) => p.slug === slug && p.id !== excludeId)
      return !existingProduct
    }

    return data.length === 0
  } catch (error) {
    console.error(`Исключение при проверке уникальности slug ${slug}:`, error)
    // Проверяем в локальных данных
    const existingProduct = demoProducts.find((p) => p.slug === slug && p.id !== excludeId)
    return !existingProduct
  }
}
