import { createClient } from "@/lib/supabase-client"
import type { DeliveryZone, DeliveryInfo } from "@/types/delivery"

export async function getAllDeliveryZones(): Promise<DeliveryZone[]> {
  try {
    const supabase = createClient()

    const { data, error } = await supabase.from("delivery_zones").select("*").order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching delivery zones:", error)
      throw new Error(error.message)
    }

    return data || []
  } catch (error) {
    console.error("Error in getAllDeliveryZones:", error)
    throw error
  }
}

export async function getDeliveryZoneById(id: number): Promise<DeliveryZone | null> {
  try {
    const supabase = createClient()

    const { data, error } = await supabase.from("delivery_zones").select("*").eq("id", id).single()

    if (error) {
      if (error.code === "PGRST116") {
        // No rows returned
        return null
      }
      console.error("Error fetching delivery zone:", error)
      throw new Error(error.message)
    }

    return data
  } catch (error) {
    console.error("Error in getDeliveryZoneById:", error)
    throw error
  }
}

export async function createDeliveryZone(zone: Partial<DeliveryZone>): Promise<DeliveryZone> {
  try {
    const supabase = createClient()

    const { data, error } = await supabase
      .from("delivery_zones")
      .insert([
        {
          name: zone.name,
          type: zone.type,
          coordinates: zone.coordinates,
          center: zone.center,
          radius: zone.radius,
          base_fee: zone.base_fee || 0,
          min_order_amount: zone.min_order_amount || 0,
          free_delivery_threshold: zone.free_delivery_threshold || null,
          per_km_fee: zone.per_km_fee || 0,
          color: zone.color || "#FF5733",
          active: zone.active !== undefined ? zone.active : true,
        },
      ])
      .select()

    if (error) {
      console.error("Error creating delivery zone:", error)
      throw new Error(error.message)
    }

    return data[0]
  } catch (error) {
    console.error("Error in createDeliveryZone:", error)
    throw error
  }
}

export async function updateDeliveryZone(id: number, zone: Partial<DeliveryZone>): Promise<DeliveryZone> {
  try {
    const supabase = createClient()

    const { data, error } = await supabase
      .from("delivery_zones")
      .update({
        name: zone.name,
        type: zone.type,
        coordinates: zone.coordinates,
        center: zone.center,
        radius: zone.radius,
        base_fee: zone.base_fee,
        min_order_amount: zone.min_order_amount,
        free_delivery_threshold: zone.free_delivery_threshold,
        per_km_fee: zone.per_km_fee,
        color: zone.color,
        active: zone.active,
      })
      .eq("id", id)
      .select()

    if (error) {
      console.error("Error updating delivery zone:", error)
      throw new Error(error.message)
    }

    return data[0]
  } catch (error) {
    console.error("Error in updateDeliveryZone:", error)
    throw error
  }
}

export async function deleteDeliveryZone(id: number): Promise<void> {
  try {
    const supabase = createClient()

    const { error } = await supabase.from("delivery_zones").delete().eq("id", id)

    if (error) {
      console.error("Error deleting delivery zone:", error)
      throw new Error(error.message)
    }
  } catch (error) {
    console.error("Error in deleteDeliveryZone:", error)
    throw error
  }
}

// Helper function to calculate if a point is inside a polygon
function isPointInPolygon(point: [number, number], polygon: [number, number][]): boolean {
  const [x, y] = point
  let inside = false

  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const [xi, yi] = polygon[i]
    const [xj, yj] = polygon[j]

    const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi
    if (intersect) inside = !inside
  }

  return inside
}

// Helper function to calculate distance between two points in kilometers
function calculateDistance(point1: [number, number], point2: [number, number]): number {
  const [lat1, lon1] = point1
  const [lat2, lon2] = point2

  const R = 6371 // Radius of the earth in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLon = ((lon2 - lon1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const distance = R * c // Distance in km

  return distance
}

export async function calculateDeliveryFee(
  coordinates: [number, number],
  storeCoordinates: [number, number],
  orderAmount: number,
): Promise<DeliveryInfo> {
  try {
    // Get all active delivery zones
    const supabase = createClient()

    const { data: zones, error } = await supabase.from("delivery_zones").select("*").eq("active", true)

    if (error) {
      console.error("Error fetching delivery zones:", error)
      throw new Error(error.message)
    }

    // Calculate distance from store to delivery point
    const distance = calculateDistance(storeCoordinates, coordinates)

    // Find the delivery zone that contains the point
    let matchingZone: DeliveryZone | null = null

    for (const zone of zones) {
      if (zone.type === "circle" && zone.center) {
        const zoneCenter: [number, number] = [zone.center.lat, zone.center.lng]
        const distanceToCenter = calculateDistance(zoneCenter, coordinates)

        if (distanceToCenter <= (zone.radius || 0) / 1000) {
          // Convert radius from meters to km
          matchingZone = zone
          break
        }
      } else if (zone.type === "polygon" && zone.coordinates && zone.coordinates.length > 0) {
        if (isPointInPolygon(coordinates, zone.coordinates)) {
          matchingZone = zone
          break
        }
      }
    }

    if (!matchingZone) {
      return {
        isDeliveryAvailable: false,
        deliveryFee: 0,
        minOrderAmount: 0,
        message: "Доставка по этому адресу недоступна",
        distance: distance,
        zone: null,
      }
    }

    // Check if order meets minimum amount
    if (orderAmount < matchingZone.min_order_amount) {
      return {
        isDeliveryAvailable: false,
        deliveryFee: 0,
        minOrderAmount: matchingZone.min_order_amount,
        message: `Минимальная сумма заказа для этой зоны: ${matchingZone.min_order_amount} ₽`,
        distance: distance,
        zone: matchingZone,
      }
    }

    // Check if order qualifies for free delivery
    if (matchingZone.free_delivery_threshold && orderAmount >= matchingZone.free_delivery_threshold) {
      return {
        isDeliveryAvailable: true,
        deliveryFee: 0,
        minOrderAmount: matchingZone.min_order_amount,
        message: "Бесплатная доставка",
        distance: distance,
        zone: matchingZone,
      }
    }

    // Calculate delivery fee
    let deliveryFee = matchingZone.base_fee

    // Add per km fee if applicable
    if (matchingZone.per_km_fee > 0) {
      deliveryFee += Math.ceil(distance) * matchingZone.per_km_fee
    }

    return {
      isDeliveryAvailable: true,
      deliveryFee: deliveryFee,
      minOrderAmount: matchingZone.min_order_amount,
      message: `Стоимость доставки: ${deliveryFee} ₽`,
      distance: distance,
      zone: matchingZone,
    }
  } catch (error) {
    console.error("Error calculating delivery fee:", error)
    throw error
  }
}
