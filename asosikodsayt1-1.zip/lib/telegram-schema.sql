-- Создание таблицы telegram_users
CREATE TABLE IF NOT EXISTS telegram_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone_number TEXT UNIQUE NOT NULL,
  telegram_chat_id BIGINT UNIQUE,
  is_subscribed BOOLEAN DEFAULT true,
  auth_code TEXT,
  auth_code_expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Создание индексов для быстрого поиска
CREATE INDEX IF NOT EXISTS idx_telegram_users_phone_number ON telegram_users(phone_number);
CREATE INDEX IF NOT EXISTS idx_telegram_users_telegram_chat_id ON telegram_users(telegram_chat_id);
