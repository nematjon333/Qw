import { supabase } from "./supabase-client"

// Check if admin is authenticated
export function isAdminAuthenticated(): boolean {
  if (typeof window === "undefined") return false
  return localStorage.getItem("admin_authenticated") === "true"
}

// Admin login
export async function adminLogin(username: string, password: string): Promise<boolean> {
  // Use the credentials provided by the user
  if (username === "nematjon_33" && password === "Nematzon@gmail.com2") {
    if (typeof window !== "undefined") {
      localStorage.setItem("admin_authenticated", "true")
    }
    return true
  }
  return false
}

// Admin logout
export function adminLogout(): void {
  if (typeof window !== "undefined") {
    localStorage.removeItem("admin_authenticated")
  }
}

// Проверка существования таблицы
async function checkTableExists(tableName: string): Promise<boolean> {
  try {
    const { error } = await supabase.from(tableName).select("id").limit(1)

    if (error && error.code === "42P01") {
      console.log(`Таблица ${tableName} не существует`)
      return false
    }

    return true
  } catch (error) {
    console.error(`Ошибка при проверке таблицы ${tableName}:`, error)
    return false
  }
}

// Get promo codes
export async function getPromoCodes() {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists("promo_codes")
    if (!tableExists) {
      console.log("Таблица promo_codes не существует, возвращаем пустой массив")
      return []
    }

    const { data, error } = await supabase.from("promo_codes").select("*").order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching promo codes:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("Exception when fetching promo codes:", error)
    return []
  }
}

// Get delivery zones
export async function getDeliveryZones() {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists("delivery_zones")
    if (!tableExists) {
      console.log("Таблица delivery_zones не существует, возвращаем пустой массив")
      return []
    }

    const { data, error } = await supabase.from("delivery_zones").select("*").order("distance_km", { ascending: true })

    if (error) {
      console.error("Error fetching delivery zones:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("Exception when fetching delivery zones:", error)
    return []
  }
}

// Get site settings
export async function getSiteSettings() {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists("site_settings")
    if (!tableExists) {
      console.log("Таблица site_settings не существует, возвращаем пустой массив")
      return []
    }

    const { data, error } = await supabase.from("site_settings").select("*")

    if (error) {
      console.error("Error fetching site settings:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("Exception when fetching site settings:", error)
    return []
  }
}

// Update site setting
export async function updateSiteSetting(id: string, value: string) {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists("site_settings")
    if (!tableExists) {
      console.log("Таблица site_settings не существует, возвращаем null")
      return null
    }

    const { data, error } = await supabase
      .from("site_settings")
      .update({ value, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()

    if (error) {
      console.error("Error updating site setting:", error)
      return null
    }

    return data[0] || null
  } catch (error) {
    console.error("Exception when updating site setting:", error)
    return null
  }
}

// Get orders
export async function getOrders() {
  try {
    // Проверяем существование таблицы orders
    const ordersTableExists = await checkTableExists("orders")
    if (!ordersTableExists) {
      console.log("Таблица orders не существует, возвращаем пустой массив")
      return []
    }

    // Get orders
    const { data: orders, error: ordersError } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false })

    if (ordersError) {
      console.error("Error fetching orders:", ordersError)
      return []
    }

    if (!orders || orders.length === 0) {
      return []
    }

    // Проверяем существование таблицы order_items
    const orderItemsTableExists = await checkTableExists("order_items")
    if (!orderItemsTableExists) {
      console.log("Таблица order_items не существует, возвращаем заказы без товаров")
      return orders.map((order) => ({ ...order, items: [] }))
    }

    // Get all order IDs
    const orderIds = orders.map((order) => order.id)

    // Get all order items for these orders
    const { data: allItems, error: itemsError } = await supabase
      .from("order_items")
      .select("*")
      .in("order_id", orderIds)

    if (itemsError) {
      console.error("Error fetching items for orders:", itemsError)
      return orders.map((order) => ({ ...order, items: [] }))
    }

    // Combine orders with their items
    const completeOrders = orders.map((order) => ({
      ...order,
      items: allItems.filter((item) => item.order_id === order.id) || [],
    }))

    return completeOrders
  } catch (error) {
    console.error("Exception when fetching orders:", error)
    return []
  }
}

// Update order status
export async function updateOrderStatus(id: string, status: string) {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists("orders")
    if (!tableExists) {
      console.log("Таблица orders не существует, возвращаем null")
      return null
    }

    const { data, error } = await supabase
      .from("orders")
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()

    if (error) {
      console.error(`Error updating status for order with ID ${id}:`, error)
      return null
    }

    return data[0] || null
  } catch (error) {
    console.error(`Exception when updating status for order with ID ${id}:`, error)
    return null
  }
}

// Get customers
export async function getCustomers() {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists("customers")
    if (!tableExists) {
      console.log("Таблица customers не существует, возвращаем пустой массив")
      return []
    }

    const { data, error } = await supabase.from("customers").select("*").order("updated_at", { ascending: false })

    if (error) {
      console.error("Error fetching customers:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("Exception when fetching customers:", error)
    return []
  }
}
