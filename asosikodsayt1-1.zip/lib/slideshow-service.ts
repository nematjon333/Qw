import { supabase } from "./supabase-client"

export type Slideshow = {
  id: string
  image_url: string
  description?: string
  link?: string
  slide_order: number
  active: boolean
  created_at: string
  updated_at?: string
  title?: string
  subtitle?: string
  link_url?: string
  button_text?: string
  position?: number
  is_active?: boolean
}

// Проверка существования таблицы
async function checkTableExists(): Promise<boolean> {
  try {
    const { error } = await supabase.from("slideshows").select("id").limit(1)

    if (error && error.code === "42P01") {
      console.log("Таблица slideshows не существует")
      return false
    }

    return true
  } catch (error) {
    console.error("Ошибка при проверке таблицы slideshows:", error)
    return false
  }
}

// Получение всех слайдов
export async function getSlideshows(): Promise<Slideshow[]> {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists()
    if (!tableExists) {
      console.log("Таблица slideshows не существует, возвращаем пустой массив")
      return []
    }

    const { data, error } = await supabase.from("slideshows").select("*").order("slide_order", { ascending: true })

    if (error) {
      console.error("Ошибка при получении слайдов:", error)
      return []
    }

    // Преобразуем данные для совместимости
    const slideshows = data.map((item) => ({
      id: item.id,
      image_url: item.image_url,
      description: item.description || item.subtitle,
      link: item.link || item.link_url,
      slide_order: item.slide_order || item.position || 0,
      active: item.active !== undefined ? item.active : item.is_active !== undefined ? item.is_active : true,
      created_at: item.created_at,
      updated_at: item.updated_at,
      title: item.title,
      subtitle: item.subtitle,
      link_url: item.link_url,
      button_text: item.button_text,
      position: item.position,
      is_active: item.is_active,
    }))

    return slideshows || []
  } catch (error) {
    console.error("Исключение при получении слайдов:", error)
    return []
  }
}

// Получение слайда по ID
export async function getSlideshow(id: string): Promise<Slideshow | null> {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists()
    if (!tableExists) {
      console.log("Таблица slideshows не существует, возвращаем null")
      return null
    }

    const { data, error } = await supabase.from("slideshows").select("*").eq("id", id).single()

    if (error) {
      console.error(`Ошибка при получении слайда с ID ${id}:`, error)
      return null
    }

    // Преобразуем данные для совместимости
    const slideshow = {
      id: data.id,
      image_url: data.image_url,
      description: data.description || data.subtitle,
      link: data.link || data.link_url,
      slide_order: data.slide_order || data.position || 0,
      active: data.active !== undefined ? data.active : data.is_active !== undefined ? data.is_active : true,
      created_at: data.created_at,
      updated_at: data.updated_at,
      title: data.title,
      subtitle: data.subtitle,
      link_url: data.link_url,
      button_text: data.button_text,
      position: data.position,
      is_active: data.is_active,
    }

    return slideshow
  } catch (error) {
    console.error(`Исключение при получении слайда с ID ${id}:`, error)
    return null
  }
}

// Создание нового слайда
export async function createSlideshow(slideshow: Omit<Slideshow, "id" | "created_at">): Promise<Slideshow | null> {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists()
    if (!tableExists) {
      console.log("Таблица slideshows не существует, возвращаем null")
      return null
    }

    // Получаем максимальный порядок слайда
    const { data: maxOrderData, error: maxOrderError } = await supabase
      .from("slideshows")
      .select("slide_order")
      .order("slide_order", { ascending: false })
      .limit(1)

    let maxOrder = 0
    if (!maxOrderError && maxOrderData && maxOrderData.length > 0) {
      maxOrder = maxOrderData[0].slide_order || 0
    }

    // Создаем новый слайд с порядком на 1 больше максимального
    const newSlideshow = {
      image_url: slideshow.image_url,
      description: slideshow.description,
      link_url: slideshow.link || slideshow.link_url,
      title: slideshow.title || "",
      subtitle: slideshow.subtitle || slideshow.description,
      button_text: slideshow.button_text || "Подробнее",
      slide_order: slideshow.slide_order || maxOrder + 1,
      is_active:
        slideshow.active !== undefined
          ? slideshow.active
          : slideshow.is_active !== undefined
            ? slideshow.is_active
            : true,
      created_at: new Date().toISOString(),
    }

    const { data, error } = await supabase.from("slideshows").insert([newSlideshow]).select()

    if (error) {
      console.error("Ошибка при создании слайда:", error)
      return null
    }

    // Преобразуем данные для совместимости
    const createdSlideshow = data[0]
      ? {
          id: data[0].id,
          image_url: data[0].image_url,
          description: data[0].description || data[0].subtitle,
          link: data[0].link || data[0].link_url,
          slide_order: data[0].slide_order || data[0].position || 0,
          active:
            data[0].active !== undefined ? data[0].active : data[0].is_active !== undefined ? data[0].is_active : true,
          created_at: data[0].created_at,
          updated_at: data[0].updated_at,
          title: data[0].title,
          subtitle: data[0].subtitle,
          link_url: data[0].link_url,
          button_text: data[0].button_text,
          position: data[0].position,
          is_active: data[0].is_active,
        }
      : null

    return createdSlideshow
  } catch (error) {
    console.error("Исключение при создании слайда:", error)
    return null
  }
}

// Обновление слайда
export async function updateSlideshow(
  id: string,
  slideshow: Partial<Omit<Slideshow, "id" | "created_at">>,
): Promise<Slideshow | null> {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists()
    if (!tableExists) {
      console.log("Таблица slideshows не существует, возвращаем null")
      return null
    }

    const updateData = {
      image_url: slideshow.image_url,
      description: slideshow.description,
      link_url: slideshow.link || slideshow.link_url,
      title: slideshow.title,
      subtitle: slideshow.subtitle,
      button_text: slideshow.button_text,
      slide_order: slideshow.slide_order || slideshow.position,
      is_active: slideshow.active !== undefined ? slideshow.active : slideshow.is_active,
      updated_at: new Date().toISOString(),
    }

    // Удаляем undefined поля
    Object.keys(updateData).forEach((key) => updateData[key] === undefined && delete updateData[key])

    const { data, error } = await supabase.from("slideshows").update(updateData).eq("id", id).select()

    if (error) {
      console.error(`Ошибка при обновлении слайда с ID ${id}:`, error)
      return null
    }

    // Преобразуем данные для совместимости
    const updatedSlideshow = data[0]
      ? {
          id: data[0].id,
          image_url: data[0].image_url,
          description: data[0].description || data[0].subtitle,
          link: data[0].link || data[0].link_url,
          slide_order: data[0].slide_order || data[0].position || 0,
          active:
            data[0].active !== undefined ? data[0].active : data[0].is_active !== undefined ? data[0].is_active : true,
          created_at: data[0].created_at,
          updated_at: data[0].updated_at,
          title: data[0].title,
          subtitle: data[0].subtitle,
          link_url: data[0].link_url,
          button_text: data[0].button_text,
          position: data[0].position,
          is_active: data[0].is_active,
        }
      : null

    return updatedSlideshow
  } catch (error) {
    console.error(`Исключение при обновлении слайда с ID ${id}:`, error)
    return null
  }
}

// Удаление слайда
export async function deleteSlideshow(id: string): Promise<boolean> {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists()
    if (!tableExists) {
      console.log("Таблица slideshows не существует, возвращаем false")
      return false
    }

    const { error } = await supabase.from("slideshows").delete().eq("id", id)

    if (error) {
      console.error(`Ошибка при удалении слайда с ID ${id}:`, error)
      return false
    }

    return true
  } catch (error) {
    console.error(`Исключение при удалении слайда с ID ${id}:`, error)
    return false
  }
}

// Изменение порядка слайдов
export async function reorderSlideshows(slideshowIds: string[]): Promise<boolean> {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists()
    if (!tableExists) {
      console.log("Таблица slideshows не существует, возвращаем false")
      return false
    }

    // Обновляем порядок слайдов
    for (let i = 0; i < slideshowIds.length; i++) {
      const { error } = await supabase
        .from("slideshows")
        .update({ slide_order: i + 1, updated_at: new Date().toISOString() })
        .eq("id", slideshowIds[i])

      if (error) {
        console.error(`Ошибка при обновлении порядка слайда с ID ${slideshowIds[i]}:`, error)
        return false
      }
    }

    return true
  } catch (error) {
    console.error("Исключение при изменении порядка слайдов:", error)
    return false
  }
}

// Получение активных слайдов для отображения на сайте
export async function getActiveSlideshows(): Promise<Slideshow[]> {
  try {
    // Проверяем существование таблицы
    const tableExists = await checkTableExists()
    if (!tableExists) {
      console.log("Таблица slideshows не существует, возвращаем пустой массив")
      return []
    }

    const { data, error } = await supabase
      .from("slideshows")
      .select("*")
      .eq("is_active", true)
      .order("slide_order", { ascending: true })

    if (error) {
      console.error("Ошибка при получении активных слайдов:", error)
      return []
    }

    // Преобразуем данные для совместимости
    const slideshows = data.map((item) => ({
      id: item.id,
      image_url: item.image_url,
      description: item.description || item.subtitle,
      link: item.link || item.link_url,
      slide_order: item.slide_order || item.position || 0,
      active: item.active !== undefined ? item.active : item.is_active !== undefined ? item.is_active : true,
      created_at: item.created_at,
      updated_at: item.updated_at,
      title: item.title,
      subtitle: item.subtitle,
      link_url: item.link_url,
      button_text: item.button_text,
      position: item.position,
      is_active: item.is_active,
    }))

    return slideshows || []
  } catch (error) {
    console.error("Исключение при получении активных слайдов:", error)
    return []
  }
}
