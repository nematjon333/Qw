export type Product = {
  id: string
  name: string
  price: number
  description: string
  category: string
  unit: string
  discount?: number
  images: string[]
  origin: string
  weight?: number
  volume?: number
  min_quantity?: number
  max_quantity?: number
  step?: number
  active?: boolean
  seo_title?: string
  seo_description?: string
  created_at?: string
  updated_at?: string
}

export type DeliveryZone = {
  id: string
  distance_km: number
  price: number
  active: boolean
  created_at: string
}

export type PromoCode = {
  id: string
  code: string
  discount_percent: number
  min_order_amount?: number
  max_discount_amount?: number
  usage_limit?: number
  usage_count: number
  active: boolean
  expires_at?: string
  created_at: string
}

// Mock data - replace with actual data fetching from a database or external source
const deliveryZones: DeliveryZone[] = [
  {
    id: "zone1",
    distance_km: 5,
    price: 150,
    active: true,
    created_at: new Date().toISOString(),
  },
]

const promoCodes: PromoCode[] = [
  {
    id: "promo1",
    code: "SUMMER20",
    discount_percent: 20,
    min_order_amount: 1000,
    max_discount_amount: 500,
    usage_count: 0,
    active: true,
    created_at: new Date().toISOString(),
  },
]

export async function getDeliveryZones(): Promise<DeliveryZone[]> {
  return deliveryZones
}

export async function createDeliveryZone(zone: Omit<DeliveryZone, "id" | "created_at">): Promise<DeliveryZone> {
  const newZone: DeliveryZone = {
    ...zone,
    id: Math.random().toString(36).substring(2, 15), // Generate a random ID
    created_at: new Date().toISOString(),
  }
  deliveryZones.push(newZone)
  return newZone
}

export async function getPromoCodes(): Promise<PromoCode[]> {
  return promoCodes
}

export async function createPromoCode(
  promoCode: Omit<PromoCode, "id" | "created_at" | "usage_count">,
): Promise<PromoCode> {
  const newPromoCode: PromoCode = {
    ...promoCode,
    id: Math.random().toString(36).substring(2, 15), // Generate a random ID
    usage_count: 0,
    created_at: new Date().toISOString(),
  }
  promoCodes.push(newPromoCode)
  return newPromoCode
}
