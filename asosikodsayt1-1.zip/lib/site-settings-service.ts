import { supabase } from "./supabase-client"

// Type definitions for site settings
export interface SiteSetting {
  id: string
  section: string
  key: string
  value: string
  created_at: string
  updated_at: string
}

// Interface for grouped settings
export interface GroupedSettings {
  [section: string]: {
    [key: string]: string
  }
}

// Cache for site settings to avoid frequent database calls
let settingsCache: GroupedSettings | null = null
let lastFetchTime = 0
const CACHE_TTL = 5 * 60 * 1000 // 5 minutes cache

/**
 * Fetch all site settings from the database and group them by section and key
 */
export async function getAllSiteSettings(): Promise<GroupedSettings> {
  const currentTime = Date.now()

  // Return cached settings if they exist and are not expired
  if (settingsCache && currentTime - lastFetchTime < CACHE_TTL) {
    return settingsCache
  }

  try {
    const { data, error } = await supabase.from("site_settings").select("*")

    if (error) {
      console.error("Error fetching site settings:", error)
      return {}
    }

    // Group settings by section and key
    const groupedSettings: GroupedSettings = {}

    data?.forEach((setting: SiteSetting) => {
      if (!groupedSettings[setting.section]) {
        groupedSettings[setting.section] = {}
      }

      groupedSettings[setting.section][setting.key] = setting.value
    })

    // Update cache
    settingsCache = groupedSettings
    lastFetchTime = currentTime

    return groupedSettings
  } catch (error) {
    console.error("Exception when fetching site settings:", error)
    return {}
  }
}

/**
 * Get a specific setting value by section and key
 */
export async function getSetting(section: string, key: string, defaultValue = ""): Promise<string> {
  const settings = await getAllSiteSettings()
  return settings[section]?.[key] || defaultValue
}

/**
 * Update a site setting
 */
export async function updateSetting(id: string, value: string): Promise<SiteSetting | null> {
  try {
    const { data, error } = await supabase
      .from("site_settings")
      .update({ value, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()

    if (error) {
      console.error("Error updating site setting:", error)
      return null
    }

    // Invalidate cache
    settingsCache = null

    return data[0] || null
  } catch (error) {
    console.error("Exception when updating site setting:", error)
    return null
  }
}
