// Этот файл содержит функции для работы с email через внешний API
// вместо прямого использования nodemailer, который не работает в браузерной среде

/**
 * Отправляет email через внешний API
 * @param options Параметры для отправки email
 */
export const sendEmailViaAPI = async (options: {
  to: string
  subject: string
  html: string
}) => {
  try {
    console.log(`[Email API] Отправка email на адрес: ${options.to}, тема: ${options.subject}`)

    // В реальном приложении здесь был бы запрос к внешнему API для отправки email
    // Например, SendGrid, Mailgun, или ваш собственный сервер

    // Пример запроса:
    // const response = await fetch('https://api.example.com/send-email', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(options)
    // });

    // if (!response.ok) {
    //   throw new Error(`Ошибка API: ${response.status}`);
    // }

    // const data = await response.json();
    // return { success: true, messageId: data.id };

    // Для демонстрации просто возвращаем успешный результат
    return {
      success: true,
      messageId: `demo-${Date.now()}`,
      note: "Это демонстрационный режим. Email не был отправлен.",
    }
  } catch (error) {
    console.error("[Email API] Ошибка при отправке email:", error)
    return { success: false, error }
  }
}

/**
 * Создает HTML-шаблон уведомления о новом заказе
 */
export const createOrderNotificationEmail = (orderData: any) => {
  const { order_number, customer_name, customer_phone, customer_address, items, subtotal, delivery_fee, total } =
    orderData

  // Форматирование списка товаров
  const itemsList =
    items && Array.isArray(items)
      ? items
          .map(
            (item: any) => `
  <tr>
    <td style="padding: 8px; border-bottom: 1px solid #eee;">${item.product_name}</td>
    <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">${item.quantity} ${item.unit}</td>
    <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">${item.price.toFixed(0)} ₽</td>
    <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">${(item.price * item.quantity).toFixed(0)} ₽</td>
  </tr>
`,
          )
          .join("")
      : "<tr><td colspan='4' style='padding: 8px; text-align: center;'>Информация о товарах отсутствует</td></tr>"

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Новый заказ #${order_number}</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #16a34a; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .footer { background-color: #f5f5f5; padding: 10px; text-align: center; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th { background-color: #f5f5f5; text-align: left; padding: 10px; }
        .total { font-weight: bold; }
        .button { display: inline-block; background-color: #16a34a; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Новый заказ #${order_number}</h1>
        </div>
        <div class="content">
          <p>Поступил новый заказ от клиента:</p>
          
          <h2>Информация о клиенте</h2>
          <p><strong>Имя:</strong> ${customer_name}</p>
          <p><strong>Телефон:</strong> ${customer_phone}</p>
          <p><strong>Адрес:</strong> ${customer_address}</p>
          
          <h2>Состав заказа</h2>
          <table>
            <thead>
              <tr>
                <th>Товар</th>
                <th style="text-align: center;">Количество</th>
                <th style="text-align: right;">Цена</th>
                <th style="text-align: right;">Сумма</th>
              </tr>
            </thead>
            <tbody>
              ${itemsList}
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3" style="text-align: right; padding: 8px;"><strong>Подытог:</strong></td>
                <td style="text-align: right; padding: 8px;">${subtotal.toFixed(0)} ₽</td>
              </tr>
              <tr>
                <td colspan="3" style="text-align: right; padding: 8px;"><strong>Доставка:</strong></td>
                <td style="text-align: right; padding: 8px;">${delivery_fee.toFixed(0)} ₽</td>
              </tr>
              <tr class="total">
                <td colspan="3" style="text-align: right; padding: 8px;"><strong>Итого:</strong></td>
                <td style="text-align: right; padding: 8px;"><strong>${total.toFixed(0)} ₽</strong></td>
              </tr>
            </tfoot>
          </table>
          
          <p>Пожалуйста, обработайте заказ как можно скорее.</p>
        </div>
        <div class="footer">
          <p>© 2025 Olucha-Fresh. Все права защищены.</p>
        </div>
      </div>
    </body>
    </html>
  `
}
