CREATE TABLE IF NOT EXISTS categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Добавим базовые категории, если таблица пуста
INSERT INTO categories (name, slug, description, image_url)
SELECT 'Фрукты', 'fruits', 'Свежие и сочные фрукты со всего мира', '/images/fruits-category.png'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'fruits');

INSERT INTO categories (name, slug, description, image_url)
SELECT 'Овощи', 'vegetables', 'Свежие овощи, выращенные с заботой', '/images/vegetables-category.png'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'vegetables');

INSERT INTO categories (name, slug, description, image_url)
SELECT 'Ягоды', 'berries', 'Сочные и спелые ягоды', '/images/berries-category.png'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'berries');

INSERT INTO categories (name, slug, description, image_url)
SELECT 'Сухофрукты', 'dried-fruits', 'Натуральные сухофрукты без добавок', '/images/dried-fruits-category.png'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'dried-fruits');

INSERT INTO categories (name, slug, description, image_url)
SELECT 'Зелень', 'greens', 'Свежая зелень и травы', '/images/greens-category.png'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'greens');

INSERT INTO categories (name, slug, description, image_url)
SELECT 'Напитки', 'beverages', 'Освежающие и полезные напитки', '/images/beverages-category.png'
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE slug = 'beverages');
