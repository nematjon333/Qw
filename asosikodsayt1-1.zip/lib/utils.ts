import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Функция для форматирования номера телефона в формат +7 (XXX) XXX-XX-XX
export function formatPhoneNumber(phoneNumber: string): string {
  // Удаляем все нецифровые символы
  const digitsOnly = phoneNumber.replace(/\D/g, "")

  // Если номер начинается с 8, заменяем на 7
  let normalizedNumber = digitsOnly
  if (normalizedNumber.startsWith("8")) {
    normalizedNumber = "7" + normalizedNumber.substring(1)
  }

  // Если номер не начинается с 7 и не пустой, добавляем 7 в начало
  if (!normalizedNumber.startsWith("7") && normalizedNumber.length > 0) {
    normalizedNumber = "7" + normalizedNumber
  }

  // Если номер пустой, возвращаем пустую строку
  if (normalizedNumber.length === 0) {
    return ""
  }

  // Форматируем номер в виде +7 (XXX) XXX-XX-XX
  let formattedNumber = "+"

  if (normalizedNumber.length >= 1) {
    formattedNumber += normalizedNumber.substring(0, 1)
  }

  if (normalizedNumber.length >= 4) {
    formattedNumber += " (" + normalizedNumber.substring(1, 4) + ")"
  } else if (normalizedNumber.length > 1) {
    formattedNumber += " (" + normalizedNumber.substring(1) + "_".repeat(4 - normalizedNumber.length) + ")"
  }

  if (normalizedNumber.length >= 7) {
    formattedNumber += " " + normalizedNumber.substring(4, 7)
  } else if (normalizedNumber.length > 4) {
    formattedNumber += " " + normalizedNumber.substring(4) + "_".repeat(7 - normalizedNumber.length)
  }

  if (normalizedNumber.length >= 9) {
    formattedNumber += "-" + normalizedNumber.substring(7, 9)
  } else if (normalizedNumber.length > 7) {
    formattedNumber += "-" + normalizedNumber.substring(7) + "_".repeat(9 - normalizedNumber.length)
  }

  if (normalizedNumber.length >= 11) {
    formattedNumber += "-" + normalizedNumber.substring(9, 11)
  } else if (normalizedNumber.length > 9) {
    formattedNumber += "-" + normalizedNumber.substring(9) + "_".repeat(11 - normalizedNumber.length)
  }

  return formattedNumber
}
