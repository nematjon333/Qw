import { supabase } from "./supabase-client"

// Функция для выполнения SQL запроса через REST API
async function executeSQLViaREST(sql: string): Promise<boolean> {
  try {
    console.log("Выполнение SQL запроса:", sql.substring(0, 100) + "...")

    // Используем REST API для выполнения SQL запроса
    const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/rpc/exec_sql`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
        Authorization: `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""}`,
      },
      body: JSON.stringify({ sql }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("Ошибка при выполнении SQL через REST API:", errorText)
      return false
    }

    return true
  } catch (error) {
    console.error("Исключение при выполнении SQL через REST API:", error)
    return false
  }
}

// Функция для создания таблицы через прямую вставку
async function createTableViaInsert(tableName: string, sampleData: any): Promise<boolean> {
  try {
    console.log(`Попытка создания таблицы ${tableName} через вставку данных:`, sampleData)

    const { error } = await supabase.from(tableName).insert([sampleData])

    if (error) {
      console.error(`Ошибка при создании таблицы ${tableName} через вставку:`, error)
      return false
    }

    return true
  } catch (error) {
    console.error(`Исключение при создании таблицы ${tableName} через вставку:`, error)
    return false
  }
}

// Функция для проверки существования таблицы
export async function checkTableExists(tableName: string): Promise<boolean> {
  try {
    console.log(`Проверка существования таблицы ${tableName}...`)

    const { error } = await supabase.from(tableName).select("count").limit(1)

    if (error && error.code === "42P01") {
      console.log(`Таблица ${tableName} не существует`)
      return false
    }

    console.log(`Таблица ${tableName} существует`)
    return true
  } catch (error) {
    console.error(`Ошибка при проверке таблицы ${tableName}:`, error)
    return false
  }
}

// Функция для создания таблицы orders
async function createOrdersTable(): Promise<boolean> {
  const tableName = "orders"

  // Проверяем, существует ли таблица
  if (await checkTableExists(tableName)) {
    console.log(`Таблица ${tableName} уже существует`)
    return true
  }

  // SQL для создания таблицы
  const sql = `
    CREATE TABLE IF NOT EXISTS orders (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      order_number TEXT,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      customer_address TEXT NOT NULL,
      entrance TEXT,
      floor TEXT,
      delivery_type TEXT DEFAULT 'door',
      payment_method TEXT DEFAULT 'cash',
      comment TEXT,
      promo_code TEXT,
      promo_discount NUMERIC DEFAULT 0,
      subtotal NUMERIC NOT NULL,
      delivery_fee NUMERIC NOT NULL,
      total NUMERIC NOT NULL,
      status TEXT DEFAULT 'new',
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `

  // Пробуем создать таблицу через SQL
  const success = await executeSQLViaREST(sql)

  if (success) {
    console.log(`Таблица ${tableName} успешно создана через SQL`)
    return true
  }

  // Если SQL не сработал, пробуем через вставку
  const sampleData = {
    order_number: "test",
    customer_name: "Test User",
    customer_phone: "1234567890",
    customer_address: "Test Address",
    subtotal: 100,
    delivery_fee: 50,
    total: 150,
  }

  const insertSuccess = await createTableViaInsert(tableName, sampleData)

  if (insertSuccess) {
    console.log(`Таблица ${tableName} успешно создана через вставку`)
    return true
  }

  console.error(`Не удалось создать таблицу ${tableName}`)
  return false
}

// Функция для создания таблицы order_items
async function createOrderItemsTable(): Promise<boolean> {
  const tableName = "order_items"

  // Проверяем, существует ли таблица
  if (await checkTableExists(tableName)) {
    console.log(`Таблица ${tableName} уже существует`)
    return true
  }

  // Проверяем, существует ли таблица orders
  if (!(await checkTableExists("orders"))) {
    console.error("Таблица orders не существует, невозможно создать order_items")
    return false
  }

  // SQL для создания таблицы
  const sql = `
    CREATE TABLE IF NOT EXISTS order_items (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      order_id UUID NOT NULL,
      product_id TEXT,
      product_name TEXT NOT NULL,
      price NUMERIC NOT NULL,
      quantity NUMERIC NOT NULL,
      unit TEXT NOT NULL,
      discount NUMERIC,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
  `

  // Пробуем создать таблицу через SQL
  const success = await executeSQLViaREST(sql)

  if (success) {
    console.log(`Таблица ${tableName} успешно создана через SQL`)
    return true
  }

  // Если SQL не сработал, пробуем через вставку
  // Сначала получаем ID существующего заказа
  const { data: orders } = await supabase.from("orders").select("id").limit(1)

  if (!orders || orders.length === 0) {
    console.error("Нет заказов для создания тестового элемента order_items")
    return false
  }

  const sampleData = {
    order_id: orders[0].id,
    product_name: "Test Product",
    price: 100,
    quantity: 1,
    unit: "шт",
  }

  const insertSuccess = await createTableViaInsert(tableName, sampleData)

  if (insertSuccess) {
    console.log(`Таблица ${tableName} успешно создана через вставку`)
    return true
  }

  console.error(`Не удалось создать таблицу ${tableName}`)
  return false
}

// Функция для создания таблицы customers
async function createCustomersTable(): Promise<boolean> {
  const tableName = "customers"

  // Проверяем, существует ли таблица
  if (await checkTableExists(tableName)) {
    console.log(`Таблица ${tableName} уже существует`)
    return true
  }

  // SQL для создания таблицы
  const sql = `
    CREATE TABLE IF NOT EXISTS customers (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      address TEXT NOT NULL,
      entrance TEXT,
      floor TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `

  // Пробуем создать таблицу через SQL
  const success = await executeSQLViaREST(sql)

  if (success) {
    console.log(`Таблица ${tableName} успешно создана через SQL`)
    return true
  }

  // Если SQL не сработал, пробуем через вставку
  const sampleData = {
    name: "Test Customer",
    phone: "1234567890",
    address: "Test Address",
  }

  const insertSuccess = await createTableViaInsert(tableName, sampleData)

  if (insertSuccess) {
    console.log(`Таблица ${tableName} успешно создана через вставку`)
    return true
  }

  console.error(`Не удалось создать таблицу ${tableName}`)
  return false
}

// Функция для создания таблицы promo_codes
async function createPromoCodesTable(): Promise<boolean> {
  const tableName = "promo_codes"

  // Проверяем, существует ли таблица
  if (await checkTableExists(tableName)) {
    console.log(`Таблица ${tableName} уже существует`)
    return true
  }

  // SQL для создания таблицы
  const sql = `
    CREATE TABLE IF NOT EXISTS promo_codes (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      code TEXT NOT NULL UNIQUE,
      discount_percent NUMERIC NOT NULL,
      min_order_amount NUMERIC DEFAULT 0,
      max_discount_amount NUMERIC,
      usage_limit INTEGER DEFAULT NULL,
      usage_count INTEGER DEFAULT 0,
      active BOOLEAN DEFAULT true,
      expires_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `

  // Пробуем создать таблицу через SQL
  const success = await executeSQLViaREST(sql)

  if (success) {
    console.log(`Таблица ${tableName} успешно создана через SQL`)
    return true
  }

  // Если SQL не сработал, пробуем через вставку
  const sampleData = {
    code: "TEST",
    discount_percent: 10,
    min_order_amount: 1000,
    max_discount_amount: 500,
    usage_limit: 100,
    usage_count: 0,
    active: true,
  }

  const insertSuccess = await createTableViaInsert(tableName, sampleData)

  if (insertSuccess) {
    console.log(`Таблица ${tableName} успешно создана через вставку`)
    return true
  }

  console.error(`Не удалось создать таблицу ${tableName}`)
  return false
}

// Функция для создания таблицы delivery_zones
async function createDeliveryZonesTable(): Promise<boolean> {
  const tableName = "delivery_zones"

  // Проверяем, существует ли таблица
  if (await checkTableExists(tableName)) {
    console.log(`Таблица ${tableName} уже существует`)
    return true
  }

  // SQL для создания таблицы
  const sql = `
    CREATE TABLE IF NOT EXISTS delivery_zones (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      distance_km NUMERIC NOT NULL,
      price NUMERIC NOT NULL,
      active BOOLEAN DEFAULT true,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `

  // Пробуем создать таблицу через SQL
  const success = await executeSQLViaREST(sql)

  if (success) {
    console.log(`Таблица ${tableName} успешно создана через SQL`)
    return true
  }

  // Если SQL не сработал, пробуем через вставку
  const sampleData = {
    distance_km: 5,
    price: 150,
    active: true,
  }

  const insertSuccess = await createTableViaInsert(tableName, sampleData)

  if (insertSuccess) {
    console.log(`Таблица ${tableName} успешно создана через вставку`)
    return true
  }

  console.error(`Не удалось создать таблицу ${tableName}`)
  return false
}

// Функция для создания таблицы products
async function createProductsTable(): Promise<boolean> {
  const tableName = "products"

  // Проверяем, существует ли таблица
  if (await checkTableExists(tableName)) {
    console.log(`Таблица ${tableName} уже существует`)
    return true
  }

  // SQL для создания таблицы
  const sql = `
    CREATE TABLE IF NOT EXISTS products (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      name TEXT NOT NULL,
      price NUMERIC NOT NULL,
      description TEXT,
      category TEXT NOT NULL,
      unit TEXT NOT NULL,
      discount NUMERIC,
      images TEXT[],
      origin TEXT,
      weight NUMERIC,
      volume NUMERIC,
      min_quantity NUMERIC,
      max_quantity NUMERIC,
      step NUMERIC,
      active BOOLEAN DEFAULT true,
      on_homepage BOOLEAN DEFAULT false,
      seo_title TEXT,
      seo_description TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `

  // Пробуем создать таблицу через SQL
  const success = await executeSQLViaREST(sql)

  if (success) {
    console.log(`Таблица ${tableName} успешно создана через SQL`)
    return true
  }

  // Если SQL не сработал, пробуем через вставку
  const sampleData = {
    name: "Test Product",
    price: 100,
    category: "fruits",
    unit: "кг",
    images: ["/placeholder.svg?height=400&width=400"],
    active: true,
  }

  const insertSuccess = await createTableViaInsert(tableName, sampleData)

  if (insertSuccess) {
    console.log(`Таблица ${tableName} успешно создана через вставку`)
    return true
  }

  console.error(`Не удалось создать таблицу ${tableName}`)
  return false
}

// Функция для создания таблицы site_settings
async function createSiteSettingsTable(): Promise<boolean> {
  const tableName = "site_settings"

  // Проверяем, существует ли таблица
  if (await checkTableExists(tableName)) {
    console.log(`Таблица ${tableName} уже существует`)
    return true
  }

  // SQL для создания таблицы
  const sql = `
    CREATE TABLE IF NOT EXISTS site_settings (
      id TEXT PRIMARY KEY,
      section TEXT NOT NULL,
      key TEXT NOT NULL,
      value TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `

  // Пробуем создать таблицу через SQL
  const success = await executeSQLViaREST(sql)

  if (success) {
    console.log(`Таблица ${tableName} успешно создана через SQL`)
    return true
  }

  // Если SQL не сработал, пробуем через вставку
  const sampleData = {
    id: "home_banner_title",
    section: "home",
    key: "banner_title",
    value: "Свежие продукты с доставкой",
  }

  const insertSuccess = await createTableViaInsert(tableName, sampleData)

  if (insertSuccess) {
    console.log(`Таблица ${tableName} успешно создана через вставку`)
    return true
  }

  console.error(`Не удалось создать таблицу ${tableName}`)
  return false
}

// Основная функция для настройки базы данных
export async function setupDatabase() {
  console.log("Начинаем проверку базы данных...")

  try {
    // Проверяем существование всех необходимых таблиц
    const tables = {
      orders: await checkTableExists("orders"),
      order_items: await checkTableExists("order_items"),
      customers: await checkTableExists("customers"),
      promo_codes: await checkTableExists("promo_codes"),
      delivery_zones: await checkTableExists("delivery_zones"),
      products: await checkTableExists("products"),
      site_settings: await checkTableExists("site_settings"),
    }

    const allTablesExist = Object.values(tables).every(Boolean)

    if (allTablesExist) {
      console.log("Все необходимые таблицы существуют!")
      return { success: true, message: "Все необходимые таблицы существуют", tables }
    } else {
      console.log("Некоторые таблицы отсутствуют. Используйте SQL-запрос для их создания.")
      return {
        success: false,
        message: "Некоторые таблицы отсутствуют. Используйте SQL-запрос для их создания.",
        tables,
      }
    }
  } catch (error) {
    console.error("Ошибка при проверке базы данных:", error)
    return { success: false, message: "Ошибка при проверке базы данных", error }
  }
}
