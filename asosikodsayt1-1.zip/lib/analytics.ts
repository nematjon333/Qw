// Basic analytics module with fallback functionality

// Check if window is defined (browser environment)
const isBrowser = typeof window !== "undefined"

// Create a safe version of dataLayer
const getDataLayer = () => {
  if (isBrowser) {
    // Make sure window.dataLayer exists
    window.dataLayer = window.dataLayer || []
    return window.dataLayer
  }
  return []
}

// Function to safely track events
const safeTrack = (callback) => {
  try {
    if (isBrowser) {
      callback()
    }
  } catch (error) {
    console.error("Analytics error:", error)
  }
}

// E-commerce event tracking
export const ecommerceEvents = {
  // View item
  viewItem: (product) => {
    safeTrack(() => {
      const dataLayer = getDataLayer()
      dataLayer.push({
        event: "view_item",
        currency: "RUB",
        value: product.price,
        items: [
          {
            item_id: product.id,
            item_name: product.name,
            price: product.price,
            item_category: product.category || "",
          },
        ],
      })
    })
  },

  // Add to cart
  addToCart: (product) => {
    safeTrack(() => {
      const dataLayer = getDataLayer()
      dataLayer.push({
        event: "add_to_cart",
        currency: "RUB",
        value: product.price * product.quantity,
        items: [
          {
            item_id: product.id,
            item_name: product.name,
            price: product.price,
            quantity: product.quantity,
            item_category: product.category || "",
          },
        ],
      })
    })
  },

  // Begin checkout
  beginCheckout: (cart) => {
    safeTrack(() => {
      const dataLayer = getDataLayer()
      dataLayer.push({
        event: "begin_checkout",
        currency: "RUB",
        value: cart.total,
        items: cart.items.map((item) => ({
          item_id: item.id,
          item_name: item.name,
          price: item.price,
          quantity: item.quantity,
          item_category: item.category || "",
        })),
      })
    })
  },

  // Purchase
  purchase: (order) => {
    safeTrack(() => {
      const dataLayer = getDataLayer()
      dataLayer.push({
        event: "purchase",
        transaction_id: order.id,
        currency: "RUB",
        value: order.total,
        items: order.items.map((item) => ({
          item_id: item.id,
          item_name: item.name,
          price: item.price,
          quantity: item.quantity,
          item_category: item.category || "",
        })),
      })
    })
  },
}

// Track page view
export const trackPageView = (url) => {
  safeTrack(() => {
    const dataLayer = getDataLayer()
    dataLayer.push({
      event: "page_view",
      page_location: url,
    })
  })
}

// Default export
export default {
  ecommerceEvents,
  trackPageView,
}
