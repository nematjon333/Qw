import { createClient } from "@supabase/supabase-js"

// Типы данных для Яндекс.Доставки
export interface YandexDeliveryRequest {
  items: {
    weight: number
    dimensions: {
      length: number
      width: number
      height: number
    }
  }[]
  route_points: {
    coordinates: number[]
    address: {
      fullname: string
    }
  }[]
  tariff_class: string
}

export interface YandexDeliveryOption {
  id: string
  type: "now" | "within_60_min" | "up_to_2_hours"
  title: string
  price: number
  deliveryTime: string
  estimatedDeliveryTime: Date
}

export interface YandexDeliveryResponse {
  success: boolean
  options?: YandexDeliveryOption[]
  error?: string
}

// Константы
const STORE_ADDRESS = "Россия, г. Челябинск, ул. Артиллерийская 116/1"
const STORE_COORDINATES = [61.431893, 55.17227] // [долгота, широта]
const DEFAULT_WEIGHT = 1 // кг
const DEFAULT_DIMENSIONS = { length: 20, width: 20, height: 10 } // см

/**
 * Получает варианты доставки от Яндекс.Доставки
 */
export async function getDeliveryOptions(
  destinationAddress: string,
  destinationCoordinates: [number, number],
  weight?: number,
  dimensions?: { length: number; width: number; height: number },
): Promise<YandexDeliveryResponse> {
  try {
    const apiKey = process.env.YANDEX_API_KEY

    if (!apiKey) {
      throw new Error("API ключ Яндекс.Доставки не найден")
    }

    // Подготовка данных для запроса
    const requestData: YandexDeliveryRequest = {
      items: [
        {
          weight: weight || DEFAULT_WEIGHT,
          dimensions: dimensions || DEFAULT_DIMENSIONS,
        },
      ],
      route_points: [
        {
          coordinates: STORE_COORDINATES,
          address: {
            fullname: STORE_ADDRESS,
          },
        },
        {
          coordinates: [destinationCoordinates[0], destinationCoordinates[1]], // [долгота, широта]
          address: {
            fullname: destinationAddress,
          },
        },
      ],
      tariff_class: "express",
    }

    // Отправка запроса в API Яндекс.Доставки
    const response = await fetch("https://b2b.taxi.yandex.net/b2b/cargo/integration/v1/check-price", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(requestData),
    })

    const data = await response.json()

    // Проверка на ошибки
    if (!response.ok) {
      console.error("Ошибка Яндекс.Доставки:", data)
      return {
        success: false,
        error: data.message || "Ошибка при расчете стоимости доставки",
      }
    }

    // Если нет доступных опций доставки
    if (!data.options || data.options.length === 0) {
      return {
        success: false,
        error: "Доставка недоступна по этому адресу",
      }
    }

    // Обработка ответа и формирование трех вариантов доставки
    const now = new Date()

    // Создаем три варианта доставки на основе полученных данных
    const deliveryOptions: YandexDeliveryOption[] = [
      {
        id: "now",
        type: "now",
        title: "Сейчас",
        price: Math.round(data.price * 1.3), // Самая дорогая
        deliveryTime: "15-30 минут",
        estimatedDeliveryTime: new Date(now.getTime() + 30 * 60000), // +30 минут
      },
      {
        id: "within_60_min",
        type: "within_60_min",
        title: "В течение 60 минут",
        price: Math.round(data.price * 1.1), // Средняя цена
        deliveryTime: "45-60 минут",
        estimatedDeliveryTime: new Date(now.getTime() + 60 * 60000), // +60 минут
      },
      {
        id: "up_to_2_hours",
        type: "up_to_2_hours",
        title: "До 2 часов",
        price: Math.round(data.price), // Самая дешевая
        deliveryTime: "1-2 часа",
        estimatedDeliveryTime: new Date(now.getTime() + 120 * 60000), // +120 минут
      },
    ]

    return {
      success: true,
      options: deliveryOptions,
    }
  } catch (error) {
    console.error("Ошибка при получении вариантов доставки:", error)
    return {
      success: false,
      error: error.message || "Произошла ошибка при расчете стоимости доставки",
    }
  }
}

// Сохранение выбранного варианта доставки в базу данных
export async function saveDeliveryOption(orderId: string, deliveryOption: YandexDeliveryOption): Promise<boolean> {
  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

    if (!supabaseUrl || !supabaseKey) {
      throw new Error("Отсутствуют учетные данные Supabase")
    }

    const supabase = createClient(supabaseUrl, supabaseKey)

    // Обновляем заказ с информацией о доставке
    const { error } = await supabase
      .from("orders")
      .update({
        delivery_option: deliveryOption.type,
        delivery_price: deliveryOption.price,
        estimated_delivery_time: deliveryOption.estimatedDeliveryTime.toISOString(),
      })
      .eq("id", orderId)

    if (error) {
      console.error("Ошибка при сохранении варианта доставки:", error)
      return false
    }

    return true
  } catch (error) {
    console.error("Ошибка при сохранении варианта доставки:", error)
    return false
  }
}
