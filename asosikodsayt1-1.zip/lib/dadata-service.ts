// Константы для координат магазина
export const STORE_LATITUDE = 55.159897
export const STORE_LONGITUDE = 61.402554
// Максимальное расстояние доставки в метрах (15 км)
export const MAX_DELIVERY_DISTANCE = 15000

// Функция для проверки, находится ли адрес в пределах максимального расстояния доставки
export function isAddressInRange(lat: number, lng: number, maxDistance: number = MAX_DELIVERY_DISTANCE): boolean {
  const distance = calculateDistance(STORE_LATITUDE, STORE_LONGITUDE, lat, lng)
  return distance <= maxDistance
}

// Функция для получения адреса по координатам
export async function reverseGeocode(lat: number, lng: number) {
  try {
    if (!process.env.NEXT_PUBLIC_DADATA_API_KEY) {
      console.error("DADATA API key is not defined")
      throw new Error("DADATA API key is not defined")
    }

    const response = await fetch(`https://suggestions.dadata.ru/suggestions/api/4_1/rs/geolocate/address`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Token ${process.env.NEXT_PUBLIC_DADATA_API_KEY}`,
      },
      body: JSON.stringify({
        lat: lat,
        lon: lng,
        count: 1,
        radius_meters: 100, // Ищем ближайший дом в радиусе 100 метров
      }),
    })

    if (!response.ok) {
      console.error("Failed to fetch address:", response.status, response.statusText)
      throw new Error(`Failed to fetch address: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    if (!data || !data.suggestions) {
      console.error("Invalid response format from DaData API:", data)
      return null
    }

    if (data.suggestions && data.suggestions.length > 0) {
      return data.suggestions[0]
    }
    return null
  } catch (error) {
    console.error("Error in reverseGeocode:", error)
    return null
  }
}

// Функция для поиска адресов
export async function getSuggestions(query: string) {
  try {
    if (!process.env.NEXT_PUBLIC_DADATA_API_KEY) {
      console.error("DADATA API key is not defined")
      throw new Error("DADATA API key is not defined")
    }

    const response = await fetch(`https://suggestions.dadata.ru/suggestions/api/4_1/rs/suggest/address`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Token ${process.env.NEXT_PUBLIC_DADATA_API_KEY}`,
      },
      body: JSON.stringify({
        query: query,
        count: 5,
        locations: [{ city: "челябинск" }], // Ограничиваем поиск Челябинском
      }),
    })

    if (!response.ok) {
      console.error("Failed to fetch suggestions:", response.status, response.statusText)
      throw new Error(`Failed to fetch suggestions: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()

    if (!data || !data.suggestions) {
      console.error("Invalid response format from DaData API:", data)
      return []
    }

    return data.suggestions || []
  } catch (error) {
    console.error("Error in getSuggestions:", error)
    return []
  }
}

// Функция для расчета расстояния между двумя точками в метрах
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3 // Радиус Земли в метрах
  const φ1 = (lat1 * Math.PI) / 180
  const φ2 = (lat2 * Math.PI) / 180
  const Δφ = ((lat2 - lat1) * Math.PI) / 180
  const Δλ = ((lon2 - lon1) * Math.PI) / 180

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const d = R * c // Расстояние в метрах

  return Math.round(d)
}
