// Сервис для отправки уведомлений через Telegram
export async function sendTelegramMessage(message: string): Promise<boolean> {
  try {
    // Проверяем наличие токена бота и ID администратора
    const botToken = process.env.TELEGRAM_BOT_TOKEN
    const adminId = process.env.TELEGRAM_ADMIN_ID

    if (!botToken || !adminId) {
      console.error("Отсутствуют необходимые переменные окружения для Telegram: TELEGRAM_BOT_TOKEN, TELEGRAM_ADMIN_ID")
      return false
    }

    // Формируем URL для отправки сообщения
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`

    console.log("Отправка уведомления в Telegram на ID:", adminId)

    // Отправляем запрос к API Telegram с таймаутом и повторными попытками
    let attempts = 0
    const maxAttempts = 3

    while (attempts < maxAttempts) {
      try {
        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 секунд таймаут

        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            chat_id: adminId,
            text: message,
            parse_mode: "HTML",
          }),
          signal: controller.signal,
        })

        clearTimeout(timeoutId)

        if (!response.ok) {
          const errorData = await response.json()
          console.error(`Попытка ${attempts + 1}/${maxAttempts}: Ошибка при отправке сообщения в Telegram:`, errorData)
          attempts++

          if (attempts >= maxAttempts) {
            return false
          }

          // Ждем перед следующей попыткой
          await new Promise((resolve) => setTimeout(resolve, 1000))
          continue
        }

        const data = await response.json()
        console.log("Сообщение успешно отправлено в Telegram")
        return data.ok
      } catch (fetchError) {
        console.error(`Попытка ${attempts + 1}/${maxAttempts}: Исключение при отправке:`, fetchError)
        attempts++

        if (attempts >= maxAttempts) {
          return false
        }

        // Ждем перед следующей попыткой
        await new Promise((resolve) => setTimeout(resolve, 1000))
      }
    }

    return false
  } catch (error) {
    console.error("Исключение при отправке сообщения в Telegram:", error)
    return false
  }
}

// Функция для перевода способа оплаты на русский
function translatePaymentMethod(method: string): string {
  switch (method) {
    case "cash":
      return "Наличными при получении"
    case "online":
      return "Онлайн оплата"
    default:
      return method
  }
}

// Функция для перевода типа доставки на русский
function translateDeliveryType(type: string): string {
  switch (type) {
    case "door":
      return "До двери"
    case "entrance":
      return "До подъезда"
    default:
      return type
  }
}

// Функция для создания сообщения о новом заказе
export function createOrderNotificationMessage(orderData: any): string {
  const {
    order_number,
    customer_name,
    customer_phone,
    customer_address,
    items,
    subtotal,
    delivery_fee,
    total,
    entrance,
    floor,
    apartment,
    payment_method,
    delivery_type,
    delivery_time,
    comment,
  } = orderData

  // Форматирование списка товаров
  const itemsList =
    items && Array.isArray(items)
      ? items
          .map(
            (item: any) =>
              `- ${item.product_name || item.name}: ${item.quantity} ${item.unit} x ${item.price.toFixed(0)} ₽ = ${(item.price * item.quantity).toFixed(0)} ₽`,
          )
          .join("\n")
      : "Информация о товарах отсутствует"

  // Переводим способ оплаты и тип доставки на русский
  const paymentMethodRu = translatePaymentMethod(payment_method)
  const deliveryTypeRu = delivery_type ? translateDeliveryType(delivery_type) : "Не указан"

  // Формируем сообщение в HTML-формате
  return `
<b>🔔 Новый заказ #${order_number}</b>

<b>Информация о клиенте:</b>
Имя: ${customer_name}
Телефон: ${customer_phone}
Адрес: ${customer_address}
${entrance ? `Подъезд: ${entrance}` : ""}
${floor ? `Этаж: ${floor}` : ""}\
${apartment ? `Квартира: ${apartment}` : ""}

<b>Способ оплаты:</b> ${paymentMethodRu}
<b>Тип доставки:</b> ${deliveryTypeRu}
${delivery_time ? `<b>Время доставки:</b> ${delivery_time}` : ""}
${comment ? `<b>Комментарий:</b> ${comment}` : ""}

<b>Состав заказа:</b>
${itemsList}

<b>Сумма:</b>
Подытог: ${subtotal.toFixed(0)} ₽
Доставка: ${delivery_fee.toFixed(0)} ₽
<b>Итого: ${total.toFixed(0)} ₽</b>

Пожалуйста, обработайте заказ как можно скорее.
`
}

// Функция для тестирования соединения с Telegram
export async function testTelegramConnection(): Promise<{
  success: boolean
  message: string
  config?: {
    botToken: string
    adminId: string
    botUsername: string
  }
  error?: any
}> {
  try {
    // Проверяем наличие токена бота и ID администратора
    const botToken = process.env.TELEGRAM_BOT_TOKEN
    const adminId = process.env.TELEGRAM_ADMIN_ID
    const botUsername = process.env.TELEGRAM_BOT_USERNAME || "неизвестно"

    if (!botToken || !adminId) {
      return {
        success: false,
        message: "Отсутствуют необходимые переменные окружения для Telegram",
        config: {
          botToken: botToken ? "настроен" : "не настроен",
          adminId: adminId ? "настроен" : "не настроен",
          botUsername,
        },
      }
    }

    // Отправляем тестовое сообщение
    const testMessage = `<b>Тестовое сообщение</b>\n\nЭто тестовое сообщение для проверки работы Telegram-бота.\nВремя: ${new Date().toLocaleString()}`
    const success = await sendTelegramMessage(testMessage)

    if (success) {
      return {
        success: true,
        message: "Соединение с Telegram установлено успешно",
        config: {
          botToken: "настроен",
          adminId: "настроен",
          botUsername,
        },
      }
    } else {
      return {
        success: false,
        message: "Ошибка при отправке тестового сообщения в Telegram",
        config: {
          botToken: "настроен",
          adminId: "настроен",
          botUsername,
        },
      }
    }
  } catch (error) {
    return {
      success: false,
      message: "Исключение при тестировании соединения с Telegram",
      error,
    }
  }
}
