import nodemailer from "nodemailer"

// Функция для проверки наличия необходимых переменных окружения
export const checkEmailConfig = () => {
  const requiredVars = ["EMAIL_HOST", "EMAIL_PORT", "EMAIL_USER", "EMAIL_PASSWORD", "ADMIN_EMAIL"]

  const missingVars = requiredVars.filter((varName) => !process.env[varName])

  if (missingVars.length > 0) {
    console.error(`Отсутствуют необходимые переменные окружения для отправки email: ${missingVars.join(", ")}`)
    return false
  }

  return true
}

// Создаем транспорт для отправки email с дополнительной отладкой
export const createTransporter = () => {
  if (!checkEmailConfig()) {
    throw new Error("Неправильная конфигурация email")
  }

  console.log("Создание транспорта для отправки email с параметрами:", {
    host: process.env.EMAIL_HOST,
    port: Number.parseInt(process.env.EMAIL_PORT || "587"),
    secure: process.env.EMAIL_SECURE === "true",
    auth: {
      user: process.env.EMAIL_USER,
    },
  })

  const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: Number.parseInt(process.env.EMAIL_PORT || "587"),
    secure: process.env.EMAIL_SECURE === "true",
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASSWORD,
    },
    // Добавляем дополнительные параметры для отладки
    debug: true,
    logger: true,
  })

  return transporter
}

// Функция для отправки email с улучшенной обработкой ошибок
export const sendEmail = async (options: {
  to: string
  subject: string
  html: string
}) => {
  try {
    if (!checkEmailConfig()) {
      console.error("Невозможно отправить email: неправильная конфигурация")
      return { success: false, error: "Неправильная конфигурация email" }
    }

    console.log(`Отправка email на адрес: ${options.to}, тема: ${options.subject}`)

    const transporter = createTransporter()

    // Проверка соединения перед отправкой
    try {
      await transporter.verify()
      console.log("Соединение с почтовым сервером установлено успешно")
    } catch (verifyError) {
      console.error("Ошибка при проверке соединения с почтовым сервером:", verifyError)
      return { success: false, error: verifyError }
    }

    const info = await transporter.sendMail({
      from: `"Olucha-Fresh" <${process.env.EMAIL_USER}>`,
      to: options.to,
      subject: options.subject,
      html: options.html,
    })

    console.log("Email отправлен:", info.messageId)
    return { success: true, messageId: info.messageId }
  } catch (error) {
    console.error("Ошибка при отправке email:", error)
    return { success: false, error }
  }
}

// Функция для создания HTML-шаблона уведомления о новом заказе
export const createOrderNotificationEmail = (orderData: any) => {
  const { order_number, customer_name, customer_phone, customer_address, items, subtotal, delivery_fee, total } =
    orderData

  // Форматирование списка товаров
  const itemsList =
    items && Array.isArray(items)
      ? items
          .map(
            (item: any) => `
  <tr>
    <td style="padding: 8px; border-bottom: 1px solid #eee;">${item.product_name}</td>
    <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: center;">${item.quantity} ${item.unit}</td>
    <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">${item.price.toFixed(0)} ₽</td>
    <td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">${(item.price * item.quantity).toFixed(0)} ₽</td>
  </tr>
`,
          )
          .join("")
      : "<tr><td colspan='4' style='padding: 8px; text-align: center;'>Информация о товарах отсутствует</td></tr>"

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Новый заказ #${order_number}</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #16a34a; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .footer { background-color: #f5f5f5; padding: 10px; text-align: center; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th { background-color: #f5f5f5; text-align: left; padding: 10px; }
        .total { font-weight: bold; }
        .button { display: inline-block; background-color: #16a34a; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Новый заказ #${order_number}</h1>
        </div>
        <div class="content">
          <p>Поступил новый заказ от клиента:</p>
          
          <h2>Информация о клиенте</h2>
          <p><strong>Имя:</strong> ${customer_name}</p>
          <p><strong>Телефон:</strong> ${customer_phone}</p>
          <p><strong>Адрес:</strong> ${customer_address}</p>
          
          <h2>Состав заказа</h2>
          <table>
            <thead>
              <tr>
                <th>Товар</th>
                <th style="text-align: center;">Количество</th>
                <th style="text-align: right;">Цена</th>
                <th style="text-align: right;">Сумма</th>
              </tr>
            </thead>
            <tbody>
              ${itemsList}
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3" style="text-align: right; padding: 8px;"><strong>Подытог:</strong></td>
                <td style="text-align: right; padding: 8px;">${subtotal.toFixed(0)} ₽</td>
              </tr>
              <tr>
                <td colspan="3" style="text-align: right; padding: 8px;"><strong>Доставка:</strong></td>
                <td style="text-align: right; padding: 8px;">${delivery_fee.toFixed(0)} ₽</td>
              </tr>
              <tr class="total">
                <td colspan="3" style="text-align: right; padding: 8px;"><strong>Итого:</strong></td>
                <td style="text-align: right; padding: 8px;"><strong>${total.toFixed(0)} ₽</strong></td>
              </tr>
            </tfoot>
          </table>
          
          <p>Пожалуйста, обработайте заказ как можно скорее.</p>
          
          <div style="text-align: center; margin-top: 30px;">
            <a href="${process.env.NEXT_PUBLIC_SITE_URL || "https://olucha-fresh.ru"}/admin/dashboard" class="button">
              Перейти в панель управления
            </a>
          </div>
        </div>
        <div class="footer">
          <p>© 2025 Olucha-Fresh. Все права защищены.</p>
        </div>
      </div>
    </body>
    </html>
  `
}

// Функция для создания HTML-шаблона напоминания о необработанном заказе
export const createOrderReminderEmail = (orderData: any) => {
  const { order_number, customer_name, customer_phone } = orderData

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Напоминание о заказе #${order_number}</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #f97316; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .footer { background-color: #f5f5f5; padding: 10px; text-align: center; font-size: 12px; }
        .button { display: inline-block; background-color: #16a34a; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>⚠️ Напоминание о необработанном заказе</h1>
        </div>
        <div class="content">
          <p>Заказ <strong>#${order_number}</strong> от клиента <strong>${customer_name}</strong> (${customer_phone}) не был обработан в течение 20 минут.</p>
          
          <p>Пожалуйста, проверьте статус заказа и свяжитесь с клиентом как можно скорее.</p>
          
          <div style="text-align: center; margin-top: 30px;">
            <a href="${process.env.NEXT_PUBLIC_SITE_URL || "https://olucha-fresh.ru"}/admin/dashboard" class="button">
              Перейти в панель управления
            </a>
          </div>
        </div>
        <div class="footer">
          <p>© 2025 Olucha-Fresh. Все права защищены.</p>
        </div>
      </div>
    </body>
    </html>
  `
}

// Функция для тестирования отправки email
export const testEmailConnection = async () => {
  try {
    if (!checkEmailConfig()) {
      return { success: false, message: "Неправильная конфигурация email" }
    }

    const transporter = createTransporter()
    await transporter.verify()

    return { success: true, message: "Соединение с почтовым сервером установлено успешно" }
  } catch (error) {
    console.error("Ошибка при тестировании соединения с почтовым сервером:", error)
    return {
      success: false,
      message: "Ошибка при тестировании соединения с почтовым сервером",
      error: error.message,
    }
  }
}
