/**
 * Функции для генерации SEO-дружественных URL (slug) для товаров
 */

/**
 * Преобразует русский текст в транслитерацию
 */
export function transliterate(text: string): string {
  const ru = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
  const en = "abvgdeejzijklmnoprstufhzcssyea"

  return text
    .split("")
    .map((char) => {
      const lowerChar = char.toLowerCase()
      const index = ru.indexOf(lowerChar)
      if (index >= 0) {
        return en[index]
      }
      return char
    })
    .join("")
}

/**
 * Преобразует строку в slug-формат
 * Например: "Яблоки Голден (1 кг)" -> "yabloki-golden-1-kg"
 */
export function generateSlug(text: string): string {
  // Транслитерация русских символов
  const transliterated = transliterate(text)

  // Оставляем только буквы, цифры, дефисы и пробелы
  const alphaNumeric = transliterated.replace(/[^\w\s-]/g, "")

  // Заменяем пробелы и последовательности дефисов на одиночный дефис
  const slug = alphaNumeric.trim().toLowerCase().replace(/\s+/g, "-").replace(/-+/g, "-")

  return slug
}

/**
 * Убеждаемся, что slug уникален, добавляя число если нужно
 * Например: если "yabloki-golden" уже существует, вернет "yabloki-golden-2"
 */
export async function ensureUniqueSlug(slug: string, id?: string): Promise<string> {
  try {
    // Проверяем наличие товара с таким slug
    const response = await fetch(`/api/products/check-slug?slug=${slug}${id ? `&id=${id}` : ""}`)
    const data = await response.json()

    if (!data.exists) {
      return slug // Если slug уникален, возвращаем его
    }

    // Если такой slug уже есть, добавляем число в конец
    // Сначала проверяем, есть ли уже число в конце
    const match = slug.match(/-(\d+)$/)

    if (match) {
      // Если число уже есть, увеличиваем его
      const number = Number.parseInt(match[1], 10) + 1
      const newSlug = slug.replace(/-\d+$/, `-${number}`)
      return ensureUniqueSlug(newSlug, id)
    } else {
      // Если числа нет, добавляем -2
      return ensureUniqueSlug(`${slug}-2`, id)
    }
  } catch (error) {
    console.error("Ошибка при проверке уникальности slug:", error)
    // В случае ошибки добавляем случайное число для уникальности
    return `${slug}-${Math.floor(Math.random() * 1000)}`
  }
}

/**
 * Генерирует SEO-заголовок на основе имени и категории товара
 */
export function generateSeoTitle(name: string, category: string): string {
  const categoryNames = {
    fruits: "фрукт",
    vegetables: "овощ",
    berries: "ягода",
    "dried-fruits": "сухофрукт",
    greens: "зелень",
    beverages: "напиток",
    bread: "хлеб",
    sets: "набор",
    exotic: "экзотический продукт",
    promotions: "товар со скидкой",
  }

  const categoryName = categoryNames[category] || "продукт"

  return `${name} - свежий ${categoryName} с доставкой в Челябинске | OLUCHA`
}

/**
 * Генерирует SEO-описание на основе имени и категории товара
 */
export function generateSeoDescription(name: string, category: string): string {
  const descriptions = {
    fruits: `Купить свежие ${name} с доставкой по Челябинску. Высокое качество, доступные цены, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA! Выгодные предложения на свежие фрукты.`,
    vegetables: `Купить свежие ${name} с доставкой по Челябинску. Высокое качество, доступные цены, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA! Лучшие овощи по выгодным ценам.`,
    berries: `Купить свежие ${name} с доставкой по Челябинску. Натуральный вкус, собранные на пике спелости, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA! Сезонные ягоды по выгодным ценам.`,
    "dried-fruits": `Купить качественные ${name} с доставкой по Челябинску. Натуральный вкус, без добавок, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA! Богатый выбор орехов и сухофруктов.`,
    greens: `Купить свежую ${name} с доставкой по Челябинску. Высокое качество, свежий урожай, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA! Витаминная зелень для вашего здоровья.`,
    beverages: `Купить натуральный ${name} с доставкой по Челябинску. Высокое качество, доступные цены, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA! Освежающие и полезные напитки.`,
    bread: `Купить свежий ${name} с доставкой по Челябинску. Только натуральные ингредиенты, доступные цены, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA!`,
    sets: `Купить набор ${name} с доставкой по Челябинску. Удобное решение для вашего стола, выгодная цена, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA!`,
    exotic: `Купить экзотический ${name} с доставкой по Челябинску. Редкие и необычные продукты, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA! Удивите себя и близких!`,
    promotions: `Купить ${name} со скидкой и доставкой по Челябинску. Выгодное предложение, быстрая доставка за 60 минут. Заказывайте ${name} в интернет-магазине OLUCHA! Ограниченное предложение!`,
  }

  return descriptions[category] || descriptions.fruits
}

/**
 * Генерирует полный набор SEO-данных для товара
 */
export function generateProductSeoData(name: string, category: string) {
  return {
    seoTitle: generateSeoTitle(name, category),
    seoDescription: generateSeoDescription(name, category),
  }
}
