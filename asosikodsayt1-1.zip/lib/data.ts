// Типы данных
export type Product = {
  id: string
  name: string
  price: number
  description: string
  category: string
  unit: string
  discount?: number
  images: string[]
  origin: string
  weight?: number
  volume?: number
  related?: string[]
  seo_title?: string
  seo_description?: string
  created_at: string
  updated_at: string
  min_quantity?: number
  max_quantity?: number
  step?: number
  active?: boolean
}

export type PromoCode = {
  id: string
  code: string
  discount_percent: number
  min_order_amount?: number
  max_discount_amount?: number
  usage_limit?: number
  usage_count: number
  active: boolean
  expires_at?: string
  created_at: string
}

export type DeliveryZone = {
  id: string
  distance_km: number
  price: number
  active: boolean
  created_at: string
}

// Временное хранилище данных (в реальном приложении здесь будет база данных)
let products: Product[] = [
  {
    id: "1",
    name: "Яблоки Голден",
    price: 159,
    description:
      "Сочные и сладкие яблоки сорта Голден. Идеально подходят для употребления в свежем виде, а также для приготовления десертов и выпечки.",
    category: "fruits",
    unit: "кг",
    discount: 15,
    images: ["/placeholder.svg?height=400&width=400"],
    origin: "Краснодарский край",
    weight: 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    min_quantity: 0.1,
    max_quantity: 10,
    step: 0.1,
    active: true,
  },
  {
    id: "2",
    name: "Бананы",
    price: 129,
    description: "Спелые и сладкие бананы. Богаты калием и другими полезными веществами.",
    category: "fruits",
    unit: "кг",
    images: ["/placeholder.svg?height=400&width=400"],
    origin: "Эквадор",
    weight: 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    min_quantity: 0.1,
    max_quantity: 10,
    step: 0.1,
    active: true,
  },
]

const promoCodes: PromoCode[] = [
  {
    id: "1",
    code: "WELCOME",
    discount_percent: 15,
    min_order_amount: 1000,
    max_discount_amount: 500,
    usage_limit: 100,
    usage_count: 0,
    active: true,
    created_at: new Date().toISOString(),
  },
]

const deliveryZones: DeliveryZone[] = [
  {
    id: "1",
    distance_km: 5,
    price: 150,
    active: true,
    created_at: new Date().toISOString(),
  },
]

// Функции для работы с продуктами
export async function getProducts(): Promise<Product[]> {
  return products
}

export async function getProductById(id: string): Promise<Product | null> {
  const product = products.find((p) => p.id === id)
  return product || null
}

export async function createProduct(product: Omit<Product, "id" | "created_at" | "updated_at">): Promise<Product> {
  const newProduct: Product = {
    ...product,
    id: crypto.randomUUID(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }

  products.push(newProduct)
  return newProduct
}

export async function updateProduct(id: string, product: Partial<Product>): Promise<Product | null> {
  const index = products.findIndex((p) => p.id === id)
  if (index === -1) return null

  products[index] = {
    ...products[index],
    ...product,
    updated_at: new Date().toISOString(),
  }

  return products[index]
}

export async function deleteProduct(id: string): Promise<boolean> {
  const initialLength = products.length
  products = products.filter((p) => p.id !== id)
  return products.length < initialLength
}

// Функции для работы с промокодами
export async function getPromoCodes(): Promise<PromoCode[]> {
  return promoCodes
}

export async function createPromoCode(
  promoCode: Omit<PromoCode, "id" | "created_at" | "usage_count">,
): Promise<PromoCode> {
  const newPromoCode: PromoCode = {
    ...promoCode,
    id: crypto.randomUUID(),
    usage_count: 0,
    created_at: new Date().toISOString(),
  }

  promoCodes.push(newPromoCode)
  return newPromoCode
}

// Функции для работы с зонами доставки
export async function getDeliveryZones(): Promise<DeliveryZone[]> {
  return deliveryZones
}

export async function createDeliveryZone(zone: Omit<DeliveryZone, "id" | "created_at">): Promise<DeliveryZone> {
  const newZone: DeliveryZone = {
    ...zone,
    id: crypto.randomUUID(),
    created_at: new Date().toISOString(),
  }

  deliveryZones.push(newZone)
  return newZone
}

// Функция для аутентификации администратора
export function isAdminAuthenticated(): boolean {
  if (typeof window === "undefined") return false
  return localStorage.getItem("admin_authenticated") === "true"
}

export function adminLogin(username: string, password: string): boolean {
  if (username === "admin" && password === "admin") {
    if (typeof window !== "undefined") {
      localStorage.setItem("admin_authenticated", "true")
    }
    return true
  }
  return false
}

export function adminLogout(): void {
  if (typeof window !== "undefined") {
    localStorage.removeItem("admin_authenticated")
  }
}
