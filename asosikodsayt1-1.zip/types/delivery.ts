// Тип для зоны доставки из базы данных
export type RawZone = {
  id: string
  name: string
  min_distance: number
  max_distance: number
  min_km?: number
  max_km?: number
  min_m?: number
  max_m?: number
  price: number
  min_order_amount: number
  free_delivery_threshold: number | null
  estimated_time: number | string
  color: string
  active: boolean
  surge_active: boolean
  surge_price: number
  surge_reason: string | null
  created_at?: string
  updated_at?: string | null
  type?: "circle" | "polygon"
  center?: { lat: number; lng: number }
  radius?: number
  coordinates?: [number, number][]
  base_fee?: number
  per_km_fee?: number
}

// Нормализованный тип зоны доставки для использования в клиентском коде
export type DeliveryZone = {
  id: string
  name: string
  minDistance: number
  maxDistance: number
  price: number
  minOrderAmount: number
  freeDeliveryThreshold: number | null
  estimatedTime: string | number
  color: string
  active: boolean
  surge_active: boolean
  surge_price: number
  surge_reason: string | null
  type?: "circle" | "polygon"
  center?: { lat: number; lng: number }
  radius?: number
  coordinates?: [number, number][]
  base_fee?: number
  per_km_fee?: number
}

// Результат расчета доставки
export type DeliveryResult = {
  zone: DeliveryZone | null
  distance: number
  isInZone: boolean
  deliveryFee: number
  minOrderAmount: number
  freeDeliveryThreshold?: number | null
  estimatedTime: string | number
  zoneName?: string
  zoneId?: string | number
  isSurgeActive?: boolean
  surgeReason?: string
  surgeAmount?: number
}

// Информация о доставке
export type DeliveryInfo = {
  isDeliveryAvailable: boolean
  fee: number
  minOrderAmount: number
  freeDeliveryThreshold?: number | null
  message: string
  distance: number
  estimatedTime: string | number
  zone?: DeliveryZone | null
  zoneName?: string
  zoneId?: string | number
  isSurgeActive?: boolean
  surgeReason?: string
  surgeAmount?: number
}
