interface Window {
  gtag: (command: "config" | "event" | "set", targetId: string, params?: { [key: string]: any }) => void
  dataLayer: any[]
}
